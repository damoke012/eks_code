# risingwave-2-imports.tf
#
# Terraform import blocks must live in the root module, even if the target
# resources are in a child module. These adopt the AWS resources created
# manually on 2026-05-26 during the risingwave-2 CICD build-out.
#
# The resource definitions themselves are in:
#   modules/irsa/risingwave-2-role.tf
#
# These imports are one-shot: on first successful apply they bring the
# resources into TF state, then Terraform ignores the import blocks on
# subsequent applies. They can be deleted after the first apply.

import {
  to = module.irsa[0].aws_s3_bucket.risingwave_2_data
  id = "risingwave-data-op-usxpress-dev"
}

import {
  to = module.irsa[0].aws_s3_bucket_public_access_block.risingwave_2_data
  id = "risingwave-data-op-usxpress-dev"
}

import {
  to = module.irsa[0].aws_iam_role.risingwave_2
  id = "op-usxpress-dev-risingwave-2"
}
