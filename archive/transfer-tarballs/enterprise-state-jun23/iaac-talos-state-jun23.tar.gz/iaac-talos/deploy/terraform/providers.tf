terraform {
  backend "s3" {}
  required_providers {
    vsphere = {
      source  = "vmware/vsphere"
      version = ">= 2.1.1"
    }
    talos = {
      source  = "siderolabs/talos"
      version = ">= 0.8.0"
    }
    flux = {
      source  = "fluxcd/flux"
      version = ">= 1.7.3"
    }

    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
    tls = {
      source  = "hashicorp/tls"
      version = ">= 4.0"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = ">= 2.20"
    }
  }
}


provider "vsphere" {
  user                 = var.vsphere_user
  password             = var.vsphere_password
  vsphere_server       = var.vsphere_server
  allow_unverified_ssl = true
}

provider "talos" {
}

provider "flux" {
  kubernetes = {
    host                   = local.kubeconfig.clusters[0].cluster.server
    cluster_ca_certificate = base64decode(local.kubeconfig.clusters[0].cluster["certificate-authority-data"])
    client_certificate     = base64decode(local.kubeconfig.users[0].user["client-certificate-data"])
    client_key             = base64decode(local.kubeconfig.users[0].user["client-key-data"])
  }
  git = {
    url = "https://github.com/${var.github_owner}/${var.github_repository}.git"
    http = {
      username = "git"
      password = var.github_token
    }
    branch = var.github_branch
  }
}

provider "aws" {
  region = var.aws_region

  dynamic "assume_role" {
    for_each = var.irsa_role_arn != "" ? [1] : []
    content {
      role_arn     = var.irsa_role_arn
      session_name = "octopus-talos-irsa"
    }
  }

  default_tags {
    tags = {
      ManagedBy = "terraform"
      Project   = "irsa"
    }
  }
}



# Standalone kubernetes provider (in addition to the one inside flux provider).
# Used for creating the magerunner-deploy ServiceAccount + token that MageRunner
# uses to authenticate against the cluster API from the Octopus worker.
provider "kubernetes" {
  host                   = local.kubeconfig.clusters[0].cluster.server
  cluster_ca_certificate = base64decode(local.kubeconfig.clusters[0].cluster["certificate-authority-data"])
  client_certificate     = base64decode(local.kubeconfig.users[0].user["client-certificate-data"])
  client_key             = base64decode(local.kubeconfig.users[0].user["client-key-data"])
}
