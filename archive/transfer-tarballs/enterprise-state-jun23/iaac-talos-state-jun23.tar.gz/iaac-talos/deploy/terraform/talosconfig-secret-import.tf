# Declarative import — adopts the existing manually-created talosconfig SM secret
# into TF state. Import blocks must live in the ROOT module per Terraform rules.
#
# AWS provider gotcha: aws_secretsmanager_secret expects the full ARN as the
# import ID, NOT the secret name. The secret name `op-usxpress-dev/talosconfig`
# gets a random suffix (-jZx93J) appended by AWS — hardcoded below.
#
# For op-usxpress-dev: secret seeded out-of-band on 2026-06-23. This block
# brings it under TF management without recreating.
#
# For NEW clusters (QA / prod): the random ARN suffix differs per secret.
# REMOVE this file before first Octopus apply since the secret doesn't exist
# yet. After first apply creates the wrapper, operator seeds value via
# 'aws secretsmanager put-secret-value'. A QA-specific import would need
# its own ARN if adopting later.
#
# Resource definition lives in modules/irsa/talosconfig-secret.tf.
import {
  to = module.irsa[0].aws_secretsmanager_secret.talosconfig
  id = "arn:aws:secretsmanager:us-east-2:700736442855:secret:op-usxpress-dev/talosconfig-jZx93J"
}
