resource "talos_machine_secrets" "cluster" {
  talos_version = var.talos_version
}

data "vsphere_datacenter" "dc" {
  name = var.datacenter
}

resource "vsphere_folder" "cluster_folder" {
  path          = var.vm_folder
  type          = "vm"
  datacenter_id = data.vsphere_datacenter.dc.id
}

module "vsphere_cp" {
  source                    = "./modules/vsphere_vm"
  vm_count                  = var.control_plane_count
  vm_folder                 = vsphere_folder.cluster_folder.path
  datacenter                = var.datacenter
  datastore                 = var.datastore
  vm_cluster_name           = var.vm_cluster_name
  content_library_name      = var.content_library_name
  content_library_item_name = var.content_library_item_name
  network_name              = var.network_name
  cpus                      = var.cp_cpus
  memory_mb                 = var.cp_memory_mb
  disk_size_gb              = var.disk_size_gb
  name_prefix               = var.control_plane_name_prefix
  sleep_seconds             = var.sleep_seconds
}

module "vsphere_worker" {
  source                    = "./modules/vsphere_vm"
  vm_count                  = var.worker_count
  vm_folder                 = vsphere_folder.cluster_folder.path
  datacenter                = var.datacenter
  datastore                 = var.datastore
  vm_cluster_name           = var.vm_cluster_name
  content_library_name      = var.content_library_name
  content_library_item_name = var.content_library_item_name
  network_name              = var.network_name
  cpus                      = var.worker_cpus
  memory_mb                 = var.worker_memory_mb
  disk_size_gb              = var.disk_size_gb
  extra_disk_size_gb        = var.worker_ceph_disk_gb
  name_prefix               = var.worker_name_prefix
  sleep_seconds             = var.sleep_seconds
}

module "cilium" {
  source            = "./modules/cilium"
  chart_version     = var.cilium_chart_version
  cli_image         = var.cilium_cli_image
  control_plane_vip = var.control_plane_vip

  extra_set = {
    # security
    "enableRemoteNodeIdentity"  = "true"
    "encryption.enabled"        = "true"
    "encryption.type"           = "wireguard"
    "encryption.nodeEncryption" = "true"
    # experimental features so we won't enable them for now
    # "identityManagementMode"    = "operator"

    # performance
    "routingMode"           = "native"
    "ipv4NativeRoutingCIDR" = "10.244.0.0/16"

    "bandwidthManager.enabled" = "true"
    "bandwidthManager.bbr"     = "true"

    # Load Balancing
    "l2announcements.enabled"            = "true"
    "l2announcements.leaseDuration"      = "10s"
    "l2announcements.leaseRenewDeadline" = "3s"
    "l2announcements.leaseRetryPeriod"   = "1s"

    "k8sClientRateLimit.qps"   = "80"
    "k8sClientRateLimit.burst" = "200"

    "externalIPs" = "true"

    # istio compatibility
    "socketLB.hostNamespaceOnly" = "true"
    "cni.exclusive"              = "false"
    "l7Proxy"                    = "false"

    # Cilium's BPF masquerading is currently disabled by default, and has issues with Istio’s use of link-local IPs for Kubernetes health checking. 
    # Enabling BPF masquerading via bpf.masquerade=true is not currently supported, and results in non-functional pod health checks in Istio ambient. 
    # Cilium's default iptables masquerading implementation should continue to function correctly.
    # github issue: https://github.com/istio/istio/issues/52208
    # "bpf.masquerade"             = "true"
    # "bpf.distributedLRU.enabled" = "true"
    # "bpf.mapDynamicSizeRatio"    = "0.08"
    # experimental features so we won't enable them for now
    # "bpf.datapathMode"           = "netkit"
    # "bpfClockProbe"              = "true"

    # observability
    # "hubble.relay.enabled"             = "true"
    # "hubble.ui.enabled"                = "true"
    # "hubble.metrics.enableOpenMetrics" = "true"
    # "hubble.metrics.enabled"           = "{dns,drop,tcp,flow,icmp,port-distribution}"

    # "prometheus.enabled"              = "true"
    # "operator.prometheus.enabled"     = "true"
    # "hubble.relay.prometheus.enabled" = "true"
  }
}

module "talos" {
  source                    = "./modules/talos"
  cluster_name              = var.cluster_name
  control_plane_vip         = var.control_plane_vip
  endpoint                  = var.endpoint
  talos_version             = var.talos_version
  control_plane_ips         = module.vsphere_cp.ip_addresses
  worker_ips                = module.vsphere_worker.ip_addresses
  control_plane_vm_names    = module.vsphere_cp.vm_names
  worker_vm_names           = module.vsphere_worker.vm_names
  control_plane_count       = var.control_plane_count
  worker_count              = var.worker_count
  control_plane_name_prefix = var.control_plane_name_prefix
  worker_name_prefix        = var.worker_name_prefix

  inline_manifests = [module.cilium.inline_manifest]

  # Talos machine secrets (generated in root to break circular dep with IRSA)
  machine_secrets      = talos_machine_secrets.cluster.machine_secrets
  client_configuration = talos_machine_secrets.cluster.client_configuration

  # IRSA
  enable_irsa     = var.enable_irsa
  oidc_issuer_url = var.enable_irsa ? module.irsa[0].oidc_issuer_url : ""

  depends_on = [module.vsphere_cp, module.vsphere_worker]
}

locals {
  kubeconfig_raw = module.talos.kubeconfig_raw
  kubeconfig     = yamldecode(local.kubeconfig_raw)

  cluster_host = try(
    local.kubeconfig.clusters[0].cluster.server,
    "https://localhost:6443"
  )
  cluster_endpoint = replace(replace(local.cluster_host, "https://", ""), "http://", "")
}

# --- IRSA: AWS resources (S3 OIDC bucket, CloudFront, IAM OIDC provider) ---
module "irsa" {
  count  = var.enable_irsa ? 1 : 0
  source = "./modules/irsa"

  cluster_name     = var.cluster_name
  aws_region       = var.aws_region
  oidc_bucket_name = var.irsa_oidc_bucket_name
  tf_state_bucket  = var.tf_state_bucket
}

module "flux" {
  source = "./modules/flux"

  target_path      = var.flux_target_path
  cluster_endpoint = local.cluster_endpoint

  github_token      = var.github_token
  github_owner      = var.github_owner
  github_repository = var.github_repository
  github_branch     = var.github_branch

  depends_on = [module.talos]
}

# --- Post-bootstrap: Upload JWKS from cluster to S3 ---
# Must run AFTER both module.talos (cluster exists) and module.irsa (S3 bucket exists).
# Kept at root level to avoid circular dependency between irsa and talos modules.
resource "terraform_data" "upload_jwks" {
  count = var.enable_irsa ? 1 : 0

  # Trigger only when the cluster identity changes (cluster recreation).
  # JWKS is stable for the cluster lifetime — no need to re-upload on every apply.
  triggers_replace = [var.cluster_name, var.irsa_oidc_bucket_name]

  provisioner "local-exec" {
    interpreter = ["/bin/bash", "-c"]
    command     = <<-EOT
      set -e

      # Assume role for cross-account access if var.irsa_role_arn is set (no-op when cluster terraform runs directly in the target account)
      if [ -n "${var.irsa_role_arn}" ]; then
        CREDS=$(aws sts assume-role --role-arn "${var.irsa_role_arn}" --role-session-name "tf-jwks" --output json)
        export AWS_ACCESS_KEY_ID=$(echo "$CREDS" | python3 -c "import sys,json; print(json.load(sys.stdin)['Credentials']['AccessKeyId'])")
        export AWS_SECRET_ACCESS_KEY=$(echo "$CREDS" | python3 -c "import sys,json; print(json.load(sys.stdin)['Credentials']['SecretAccessKey'])")
        export AWS_SESSION_TOKEN=$(echo "$CREDS" | python3 -c "import sys,json; print(json.load(sys.stdin)['Credentials']['SessionToken'])")
      fi

      KUBECONFIG_FILE=$(mktemp)
      echo '${local.kubeconfig_raw}' > "$KUBECONFIG_FILE"

      JWKS=$(KUBECONFIG="$KUBECONFIG_FILE" kubectl get --raw /openid/v1/jwks)
      echo "Fetched JWKS from cluster: $JWKS"

      echo "$JWKS" | aws s3 cp - "s3://${module.irsa[0].oidc_bucket_name}/keys.json" \
        --content-type "application/json" \
        --region "${var.aws_region}"
      echo "Uploaded JWKS to S3"

      aws cloudfront create-invalidation \
        --distribution-id "${module.irsa[0].cloudfront_distribution_id}" \
        --paths "/keys.json" \
        --region us-east-1 > /dev/null
      echo "CloudFront cache invalidated for /keys.json"

      rm -f "$KUBECONFIG_FILE"
    EOT
  }

  depends_on = [module.flux, module.irsa]
}

# --- SSM Parameters: Store cluster metadata for MageRunner eks-data module ---
# These allow terraform-variant-apps to dynamically look up on-prem cluster
# values via SSM instead of the EKS API (use_eks_api=false).
# Recreated automatically on every pipeline run so values stay current.
resource "aws_ssm_parameter" "cluster_endpoint" {
  count = var.enable_irsa ? 1 : 0

  name  = "/clusters/${var.cluster_name}/endpoint"
  type  = "String"
  value = "https://${var.control_plane_vip}:6443"

  tags = {
    cluster = var.cluster_name
    managed = "terraform-iaac-talos"
  }

  depends_on = [module.talos]
}

resource "aws_ssm_parameter" "cluster_certificate_authority" {
  count = var.enable_irsa ? 1 : 0

  name  = "/clusters/${var.cluster_name}/certificate_authority"
  type  = "String"
  value = local.kubeconfig.clusters[0].cluster.certificate-authority-data

  tags = {
    cluster = var.cluster_name
    managed = "terraform-iaac-talos"
  }

  depends_on = [module.talos]
}

resource "aws_ssm_parameter" "cluster_oidc_issuer" {
  count = var.enable_irsa ? 1 : 0

  name  = "/clusters/${var.cluster_name}/oidc_issuer"
  type  = "String"
  value = module.irsa[0].oidc_issuer_url

  tags = {
    cluster = var.cluster_name
    managed = "terraform-iaac-talos"
  }

  depends_on = [module.irsa]
}



# --- MageRunner cluster auth ---
# Long-lived ServiceAccount token that MageRunner (DX-Apply inline script) uses
# to build kubeconfig and operate on the cluster. SA has cluster-admin so
# MageRunner can create app namespaces + Helm releases.
resource "kubernetes_service_account_v1" "magerunner_deploy" {
  count = var.enable_irsa ? 1 : 0
  metadata {
    name      = "magerunner-deploy"
    namespace = "kube-system"
  }
  depends_on = [module.talos]
}

resource "kubernetes_cluster_role_binding_v1" "magerunner_deploy" {
  count = var.enable_irsa ? 1 : 0
  metadata {
    name = "magerunner-deploy-cluster-admin"
  }
  role_ref {
    api_group = "rbac.authorization.k8s.io"
    kind      = "ClusterRole"
    name      = "cluster-admin"
  }
  subject {
    kind      = "ServiceAccount"
    name      = kubernetes_service_account_v1.magerunner_deploy[0].metadata[0].name
    namespace = kubernetes_service_account_v1.magerunner_deploy[0].metadata[0].namespace
  }
}

resource "kubernetes_secret_v1" "magerunner_deploy_token" {
  count = var.enable_irsa ? 1 : 0
  metadata {
    name      = "magerunner-deploy-token"
    namespace = "kube-system"
    annotations = {
      "kubernetes.io/service-account.name" = kubernetes_service_account_v1.magerunner_deploy[0].metadata[0].name
    }
  }
  type                           = "kubernetes.io/service-account-token"
  wait_for_service_account_token = true

  depends_on = [kubernetes_cluster_role_binding_v1.magerunner_deploy]
}

# SSM param (us-east-2 primary)
resource "aws_ssm_parameter" "cluster_token" {
  count = var.enable_irsa ? 1 : 0

  name  = "/clusters/${var.cluster_name}/token"
  type  = "SecureString"
  value = kubernetes_secret_v1.magerunner_deploy_token[0].data["token"]

  tags = {
    cluster = var.cluster_name
    managed = "terraform-iaac-talos"
  }
}

