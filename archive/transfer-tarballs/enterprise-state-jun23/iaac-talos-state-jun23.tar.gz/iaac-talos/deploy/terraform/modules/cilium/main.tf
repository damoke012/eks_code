locals {
  base_set = {
    "ipam.mode"                                     = "kubernetes"
    "kubeProxyReplacement"                          = "true"
    "securityContext.capabilities.ciliumAgent"      = "{CHOWN,KILL,NET_ADMIN,NET_RAW,IPC_LOCK,SYS_ADMIN,SYS_RESOURCE,DAC_OVERRIDE,FOWNER,SETGID,SETUID}"
    "securityContext.capabilities.cleanCiliumState" = "{NET_ADMIN,SYS_ADMIN,SYS_RESOURCE}"
    "cgroup.autoMount.enabled"                      = "false"
    "cgroup.hostRoot"                               = "/sys/fs/cgroup"
    "k8sServiceHost"                                = var.control_plane_vip
    "k8sServicePort"                                = "6443"
  }

  merged_set = merge(local.base_set, var.extra_set)
  set_args   = flatten([for k, v in local.merged_set : ["--set", "${k}=${v}"]])

  rbac = [
    {
      apiVersion = "v1"
      kind       = "ServiceAccount"
      metadata   = { name = var.name, namespace = "kube-system" }
    },
    {
      apiVersion = "rbac.authorization.k8s.io/v1"
      kind       = "ClusterRoleBinding"
      metadata   = { name = var.name }
      roleRef    = { apiGroup = "rbac.authorization.k8s.io", kind = "ClusterRole", name = "cluster-admin" }
      subjects   = [{ kind = "ServiceAccount", name = var.name, namespace = "kube-system" }]
    }
  ]

  job = {
    apiVersion = "batch/v1"
    kind       = "Job"
    metadata   = { name = var.name, namespace = "kube-system" }
    spec = {
      backoffLimit = 10
      template = {
        metadata = { labels = { app = var.name } }
        spec = {
          restartPolicy      = "OnFailure"
          serviceAccountName = var.name
          hostNetwork        = true
          tolerations = [
            { operator = "Exists" },
            { effect = "NoSchedule", operator = "Exists" },
            { effect = "NoExecute", operator = "Exists" },
            { effect = "PreferNoSchedule", operator = "Exists" },
            { key = "node-role.kubernetes.io/control-plane", operator = "Exists", effect = "NoSchedule" },
            { key = "node-role.kubernetes.io/control-plane", operator = "Exists", effect = "NoExecute" },
            { key = "node-role.kubernetes.io/control-plane", operator = "Exists", effect = "PreferNoSchedule" },
          ]
          affinity = {
            nodeAffinity = {
              requiredDuringSchedulingIgnoredDuringExecution = {
                nodeSelectorTerms = [{
                  matchExpressions = [{
                    key      = "node-role.kubernetes.io/control-plane"
                    operator = "Exists"
                  }]
                }]
              }
            }
          }
          containers = [{
            name            = var.name
            image           = var.cli_image
            imagePullPolicy = "IfNotPresent"
            env = [
              { name = "KUBERNETES_SERVICE_HOST", value = var.control_plane_vip },
              { name = "KUBERNETES_SERVICE_PORT", value = "6443" }
            ]
            command = concat(["cilium", "install", "--version", var.chart_version], local.set_args)
          }]
        }
      }
    }
  }

  manifest_yaml = join("\n---\n", concat([for m in local.rbac : yamlencode(m)], [yamlencode(local.job)]))
}
