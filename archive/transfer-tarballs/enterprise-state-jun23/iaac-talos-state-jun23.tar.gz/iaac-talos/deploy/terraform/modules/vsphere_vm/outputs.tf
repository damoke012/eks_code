output "ip_addresses" {
  description = "IP addresses of the created VMs (ordering matches vm_names — no compact, no silent drops)"
  value       = [for vm in data.vsphere_virtual_machine.vm_info : vm.default_ip_address]

  precondition {
    condition = alltrue([
      for vm in data.vsphere_virtual_machine.vm_info :
      vm.default_ip_address != null && vm.default_ip_address != ""
    ])
    error_message = "One or more vSphere VMs has no default_ip_address (likely mid hot-add). Wait ~60s and re-run. compact() removed deliberately — silent index shift broke talos_machine_configuration_apply during PR #39 / Octopus 1.168."
  }
}

output "vm_names" {
  description = "vSphere VM names (count.index aligned with the resource list — same ordering as ip_addresses in steady state)"
  value       = vsphere_virtual_machine.vm[*].name
}
