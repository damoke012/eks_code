variable "name" {
  description = "Name for the inline manifest + Job/SA"
  type        = string
  default     = "cilium-install"
}

variable "chart_version" {
  description = "Cilium Helm chart version (e.g., 1.18.0)"
  type        = string
}

variable "cli_image" {
  description = "cilium CLI image tag"
  type        = string
}

variable "control_plane_vip" {
  description = "Talos API endpoint (VIP) for the control plane; no scheme, no port."
  type        = string
}

variable "extra_set" {
  description = "Additional Helm --set flags for Cilium"
  type        = map(string)
  default     = {}
}
