variable "cluster_name" {
  description = "Name of the Talos cluster"
  type        = string
}

variable "control_plane_vip" {
  description = "VIP used by Talos L2 shared IP (no scheme, no port)"
  type        = string

  validation {
    condition     = can(cidrnetmask(format("%s/32", trimspace(var.control_plane_vip))))
    error_message = "Must be a valid IPv4 address without scheme or port (e.g., 192.168.1.50)."
  }
}

variable "endpoint" {
  description = "Cluster API endpoint (e.g., https://lb.example.com or https://192.168.0.10:6443)"
  type        = string

  validation {
    condition     = can(regex("^https://[a-zA-Z0-9\\.-]+(:[0-9]+)?$", var.endpoint))
    error_message = "The endpoint must be in the format 'https://host' or 'https://host:port'."
  }
}

variable "talos_version" {
  description = "Talos Linux version to deploy"
  type        = string
}

variable "control_plane_ips" {
  description = "List of IPs for control-plane nodes"
  type        = list(string)
}

variable "worker_ips" {
  description = "List of IPs for worker nodes"
  type        = list(string)
}

variable "control_plane_count" {
  description = "Number of control-plane nodes"
  type        = number
}

variable "worker_count" {
  description = "Number of worker nodes"
  type        = number
}

variable "control_plane_name_prefix" {
  description = "Prefix for naming each control plane VM"
  type        = string
}

variable "worker_name_prefix" {
  description = "Prefix for naming each worker VM"
  type        = string
}

variable "kubernetes_version" {
  description = "Kubernetes version to deploy (must be compatible with talos_version)"
  type        = string
  default     = "1.32.0"
}

variable "machine_secrets" {
  description = "Machine secrets from talos_machine_secrets resource"
  type        = any
  sensitive   = true
}

variable "client_configuration" {
  description = "Client configuration from talos_machine_secrets resource"
  type        = any
  sensitive   = true
}

variable "inline_manifests" {
  description = "Talos inline manifests (applied during bootstrap)"
  type = list(object({
    name     = string
    contents = string
  }))
  default = []
}

# --- IRSA (IAM Roles for Service Accounts) ---

variable "enable_irsa" {
  description = "Enable IRSA configuration (OIDC issuer + SA signing keypair on control plane)"
  type        = bool
  default     = false
}

variable "oidc_issuer_url" {
  description = "OIDC issuer URL (CloudFront URL hosting discovery + JWKS documents)"
  type        = string
  default     = ""
}

variable "control_plane_vm_names" {
  description = "vSphere VM names for control plane VMs, count.index-aligned with control_plane_ips."
  type        = list(string)
}

variable "worker_vm_names" {
  description = "vSphere VM names for worker VMs, count.index-aligned with worker_ips."
  type        = list(string)
}
