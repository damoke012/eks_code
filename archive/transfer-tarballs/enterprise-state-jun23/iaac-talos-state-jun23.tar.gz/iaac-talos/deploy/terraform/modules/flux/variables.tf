variable "target_path" {
  description = "Path in repository for this cluster/environment"
  type        = string
}

variable "components_extra" {
  description = "Extra Flux components to install"
  type        = list(string)
  default     = []
}

variable "cluster_endpoint" {
  description = "Kubernetes API endpoint (host:port)"
  type        = string
}

variable "max_retries" {
  description = "Maximum number of connection attempts"
  type        = number
  default     = 60
}

variable "retry_interval" {
  description = "Seconds to wait between retry attempts"
  type        = number
  default     = 10
}

variable "github_token" {
  description = "GitHub token for pushing infra references after bootstrap"
  type        = string
  sensitive   = true
}

variable "github_owner" {
  description = "GitHub owner/organization"
  type        = string
}

variable "github_repository" {
  description = "GitHub repository name"
  type        = string
}

variable "github_branch" {
  description = "Git branch for the Flux cluster repo"
  type        = string
}
