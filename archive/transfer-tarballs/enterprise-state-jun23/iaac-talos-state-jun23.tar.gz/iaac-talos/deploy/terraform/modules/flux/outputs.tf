output "path" {
  description = "Path in repository where Flux manifests are stored"
  value       = var.target_path
}
