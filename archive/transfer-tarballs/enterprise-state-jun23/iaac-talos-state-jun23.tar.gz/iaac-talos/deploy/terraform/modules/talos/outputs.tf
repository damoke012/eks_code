output "kubeconfig_raw" {
  description = "Raw kubeconfig contents for the Talos cluster"
  value       = talos_cluster_kubeconfig.kube.kubeconfig_raw
  sensitive   = true
}
