terraform {
  required_providers {
    vsphere = {
      source = "vmware/vsphere"
    }
  }
}

data "vsphere_datacenter" "dc" {
  name = var.datacenter
}

data "vsphere_datastore" "ds" {
  name          = var.datastore
  datacenter_id = data.vsphere_datacenter.dc.id
}

data "vsphere_content_library" "library" {
  name = var.content_library_name
}

data "vsphere_content_library_item" "ova" {
  library_id = data.vsphere_content_library.library.id
  name       = var.content_library_item_name
  type       = "ovf"
}

data "vsphere_compute_cluster" "cluster" {
  name          = var.vm_cluster_name
  datacenter_id = data.vsphere_datacenter.dc.id
}

data "vsphere_resource_pool" "pool" {
  name          = "${data.vsphere_compute_cluster.cluster.name}/Resources"
  datacenter_id = data.vsphere_datacenter.dc.id
}

data "vsphere_network" "network" {
  name          = var.network_name
  datacenter_id = data.vsphere_datacenter.dc.id
}

resource "vsphere_virtual_machine" "vm" {
  count            = var.vm_count
  name             = "${var.name_prefix}-${count.index + 1}"
  folder           = var.vm_folder
  resource_pool_id = data.vsphere_resource_pool.pool.id
  datastore_id     = data.vsphere_datastore.ds.id

  clone {
    template_uuid = data.vsphere_content_library_item.ova.id
  }

  network_interface {
    network_id   = data.vsphere_network.network.id
    adapter_type = "vmxnet3"
  }

  disk {
    label            = "disk0"
    size             = var.disk_size_gb
    thin_provisioned = true
  }

  dynamic "disk" {
    for_each = var.extra_disk_size_gb > 0 ? [1] : []
    content {
      label            = "disk1"
      size             = var.extra_disk_size_gb
      unit_number      = 1
      thin_provisioned = true
    }
  }

  num_cpus = var.cpus
  memory   = var.memory_mb
  guest_id = "otherGuest64"

  wait_for_guest_net_timeout = 0

  lifecycle {
    ignore_changes = [guest_id, clone]
  }
}


locals {
  is_windows  = length(regexall("^[A-Za-z]:/", abspath(path.root))) > 0
  sleep_cmd   = local.is_windows ? "Start-Sleep -Seconds ${var.sleep_seconds}" : "sleep ${var.sleep_seconds}"
  interpreter = local.is_windows ? ["PowerShell", "-NoProfile", "-NonInteractive", "-Command"] : ["/bin/bash", "-c"]
}

resource "terraform_data" "delay_after_vm" {
  count = var.vm_count

  triggers_replace = {
    vm_id = vsphere_virtual_machine.vm[count.index].id
  }

  provisioner "local-exec" {
    interpreter = local.interpreter
    command     = local.sleep_cmd
  }

  depends_on = [resource.vsphere_virtual_machine.vm]
}

data "vsphere_virtual_machine" "vm_info" {
  count      = var.vm_count
  uuid       = vsphere_virtual_machine.vm[count.index].uuid
  depends_on = [terraform_data.delay_after_vm]
}
