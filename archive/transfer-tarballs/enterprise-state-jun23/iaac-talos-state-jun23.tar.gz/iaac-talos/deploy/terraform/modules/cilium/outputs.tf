output "inline_manifest" {
  description = "Object suitable for Talos cluster.inlineManifests"
  value = {
    name     = var.name
    contents = local.manifest_yaml
  }
}
