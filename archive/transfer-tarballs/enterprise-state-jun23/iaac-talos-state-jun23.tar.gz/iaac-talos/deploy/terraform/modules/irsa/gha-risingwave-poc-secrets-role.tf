resource "aws_iam_role" "gha_risingwave_poc_secrets" {
  name        = "gha-${var.cluster_name}-risingwave-poc-secrets"
  description = "GHA OIDC role for usxpressinc/risingwave-poc to read RW secrets from SM"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Federated = aws_iam_openid_connect_provider.github_actions.arn }
      Action    = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          # Standard audience claim for GitHub OIDC
          "token.actions.githubusercontent.com:aud" = "sts.amazonaws.com"
        }
        StringLike = {
          # Tight scope: only this repo's workflows. Blocks PRs from forks,
          # blocks any other branch in the repo, blocks any other repo.
          "token.actions.githubusercontent.com:sub" = [
            # "repo:usxpressinc/risingwave-poc:ref:refs/heads/master",
            # "repo:usxpressinc/risingwave-poc:ref:refs/heads/dev",
            # "repo:usxpressinc/risingwave-poc:ref:refs/heads/qa",
            "repo:variant-inc/risingwave-pipeline:environment:dev",
            "repo:variant-inc/risingwave-pipeline:environment:qa",
            "repo:variant-inc/risingwave-pipeline:environment:prod"
          ]
        }
      }
    }]
  })

  tags = {
    Cluster = var.cluster_name
    Purpose = "GHA-OIDC for risingwave-poc workflows reading SM secrets"
    Owner   = "tim-preble"
  }
}

# Read-only access scoped to the RisingWave secret namespace ONLY.
# DO NOT broaden to other prefixes without a separate review.
resource "aws_iam_role_policy" "gha_risingwave_poc_secrets" {
  name = "read-risingwave-secrets"
  role = aws_iam_role.gha_risingwave_poc_secrets.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "ReadRisingWaveSecrets"
        Effect = "Allow"
        Action = [
          "secretsmanager:GetSecretValue",
          "secretsmanager:DescribeSecret"
        ]
        Resource = [
          # Wildcard at the end matches the AWS-suffixed ARN form
          # (op-usxpress-dev/risingwave/postgres-uscTgj, etc.)
          "arn:aws:secretsmanager:us-east-2:700736442855:secret:op-usxpress-dev/risingwave/*"
        ]
      },
      {
        Sid      = "ListSecretsMetadata"
        Effect   = "Allow"
        Action   = "secretsmanager:ListSecrets"
        Resource = "*"
      }
    ]
  })
}
