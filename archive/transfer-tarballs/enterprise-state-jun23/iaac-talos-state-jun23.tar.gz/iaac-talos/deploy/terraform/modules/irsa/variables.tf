variable "cluster_name" {
  description = "Name of the Talos cluster (used for tagging)"
  type        = string
}

variable "aws_region" {
  description = "AWS region for S3 bucket and IAM resources"
  type        = string
}

variable "oidc_bucket_name" {
  description = "S3 bucket name for OIDC discovery and JWKS documents"
  type        = string
}



variable "tf_state_bucket" {
  description = "S3 bucket for MageRunner per-app terraform state (on-prem). Empty = skip on-prem IAM policies."
  type        = string
  default     = ""
}
