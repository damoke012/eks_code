terraform {
  required_providers {
    talos = {
      source = "siderolabs/talos"
    }
  }
}

data "talos_machine_configuration" "cp" {
  cluster_name       = var.cluster_name
  machine_type       = "controlplane"
  cluster_endpoint   = var.endpoint
  machine_secrets    = var.machine_secrets
  talos_version      = var.talos_version
  kubernetes_version = var.kubernetes_version

  config_patches = concat(
    [
      yamlencode({
        cluster = {
          network         = { cni = { name = "none" } }
          proxy           = { disabled = true }
          inlineManifests = var.inline_manifests
        }
      })
    ],
    var.enable_irsa ? [
      yamlencode({
        cluster = {
          apiServer = {
            extraArgs = {
              "service-account-issuer" = var.oidc_issuer_url
              "api-audiences"          = "sts.amazonaws.com"
            }
          }
        }
      })
    ] : []
  )
}

data "talos_machine_configuration" "worker" {
  cluster_name       = var.cluster_name
  machine_type       = "worker"
  cluster_endpoint   = var.endpoint
  machine_secrets    = var.machine_secrets
  talos_version      = var.talos_version
  kubernetes_version = var.kubernetes_version

  config_patches = [
    yamlencode({
      cluster = {
        network = { cni = { name = "none" } }
        proxy   = { disabled = true }
      }
    })
  ]
}

resource "talos_machine_configuration_apply" "init" {
  client_configuration        = var.client_configuration
  machine_configuration_input = data.talos_machine_configuration.cp.machine_configuration
  node                        = var.control_plane_ips[0]

  config_patches = [
    yamlencode({
      machine = {
        network = {
          hostname = var.control_plane_vm_names[0]
          interfaces = [
            {
              interface = "eth0"
              dhcp      = true
              vip = {
                ip = var.control_plane_vip
              }
            }
          ]
        }
        kubelet = {
          extraArgs = {
            hostname-override = var.control_plane_vm_names[0]
          }
        }
      }
    })
  ]
}

resource "terraform_data" "wait_for_node_ready" {
  depends_on = [talos_machine_configuration_apply.init]

  triggers_replace = {
    node = var.control_plane_ips[0]
  }

  provisioner "local-exec" {
    interpreter = ["/bin/bash", "-c"]
    command     = <<-EOT
      echo "Waiting for Talos node ${var.control_plane_ips[0]} to be ready for bootstrap..."
      for i in $(seq 1 60); do
        if timeout 5 bash -c "</dev/tcp/${var.control_plane_ips[0]}/50000" 2>/dev/null; then
          echo "Talos API responsive on attempt $i, waiting 30s for CRI and services..."
          sleep 30
          echo "Node should be ready for bootstrap."
          exit 0
        fi
        echo "Attempt $i/60: Talos API not ready on port 50000, retrying in 5s..."
        sleep 5
      done
      echo "Timeout waiting for Talos API after 300s"
      exit 1
    EOT
  }
}

resource "talos_machine_bootstrap" "init" {
  depends_on           = [terraform_data.wait_for_node_ready]
  node                 = var.control_plane_ips[0]
  endpoint             = var.control_plane_ips[0]
  client_configuration = var.client_configuration
}

resource "talos_machine_configuration_apply" "join_cp" {
  count                       = max(var.control_plane_count - 1, 0)
  client_configuration        = var.client_configuration
  machine_configuration_input = data.talos_machine_configuration.cp.machine_configuration
  node                        = var.control_plane_ips[count.index + 1]

  config_patches = [
    yamlencode({
      machine = {
        network = {
          hostname = var.control_plane_vm_names[count.index + 1]
          interfaces = [
            {
              interface = "eth0"
              dhcp      = true
              vip = {
                ip = var.control_plane_vip
              }
            }
          ]
        }
        kubelet = {
          extraArgs = {
            hostname-override = var.control_plane_vm_names[count.index + 1]
          }
        }
      }
    })
  ]

  depends_on = [talos_machine_bootstrap.init]
}

resource "talos_machine_configuration_apply" "join_workers" {
  count                       = var.worker_count
  client_configuration        = var.client_configuration
  machine_configuration_input = data.talos_machine_configuration.worker.machine_configuration
  node                        = var.worker_ips[count.index]

  endpoint = var.worker_ips[count.index]

  config_patches = [
    yamlencode({
      machine = {
        network = {
          hostname = var.worker_vm_names[count.index]
          interfaces = [
            {
              interface = "eth0"
              dhcp      = true
            }
          ]
        }
        # Synthetic failure-domain labels so pods with topologySpreadConstraints
        # on topology.kubernetes.io/zone (set automatically on EKS by the cloud
        # provider) can schedule on bare-metal Talos. Round-robin a/b/c across
        # workers — each physical host is its own failure domain on bare metal,
        # so the spread semantics still hold.
        nodeLabels = {
          "topology.kubernetes.io/zone" = "${var.cluster_name}-${["a", "b", "c"][count.index % 3]}"
        }
        kubelet = {
          extraArgs = {
            hostname-override = var.worker_vm_names[count.index]
          }
        }
      }
    })
  ]

  depends_on = [talos_machine_bootstrap.init]
}

resource "talos_cluster_kubeconfig" "kube" {
  depends_on           = [talos_machine_bootstrap.init]
  client_configuration = var.client_configuration
  node                 = var.control_plane_ips[0]
}
