# talosconfig-secret.tf
#
# Codifies the manual `aws secretsmanager create-secret` ceremony that
# seeds the talosconfig for the etcd-backup CronJob's ExternalSecret.
#
# IMPORTANT — value handling:
#   The secret VALUE (the talosconfig YAML) is provisioned out-of-band the
#   first time, via the operator running:
#     aws secretsmanager put-secret-value \
#       --secret-id <cluster>/talosconfig \
#       --secret-string file:///path/to/talosconfig
#
#   This Terraform resource declares the secret WRAPPER (name, description,
#   tags). No aws_secretsmanager_secret_version resource — TF never touches
#   the value, only the wrapper metadata.
#
# Recovery: if the secret is deleted or value drifts, re-seed via the same
# CLI command. The Terraform-managed wrapper will adopt it on next apply
# (declarative import block in the root module handles existing secrets).
#
# Refs: INFRA-1541, AWS SM seed step in onprem-safety Rule 6.

resource "aws_secretsmanager_secret" "talosconfig" {
  name        = "${var.cluster_name}/talosconfig"
  description = "Talosconfig for ${var.cluster_name} cluster — used by etcd-backup CronJob ExternalSecret to authenticate talosctl etcd snapshot. Source of truth: tfstate (recovery path in onprem-safety skill Rule 6)."

  recovery_window_in_days = 7

  tags = {
    Cluster = var.cluster_name
    Purpose = "etcd-backup"
    Owner   = "on-prem-platform"
  }
}

output "talosconfig_secret_arn" {
  description = "ARN of the talosconfig AWS Secrets Manager secret"
  value       = aws_secretsmanager_secret.talosconfig.arn
}

output "talosconfig_secret_name" {
  description = "Name of the talosconfig AWS Secrets Manager secret (matches ExternalSecret.spec.data[0].remoteRef.key)"
  value       = aws_secretsmanager_secret.talosconfig.name
}
