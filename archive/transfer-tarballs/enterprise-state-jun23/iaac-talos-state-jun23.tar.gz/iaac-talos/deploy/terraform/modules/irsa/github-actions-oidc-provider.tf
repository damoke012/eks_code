resource "aws_iam_openid_connect_provider" "github_actions" {
  url            = "https://token.actions.githubusercontent.com"
  client_id_list = ["sts.amazonaws.com"]
  # Modern AWS validates the X.509 chain to GitHub directly; the thumbprint
  # field is effectively vestigial. An all-zeros placeholder is the common
  # convention (avoids worrying about cert rotation invalidating us).
  thumbprint_list = ["0000000000000000000000000000000000000000"]

  tags = {
    Cluster = var.cluster_name
    Purpose = "GitHub Actions OIDC federation - account-wide"
  }
}
