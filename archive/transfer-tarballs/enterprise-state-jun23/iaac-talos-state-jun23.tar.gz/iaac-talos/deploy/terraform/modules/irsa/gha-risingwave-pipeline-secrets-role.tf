# gha-risingwave-pipeline-secrets-role.tf
#
# GHA OIDC role for variant-inc/risingwave-pipeline (on-prem platform team's
# fork of usxpressinc/risingwave-poc). Reads risingwave-2 secrets from SM
# during the SQL pipeline CICD workflow.
#
# Companion to gha-risingwave-poc-secrets-role.tf (Tim's prod equivalent
# pointing at /risingwave/*). Kept as separate roles so prod and CICD-env
# credentials are independently rotatable + auditable.
#
# Scope rationale:
#   - Subject:  ONLY variant-inc/risingwave-pipeline master branch.
#               Mirrors Tim's pattern. Blocks PRs from forks + other branches.
#               If we need to allow feature-branch testing, use workflow_dispatch
#               with explicit role override rather than broadening this scope.
#   - SM ARN:   ONLY op-usxpress-dev/risingwave-2/* (the per-env paths we
#               split on 2026-05-26). Does NOT include /risingwave/ (Tim's prod).

resource "aws_iam_role" "gha_risingwave_pipeline_secrets" {
  name        = "gha-${var.cluster_name}-risingwave-pipeline-secrets"
  description = "GHA OIDC role for variant-inc/risingwave-pipeline to read risingwave-2 secrets from SM"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Federated = aws_iam_openid_connect_provider.github_actions.arn }
      Action    = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          "token.actions.githubusercontent.com:aud" = "sts.amazonaws.com"
        }
        StringLike = {
          "token.actions.githubusercontent.com:sub" = "repo:variant-inc/risingwave-pipeline:ref:refs/heads/master"
        }
      }
    }]
  })

  tags = {
    Cluster = var.cluster_name
    Purpose = "GHA-OIDC for risingwave-pipeline workflows reading risingwave-2 SM secrets"
    Owner   = "on-prem-platform"
  }
}

resource "aws_iam_role_policy" "gha_risingwave_pipeline_secrets" {
  name = "read-risingwave-2-secrets"
  role = aws_iam_role.gha_risingwave_pipeline_secrets.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "ReadRisingWave2Secrets"
        Effect = "Allow"
        Action = [
          "secretsmanager:GetSecretValue",
          "secretsmanager:DescribeSecret"
        ]
        Resource = [
          "arn:aws:secretsmanager:us-east-2:700736442855:secret:op-usxpress-dev/risingwave-2/*"
        ]
      },
      {
        Sid      = "ListSecretsMetadata"
        Effect   = "Allow"
        Action   = "secretsmanager:ListSecrets"
        Resource = "*"
      }
    ]
  })
}
