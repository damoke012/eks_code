# risingwave-2-role.tf
#
# IRSA + S3 wiring for the on-prem RisingWave CICD environment (risingwave-2 ns).
#
# Companion to:
#   variant-inc/iaac-risingwave-2     - data plane manifests (Flux source)
#   variant-inc/iaac-risingwave-cicd  - architecture + ops runbook
#
# Trust policy is scoped to the SA defined in iaac-risingwave-2:
#   system:serviceaccount:risingwave-2:risingwave
#
# Resources here were initially created via AWS CLI on 2026-05-26 during
# the risingwave-2 build-out. Import blocks below adopt them into Terraform
# state without recreation.
#
# After this PR is applied:
#   - The orphaned managed policy `op-usxpress-dev-risingwave-2-s3` and its
#     attachment to the role become unused. Clean up via:
#       aws iam detach-role-policy --role-name op-usxpress-dev-risingwave-2 \
#         --policy-arn arn:aws:iam::700736442855:policy/op-usxpress-dev-risingwave-2-s3
#       aws iam delete-policy \
#         --policy-arn arn:aws:iam::700736442855:policy/op-usxpress-dev-risingwave-2-s3

# --- S3 bucket: RisingWave-2 Hummock state store ---
resource "aws_s3_bucket" "risingwave_2_data" {
  bucket = "risingwave-data-${var.cluster_name}"

  tags = {
    Cluster = var.cluster_name
    Purpose = "RisingWave-2 CICD state store - Hummock"
    Owner   = "on-prem-platform"
  }
}

resource "aws_s3_bucket_public_access_block" "risingwave_2_data" {
  bucket = aws_s3_bucket.risingwave_2_data.id

  block_public_acls       = true
  ignore_public_acls      = true
  block_public_policy     = true
  restrict_public_buckets = true
}

# --- IAM role: IRSA for risingwave-2 SA ---
resource "aws_iam_role" "risingwave_2" {
  name        = "${var.cluster_name}-risingwave-2"
  description = "IRSA role for risingwave-2 CICD env. Scoped to risingwave-2 ns and risingwave-data-* bucket."

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Federated = aws_iam_openid_connect_provider.irsa.arn }
      Action    = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          "${local.oidc_issuer_hostpath}:sub" = "system:serviceaccount:risingwave-2:risingwave"
          "${local.oidc_issuer_hostpath}:aud" = "sts.amazonaws.com"
        }
      }
    }]
  })

  tags = {
    Cluster = var.cluster_name
    Purpose = "RisingWave-2 CICD environment IRSA"
    Owner   = "on-prem-platform"
  }
}

# Inline policy: scoped S3 access for Hummock
resource "aws_iam_role_policy" "risingwave_2_s3" {
  name = "s3-hummock"
  role = aws_iam_role.risingwave_2.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "s3:GetObject",
          "s3:PutObject",
          "s3:DeleteObject",
          "s3:AbortMultipartUpload",
          "s3:ListMultipartUploadParts"
        ]
        Resource = "${aws_s3_bucket.risingwave_2_data.arn}/*"
      },
      {
        Effect = "Allow"
        Action = [
          "s3:ListBucket",
          "s3:GetBucketLocation"
        ]
        Resource = aws_s3_bucket.risingwave_2_data.arn
      }
    ]
  })
}

