output "oidc_issuer_url" {
  description = "Full OIDC issuer URL (used by Talos API server and IAM role trust policies)"
  value       = "https://${local.oidc_issuer_hostpath}"
}

output "oidc_provider_arn" {
  description = "ARN of the IAM OIDC Identity Provider (used in IAM role trust policies)"
  value       = aws_iam_openid_connect_provider.irsa.arn
}

output "oidc_bucket_arn" {
  description = "ARN of the S3 OIDC bucket"
  value       = aws_s3_bucket.oidc.arn
}

output "cloudfront_domain_name" {
  description = "CloudFront domain name serving OIDC discovery documents"
  value       = aws_cloudfront_distribution.oidc.domain_name
}

output "cloudfront_distribution_id" {
  description = "CloudFront distribution ID (used for cache invalidation)"
  value       = aws_cloudfront_distribution.oidc.id
}

output "oidc_bucket_name" {
  description = "S3 bucket name for OIDC discovery"
  value       = aws_s3_bucket.oidc.id
}

output "ecr_credentials_role_arn" {
  description = "ARN of the ECR credentials sync IAM role"
  value       = aws_iam_role.ecr_credentials.arn
}

output "external_secrets_role_arn" {
  description = "ARN of the External Secrets IAM role"
  value       = aws_iam_role.external_secrets.arn
}

output "octopus_worker_role_arn" {
  description = "ARN of the Octopus Worker IAM role (used by the on-prem octopus-worker StatefulSet via IRSA)"
  value       = aws_iam_role.octopus_worker.arn
}


output "extd_usxpress_io_role_arn" {
  description = "ARN of the on-prem external-dns source IAM role (chains into iaac-route53-zone in 155768531003)"
  value       = aws_iam_role.extd_usxpress_io.arn
}

output "gha_risingwave_poc_secrets_role_arn" {
  description = "ARN of the GHA OIDC role for risingwave-poc to read Secrets Manager secrets"
  value       = aws_iam_role.gha_risingwave_poc_secrets.arn
}

output "risingwave_2_role_arn" {
  description = "ARN of the RisingWave-2 CICD IRSA role"
  value       = aws_iam_role.risingwave_2.arn
}

output "risingwave_2_bucket_name" {
  description = "S3 bucket name for the RisingWave-2 CICD state store - Hummock"
  value       = aws_s3_bucket.risingwave_2_data.id
}

output "risingwave_2_bucket_arn" {
  description = "S3 bucket ARN for the RisingWave-2 CICD state store"
  value       = aws_s3_bucket.risingwave_2_data.arn
}

output "gha_risingwave_pipeline_secrets_role_arn" {
  description = "ARN of the GHA OIDC role for variant-inc/risingwave-pipeline to read risingwave-2 Secrets Manager secrets"
  value       = aws_iam_role.gha_risingwave_pipeline_secrets.arn
}


output "cert_manager_role_arn" {
  description = "ARN of the on-prem cert-manager source IAM role (chains into iaac-route53-zone for DNS-01 ACME challenges)"
  value       = aws_iam_role.cert_manager.arn
}


output "velero_role_arn" {
  description = "ARN of the Velero IRSA role"
  value       = aws_iam_role.velero.arn
}

output "velero_bucket_name" {
  description = "S3 bucket name for Velero backups"
  value       = aws_s3_bucket.velero.id
}

output "etcd_backup_role_arn" {
  description = "ARN of the etcd snapshot IRSA role"
  value       = aws_iam_role.etcd_backup.arn
}

output "etcd_snapshots_bucket_name" {
  description = "S3 bucket name for Talos etcd snapshots"
  value       = aws_s3_bucket.etcd_snapshots.id
}
