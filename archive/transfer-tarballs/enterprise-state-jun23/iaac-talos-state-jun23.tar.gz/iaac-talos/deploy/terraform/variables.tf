variable "vsphere_user" {
  description = "vSphere username"
  type        = string
}

variable "vsphere_password" {
  description = "vSphere password"
  type        = string
  sensitive   = true
}

variable "vsphere_server" {
  description = "vSphere server address"
  type        = string
}

variable "datacenter" {
  description = "vSphere datacenter name"
  type        = string
}

variable "datastore" {
  description = "vSphere datastore name (used for VM placement)"
  type        = string
}

variable "vm_cluster_name" {
  description = "The name of the vSphere cluster"
  type        = string
}

variable "vm_folder" {
  description = "vSphere folder path (relative to datacenter) to place the VMs in"
  type        = string
}

variable "network_name" {
  description = "vSphere network name to attach VM NICs to"
  type        = string
}

variable "content_library_name" {
  description = "Name of the vSphere Content Library containing the Talos OVA"
  type        = string
}

variable "content_library_item_name" {
  description = "Name of the Talos OVA item in the content library"
  type        = string
}

variable "control_plane_count" {
  description = "Number of control-plane nodes"
  type        = number
}

variable "worker_count" {
  description = "Number of worker nodes"
  type        = number
}

variable "cp_cpus" {
  description = "vCPU count for control-plane VMs"
  type        = number
}

variable "cp_memory_mb" {
  description = "Memory (MB) for control-plane VMs"
  type        = number
  default     = 8192
}

variable "worker_cpus" {
  description = "vCPU count for worker VMs"
  type        = number
}

variable "worker_memory_mb" {
  description = "Memory (MB) for worker VMs"
  type        = number
  default     = 12288
}

variable "disk_size_gb" {
  description = "Disk size (GB) for all Talos VMs"
  type        = number
}

variable "cluster_name" {
  description = "Name of the Talos cluster"
  type        = string
}

variable "control_plane_vip" {
  description = "Talos API endpoint (VIP) for the control plane; no scheme, no port."
  type        = string
}

variable "endpoint" {
  description = "Cluster API endpoint (full URL and optionally port)"
  type        = string
}

variable "talos_version" {
  description = "Talos Linux version to deploy"
  type        = string
}

variable "control_plane_name_prefix" {
  description = "Prefix for naming each control plane VM"
  type        = string
}

variable "worker_name_prefix" {
  description = "Prefix for naming each worker VM"
  type        = string
}

variable "cilium_chart_version" {
  description = "Cilium Helm chart version to install at bootstrap"
  type        = string
  default     = "1.18.2"
}

variable "cilium_cli_image" {
  description = "cilium CLI image for bootstrap job"
  type        = string
  default     = "quay.io/cilium/cilium-cli:v0.18.7"
}

variable "sleep_seconds" {
  description = "Pause after VM creation before reading IPs"
  type        = number
  default     = 60
}

variable "github_owner" {
  description = "GitHub owner/organization"
  type        = string
}

variable "github_repository" {
  description = "GitHub repository name"
  type        = string
}

variable "github_token" {
  description = "GitHub personal access token"
  type        = string
  sensitive   = true
}

variable "github_branch" {
  description = "Git branch"
  type        = string
}

variable "flux_target_path" {
  description = "Path in repo where Flux configs live"
  type        = string
}


# --- IRSA (IAM Roles for Service Accounts) ---

variable "enable_irsa" {
  description = "Enable IRSA configuration (OIDC issuer + SA signing keypair on control plane)"
  type        = bool
  default     = false
}

variable "aws_region" {
  description = "AWS region for IRSA resources (S3 OIDC bucket, IAM provider)"
  type        = string
  default     = "us-east-2"
}

variable "irsa_oidc_bucket_name" {
  description = "S3 bucket name for hosting OIDC discovery and JWKS documents"
  type        = string
  default     = ""
}
variable "irsa_role_arn" {
  description = "IAM role ARN to assume for IRSA resources (cross-account)"
  type        = string
  default     = ""
}

variable "tf_state_bucket" {
  description = "S3 bucket for MageRunner per-app terraform state. Passed to irsa module. Empty = skip on-prem IAM policies."
  type        = string
  default     = ""
}

variable "worker_ceph_disk_gb" {
  description = "Size (GB) of dedicated Ceph OSD disk per worker (0 = none). Workers only — CPs do not get this disk."
  type        = number
  default     = 50
}
