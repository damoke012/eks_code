if ($PSEdition -eq "Core") {
  $PSStyle.OutputRendering = "PlainText"
}

$ErrorActionPreference = "Stop"
$InformationPreference = "Continue"
$RootPath = Get-Location

Trap {
  Write-Error $_ -ErrorAction Continue
  Set-Location $RootPath
  exit 1
}

$OctopusParameters.GetEnumerator() `
| Where-Object { $_.Key -like "TF_*" } `
| ForEach-Object {
  $key = $_.Key
  $value = $_.Value
  try {
    [Environment]::SetEnvironmentVariable($key, $value)
  }
  catch {
    [Environment]::SetEnvironmentVariable($key, ($value | ConvertTo-Json))
  }
}

$env:S3_BUCKET           = $S3_BUCKET
$env:AWS_DEFAULT_REGION  = $AWS_DEFAULT_REGION
$env:TfDestroy           = $TfDestroy
$env:TF_STATE_KEY        = $TF_STATE_KEY

# ---------------------------------------------
Write-Host "`n[STEP] Running Terraform"

Set-Location terraform
tfswitch

ce terraform init -no-color `
  -backend-config="bucket=$S3_BUCKET" `
  -backend-config="key=$TF_STATE_KEY" `
  -backend-config="region=$AWS_DEFAULT_REGION" `
  -backend-config="encrypt=true"

if ($TfDestroy -eq "true") {
  # --- Pre-destroy: Clean drain cluster before destroying VMs ---
  # This prevents namespaces from getting stuck in Terminating on rebuild.
  Write-Host "`n[STEP] Pre-destroy: Draining cluster resources"
  try {
    $kubeconfigJson = ce terraform output -raw kubeconfig 2>$null
    if ($kubeconfigJson) {
      $kubeconfigFile = [System.IO.Path]::GetTempFileName()
      $kubeconfigJson | Out-File -FilePath $kubeconfigFile -Encoding utf8 -NoNewline
      $env:KUBECONFIG = $kubeconfigFile

      Write-Host "[PRE-DESTROY] Suspending all Flux kustomizations..."
      bash -c "kubectl get kustomizations -n flux-system -o name 2>/dev/null | xargs -r -I{} kubectl patch {} -n flux-system --type merge -p '{""spec"":{""suspend"":true}}' 2>/dev/null" 2>$null

      Write-Host "[PRE-DESTROY] Deleting all HelmReleases..."
      bash -c "kubectl delete helmreleases --all-namespaces --all --wait=false 2>/dev/null" 2>$null

      Write-Host "[PRE-DESTROY] Deleting all Flux kustomizations..."
      bash -c "kubectl delete kustomizations -n flux-system --all --wait=false 2>/dev/null" 2>$null

      Write-Host "[PRE-DESTROY] Deleting stale apiservices..."
      bash -c "kubectl delete apiservice v1beta1.external.metrics.k8s.io 2>/dev/null" 2>$null

      Write-Host "[PRE-DESTROY] Waiting for namespaces to terminate (up to 3 minutes)..."
      $waitSeconds = 180
      $elapsed = 0
      while ($elapsed -lt $waitSeconds) {
        $terminating = bash -c "kubectl get ns 2>/dev/null | grep Terminating | wc -l" 2>$null
        if ([int]$terminating -eq 0) {
          Write-Host "[PRE-DESTROY] All namespaces clean"
          break
        }
        Write-Host "[PRE-DESTROY] $terminating namespaces still terminating, waiting..."
        Start-Sleep -Seconds 15
        $elapsed += 15
      }

      # Force-finalize any remaining stuck namespaces
      $stuckNamespaces = bash -c "kubectl get ns 2>/dev/null | grep Terminating | awk '{print \$1}'" 2>$null
      if ($stuckNamespaces) {
        Write-Host "[PRE-DESTROY] Force-finalizing stuck namespaces..."
        foreach ($ns in ($stuckNamespaces -split "`n" | Where-Object { $_ })) {
          bash -c "kubectl get namespace $ns -o json 2>/dev/null | python3 -c 'import json,sys; ns=json.loads(sys.stdin.read()); ns[\"spec\"][\"finalizers\"]=[]; print(json.dumps(ns))' | kubectl replace --raw '/api/v1/namespaces/$ns/finalize' -f - 2>/dev/null" 2>$null
          Write-Host "[PRE-DESTROY] Force-finalized $ns"
        }
      }

      Write-Host "[PRE-DESTROY] Running flux uninstall..."
      bash -c "flux uninstall --silent 2>/dev/null" 2>$null

      Remove-Item -Path $kubeconfigFile -Force -ErrorAction SilentlyContinue
      $env:KUBECONFIG = $null
      Write-Host "[PRE-DESTROY] Cluster drain complete"
    }
    else {
      Write-Host "[PRE-DESTROY] No kubeconfig in state, skipping drain (fresh destroy)"
    }
  }
  catch {
    Write-Host "[PRE-DESTROY] Drain failed (cluster may be unreachable), continuing with destroy: $_"
  }

  ce terraform plan -destroy -out=tfplan -input=false -no-color
  ce terraform apply tfplan
}
else {
  ce terraform plan -out=tfplan -input=false -no-color

  if ($TfApply -eq "true") {
    ce terraform apply tfplan
    Write-Host "[STEP] Capturing Terraform outputs..."
    $terraformOutputs = ce terraform output -json | ConvertFrom-Json | ConvertTo-Yaml
    if (!(Test-Path "../../outputs")) {
      New-Item -ItemType Directory -Path "../../outputs"
    }

    $terraformOutputs | Out-File "../../outputs/terraform_outputs.yml" -Encoding utf8
    Write-Host "[STEP] Uploading outputs as Octopus artifact..."
    New-OctopusArtifact -Path "../../outputs/terraform_outputs.yml"

    # --- Post-apply: Validate SSM parameters for MageRunner eks-data fallback ---
    # The eks-data Terraform module on the fork branch (feature/onprem-support)
    # reads cluster details from SSM when use_eks_api=false. This step asserts
    # the contract: all 3 SSM parameters must exist and be non-empty after apply.
    # Fails fast if missing/empty so a broken cluster never gets marked successful.
    Write-Host "`n[STEP] Post-apply: Validating SSM parameters for eks-data fallback"
    $clusterName = $env:TF_VAR_cluster_name
    $ssmRegion = if ($env:TF_VAR_aws_region) { $env:TF_VAR_aws_region } else { "us-east-2" }
    $irsaRoleArn = $env:TF_VAR_irsa_role_arn
    $ssmParams = @(
      "/clusters/$clusterName/endpoint",
      "/clusters/$clusterName/certificate_authority",
      "/clusters/$clusterName/oidc_issuer"
    )
    # SSM params live in the USX-Dev account (created by Terraform AWS provider).
    # Assume the IRSA role first if var.irsa_role_arn is set (no-op when terraform runs directly in USX-Dev).
    $assumeCmd = ""
    if ($irsaRoleArn) {
      $assumeCmd = "CREDS=`$(aws sts assume-role --role-arn '$irsaRoleArn' --role-session-name 'ssm-validate' --output json) && export AWS_ACCESS_KEY_ID=`$(echo `$CREDS | python3 -c 'import sys,json; print(json.load(sys.stdin)[\""Credentials\""][\""AccessKeyId\""])') && export AWS_SECRET_ACCESS_KEY=`$(echo `$CREDS | python3 -c 'import sys,json; print(json.load(sys.stdin)[\""Credentials\""][\""SecretAccessKey\""])') && export AWS_SESSION_TOKEN=`$(echo `$CREDS | python3 -c 'import sys,json; print(json.load(sys.stdin)[\""Credentials\""][\""SessionToken\""])') && "
    }
    foreach ($param in $ssmParams) {
      Write-Host "[SSM-VALIDATE] Checking $param ..."
      $value = bash -c "$assumeCmd aws ssm get-parameter --name '$param' --region '$ssmRegion' --query 'Parameter.Value' --output text 2>/dev/null"
      if ([string]::IsNullOrWhiteSpace($value) -or $value -eq "None") {
        Write-Error "[SSM-VALIDATE] FAIL: SSM parameter '$param' is missing or empty in region '$ssmRegion'. eks-data fallback will not work for MageRunner."
        exit 1
      }
      $preview = if ($value.Length -gt 60) { $value.Substring(0, 60) + "..." } else { $value }
      Write-Host "[SSM-VALIDATE] OK: $param = $preview"
    }
    Write-Host "[SSM-VALIDATE] All 3 SSM parameters validated successfully"

    # --- Post-apply: Recover from stuck Terminating namespaces ---
    # When an apply replaces the Talos cluster (cert rotation, machine config
    # change, etc.) without going through TfDestroy, the OLD cluster's namespaces
    # can land Terminating in the NEW cluster. Root cause: stale
    # external.metrics.k8s.io/v1beta1 apiservice blocks namespace finalization.
    # This block detects stuck namespaces, deletes the stale apiservice, force-
    # finalizes them, then kicks Flux to re-reconcile so kustomizations recover.
    Write-Host "`n[STEP] Post-apply: Checking for stuck Terminating namespaces"
    $savedErrorAction = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
      $kubeconfigJson = terraform output -raw kubeconfig 2>$null
      if ($kubeconfigJson) {
        $kubeconfigFile = [System.IO.Path]::GetTempFileName()
        $kubeconfigJson | Out-File -FilePath $kubeconfigFile -Encoding utf8 -NoNewline
        $env:KUBECONFIG = $kubeconfigFile

        # Wait briefly for any in-flight terminations to settle
        Start-Sleep -Seconds 15

        $stuckNs = bash -c "kubectl get ns 2>/dev/null | grep Terminating | awk '{print \$1}'" 2>$null
        if ($stuckNs) {
          Write-Host "[NS-RECOVERY] Detected stuck Terminating namespaces:"
          Write-Host "$stuckNs"

          Write-Host "[NS-RECOVERY] Deleting stale external.metrics apiservice..."
          bash -c "kubectl delete apiservice v1beta1.external.metrics.k8s.io 2>/dev/null" 2>$null

          Write-Host "[NS-RECOVERY] Force-finalizing stuck namespaces..."
          foreach ($ns in ($stuckNs -split "`n" | Where-Object { $_ })) {
            bash -c "kubectl get namespace $ns -o json 2>/dev/null | python3 -c 'import json,sys; n=json.loads(sys.stdin.read()); n[\""spec\""][\""finalizers\""]=[]; print(json.dumps(n))' | kubectl replace --raw '/api/v1/namespaces/$ns/finalize' -f - >/dev/null 2>&1" 2>$null
            Write-Host "[NS-RECOVERY] Force-finalized $ns"
          }

          Write-Host "[NS-RECOVERY] Waiting 20 seconds for Kubernetes to settle..."
          Start-Sleep -Seconds 20

          Write-Host "[NS-RECOVERY] Triggering Flux reconciliation for all kustomizations..."
          $allKs = bash -c "kubectl get kustomizations -n flux-system -o jsonpath='{.items[*].metadata.name}' 2>/dev/null" 2>$null
          if ($allKs) {
            foreach ($k in ($allKs -split " " | Where-Object { $_ -and $_ -ne "flux-system" })) {
              bash -c "flux reconcile kustomization $k --timeout=60s >/dev/null 2>&1" 2>$null
              Write-Host "[NS-RECOVERY] Reconciled $k"
            }
          }
          Write-Host "[NS-RECOVERY] Recovery complete"
        }
        else {
          Write-Host "[NS-RECOVERY] No stuck namespaces detected, skipping"
        }

        Remove-Item -Path $kubeconfigFile -Force -ErrorAction SilentlyContinue
        $env:KUBECONFIG = $null
      }
    }
    catch {
      Write-Host "[NS-RECOVERY] Recovery check failed (non-fatal): $_"
    }
    finally {
      $ErrorActionPreference = $savedErrorAction
    }

    # --- Post-apply: Health check for istiod cert timing ---
    # Istiod may start before cert-manager issues valid certs, causing PEM decode
    # errors. This check waits for the platform stack, detects the error, and
    # auto-restarts istiod if needed.
    Write-Host "`n[STEP] Post-apply: Running platform health checks"
    # Temporarily allow non-zero exit codes — health checks are best-effort
    $savedErrorAction = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
      $kubeconfigJson = terraform output -raw kubeconfig 2>$null
      if ($kubeconfigJson) {
        $kubeconfigFile = [System.IO.Path]::GetTempFileName()
        $kubeconfigJson | Out-File -FilePath $kubeconfigFile -Encoding utf8 -NoNewline
        $env:KUBECONFIG = $kubeconfigFile

        # Wait for istiod pod to exist (up to 20 minutes)
        # Flux needs 10-15 min to deploy: cert-manager -> issuers -> istio-csr -> istiod
        Write-Host "[HEALTH] Waiting for istiod deployment (up to 20 minutes)..."
        $maxWait = 1200
        $elapsed = 0
        while ($elapsed -lt $maxWait) {
          $istiodReady = bash -c "kubectl get deployment istiod -n istio-system -o jsonpath='{.status.readyReplicas}' 2>/dev/null" 2>$null
          if ($istiodReady -ge 1) {
            Write-Host "[HEALTH] istiod deployment is ready"
            break
          }
          Start-Sleep -Seconds 30
          $elapsed += 30
          Write-Host "[HEALTH] Waiting for istiod... ($elapsed/$maxWait seconds)"
        }

        if ($elapsed -ge $maxWait) {
          Write-Host "[HEALTH] istiod did not become ready in time, skipping health check"
        }
        else {
          # Wait 60 seconds for cert-manager to issue certs, then check for PEM error
          Write-Host "[HEALTH] Waiting 60 seconds for cert issuance..."
          Start-Sleep -Seconds 60

          $pemError = bash -c "kubectl logs -n istio-system -l app=istiod --tail=50 2>/dev/null | grep -c 'could not decode pem'" 2>$null
          if ([int]$pemError -gt 0) {
            Write-Host "[HEALTH] Detected PEM decode error in istiod, restarting..."
            bash -c "kubectl rollout restart deployment istiod -n istio-system 2>/dev/null" 2>$null
            Write-Host "[HEALTH] istiod restart triggered, waiting for rollout..."
            bash -c "kubectl rollout status deployment istiod -n istio-system --timeout=120s 2>/dev/null" 2>$null
            Write-Host "[HEALTH] istiod restarted successfully"

            # Wait for ztunnel to become ready
            Write-Host "[HEALTH] Waiting for ztunnel pods to become ready..."
            Start-Sleep -Seconds 30
            $ztunnelReady = bash -c "kubectl get pods -n istio-system -l app=ztunnel -o jsonpath='{.items[*].status.containerStatuses[0].ready}' 2>/dev/null" 2>$null
            Write-Host "[HEALTH] ztunnel status: $ztunnelReady"
          }
          else {
            Write-Host "[HEALTH] istiod certs are healthy, no restart needed"
          }
        }

        Remove-Item -Path $kubeconfigFile -Force -ErrorAction SilentlyContinue
        $env:KUBECONFIG = $null
      }
    }
    catch {
      Write-Host "[HEALTH] Health check failed (non-fatal): $_"
    }
    finally {
      $ErrorActionPreference = $savedErrorAction
    }
    Write-Host "[STEP] Platform health checks complete"
  }
}

Set-Location $RootPath
Write-Host "`n Terraform Talos Cluster Deployment Complete"

exit 0
