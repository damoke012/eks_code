#!/usr/bin/env bash
# Applies cross-cluster ESO RBAC manifests to cloud EKS. Idempotent.
# Refuses to run against any context whose cluster name looks on-prem.
set -euo pipefail

CTX="${CONTEXT:-cloud-usxpress-dev}"
MODE="${1:-dry-run}"
RBAC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/cloud-rbac"

CLUSTER=$(kubectl config view -o jsonpath="{.contexts[?(@.name=='${CTX}')].context.cluster}")
[[ -z "$CLUSTER" ]] && { echo "ERROR: kubectl context '$CTX' missing"; exit 1; }
case "$CLUSTER" in *op-usxpress*|op-usxpress-*)
  echo "ERROR: '$CLUSTER' looks on-prem. This script is cloud-only."; exit 1 ;;
esac

echo "=== context: $CTX  cluster: $CLUSTER  mode: $MODE"
for f in "$RBAC_DIR"/*.yaml; do echo "  - $(basename "$f")"; done

case "$MODE" in
  dry-run|--dry-run)
    for f in "$RBAC_DIR"/*.yaml; do
      kubectl --context="$CTX" apply --dry-run=server -f "$f"
    done ;;
  diff|--diff)
    for f in "$RBAC_DIR"/*.yaml; do
      kubectl --context="$CTX" diff -f "$f" || true
    done ;;
  apply|--apply)
    for f in "$RBAC_DIR"/*.yaml; do
      kubectl --context="$CTX" apply -f "$f"
    done
    # Sanity: yes/no/no/no expected pattern in geoservices ns
    SA="system:serviceaccount:geoservices:onprem-secret-reader"
    echo
    echo "=== RBAC sanity (expect: yes / no / no / no)"
    kubectl --context="$CTX" auth can-i list secrets   -n geoservices --as="$SA"
    kubectl --context="$CTX" auth can-i create secrets -n geoservices --as="$SA"
    kubectl --context="$CTX" auth can-i list pods      -n geoservices --as="$SA"
    kubectl --context="$CTX" auth can-i list secrets   -n kube-system --as="$SA"
    ;;
  *) echo "Usage: $0 [dry-run|diff|apply]"; exit 2 ;;
esac
