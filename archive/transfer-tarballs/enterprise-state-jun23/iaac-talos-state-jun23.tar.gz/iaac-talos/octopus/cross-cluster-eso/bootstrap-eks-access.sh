#!/usr/bin/env bash
# Creates an EKS Access Entry on cloud cluster usxpress-dev mapping the GHA
# OIDC role (ONPREM_BOOTSTRAP_ROLE_ARN_DEV) to a namespace-scoped Edit policy.
# Idempotent: skips if entry already exists; updates policy if scope changed.
set -euo pipefail

CLUSTER="${CLUSTER:-usxpress-dev}"
REGION="${REGION:-us-east-2}"
ROLE_ARN="${ROLE_ARN:?must set ROLE_ARN to the IAM role to grant kubectl access}"
NS="${NS:-geoservices}"

echo "=== EKS Access Entry bootstrap"
echo "  cluster:   $CLUSTER ($REGION)"
echo "  role:      $ROLE_ARN"
echo "  scope ns:  $NS"

# Create the access entry (idempotent — ResourceInUseException is fine)
if aws eks describe-access-entry --cluster-name "$CLUSTER" --region "$REGION" \
     --principal-arn "$ROLE_ARN" >/dev/null 2>&1; then
  echo "  access entry already exists for $ROLE_ARN — skipping create"
else
  aws eks create-access-entry --cluster-name "$CLUSTER" --region "$REGION" \
    --principal-arn "$ROLE_ARN" --type STANDARD
  echo "  access entry created"
fi

# Associate AmazonEKSEditPolicy scoped to the target namespace.
# Edit policy lets us create/update Role + RoleBinding + ServiceAccount + Secret
# in the named ns. Cannot escalate beyond the ns.
POLICY_ARN="arn:aws:eks::aws:cluster-access-policy/AmazonEKSEditPolicy"

# List current associations; skip if already bound at namespace scope
EXISTING=$(aws eks list-associated-access-policies --cluster-name "$CLUSTER" --region "$REGION" \
  --principal-arn "$ROLE_ARN" --query "associatedAccessPolicies[?policyArn=='$POLICY_ARN']" --output json)

if [[ "$EXISTING" != "[]" ]]; then
  echo "  edit policy already associated — skipping"
else
  aws eks associate-access-policy --cluster-name "$CLUSTER" --region "$REGION" \
    --principal-arn "$ROLE_ARN" --policy-arn "$POLICY_ARN" \
    --access-scope "type=namespace,namespaces=$NS"
  echo "  edit policy associated, scoped to namespace=$NS"
fi

echo
echo "Verify with:"
echo "  aws eks list-associated-access-policies --cluster-name $CLUSTER --region $REGION --principal-arn $ROLE_ARN"
