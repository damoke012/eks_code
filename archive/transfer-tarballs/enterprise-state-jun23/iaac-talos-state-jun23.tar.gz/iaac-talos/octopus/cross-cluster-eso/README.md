# Cross-Cluster ESO Bridge — cloud-side RBAC management

Owns the lifecycle of read-only RBAC tuples on cloud EKS that on-prem
ExternalSecrets Operator uses to mirror cloud-created secrets into the on-prem
cluster (kafka creds, mongo Atlas X.509 certs, ...).

## Architecture

on-prem ESO  ──Bearer token──>  cloud EKS API
│
└── geoservices ns
├── onprem-secret-reader  (SA, read-only)
├── onprem-secret-reader  (Role: secrets get/list/watch)
├── onprem-secret-reader  (RoleBinding)
└── onprem-secret-reader-token  (long-lived SA token)



## Files

- `cloud-rbac/onprem-reader-<ns>.yaml` — RBAC manifests (one per bridged ns)
- `apply-cloud-rbac.sh` — local + GHA applier with dry-run/diff/apply modes
- `bootstrap-eks-access.sh` — one-time-per-cluster: creates EKS Access Entry + Edit policy

## Workflows

- `.github/workflows/cross-cluster-eso-bootstrap.yaml` — runs `bootstrap-eks-access.sh`. Manual dispatch only. Idempotent.
- `.github/workflows/cross-cluster-eso-apply.yaml` — runs `apply-cloud-rbac.sh`. Auto dry-run on push to `cloud-rbac/**`; manual dispatch for diff/apply.

## Bootstrap chain (one-time per cluster)

1. **Extend `apply-bootstrap-perms.sh`** to include EKS Access Entry permissions on the `ONPREM_BOOTSTRAP_ROLE_ARN_DEV` IAM role. Re-run via existing `onprem-account-bootstrap.yaml` workflow.
2. **Run `cross-cluster-eso-bootstrap.yaml`** once. Creates EKS Access Entry on cloud cluster.
3. **Run `cross-cluster-eso-apply.yaml`** with mode=apply. Applies the per-ns RBAC manifests.

## Adding a new bridged namespace

1. Copy `cloud-rbac/onprem-reader-geoservices.yaml` → `onprem-reader-<newns>.yaml`, replace `geoservices` with `<newns>`.
2. Re-run `cross-cluster-eso-bootstrap.yaml` with NS=`<newns>` to extend the Access Entry's scope (or add a second association with new ns).
3. Re-run `cross-cluster-eso-apply.yaml` with mode=apply. New manifests applied.
