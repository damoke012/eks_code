#!/usr/bin/env bash
# ONE-TIME admin run: extends the ONPREM_BOOTSTRAP_ROLE_ARN_DEV (used by
# variant-inc/iaac-talos GHA OIDC) with EKS Access Entry permissions on
# cloud cluster usxpress-dev. After this runs once, the cross-cluster-eso
# bootstrap + apply workflows can run via GHA without further admin.
#
# Run with cloud admin SSO (typically your personal AWS_PROFILE=usx-dev):
#   AWS_PROFILE=usx-dev bash extend-bootstrap-role-eks-perms.sh
#
# Idempotent.
set -euo pipefail

ROLE_NAME="${ROLE_NAME:-github-actions-onprem-bootstrap}"
REGION="${REGION:-us-east-2}"
CLUSTER="${CLUSTER:-usxpress-dev}"
POLICY_NAME="cross-cluster-eso-eks-perms"

ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
echo "Target account:  $ACCOUNT"
echo "Target role:     $ROLE_NAME"
echo "EKS cluster:     $CLUSTER ($REGION)"

if ! aws iam get-role --role-name "$ROLE_NAME" >/dev/null 2>&1; then
  echo "ERROR: role $ROLE_NAME not found in account $ACCOUNT."
  echo "  This script extends the EXISTING bootstrap role used by GHA OIDC."
  echo "  If your bootstrap role has a different name, set ROLE_NAME=..."
  exit 1
fi

POLICY=$(cat <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "EKSDescribeForKubeconfig",
      "Effect": "Allow",
      "Action": ["eks:DescribeCluster"],
      "Resource": "arn:aws:eks:${REGION}:${ACCOUNT}:cluster/${CLUSTER}"
    },
    {
      "Sid": "EKSAccessEntryManagement",
      "Effect": "Allow",
      "Action": [
        "eks:CreateAccessEntry",
        "eks:DescribeAccessEntry",
        "eks:ListAccessEntries",
        "eks:UpdateAccessEntry",
        "eks:DeleteAccessEntry",
        "eks:AssociateAccessPolicy",
        "eks:DisassociateAccessPolicy",
        "eks:ListAssociatedAccessPolicies"
      ],
      "Resource": [
        "arn:aws:eks:${REGION}:${ACCOUNT}:cluster/${CLUSTER}",
        "arn:aws:eks:${REGION}:${ACCOUNT}:access-entry/${CLUSTER}/*"
      ]
    }
  ]
}
EOF
)

echo
echo "Attaching $POLICY_NAME inline policy to $ROLE_NAME ..."
aws iam put-role-policy \
  --role-name "$ROLE_NAME" \
  --policy-name "$POLICY_NAME" \
  --policy-document "$POLICY"
echo "  [ok] $POLICY_NAME applied"

echo
echo "Current inline policies on $ROLE_NAME:"
aws iam list-role-policies --role-name "$ROLE_NAME" --output text

echo
echo "Done. The bootstrap role can now create/manage EKS Access Entries on $CLUSTER."
echo "Next: commit + push, then dispatch the cross-cluster-eso-bootstrap workflow."
