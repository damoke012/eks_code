#!/usr/bin/env bash
# Grants the on-prem Octopus worker role (iaac-octopus-worker-op-usxpress-dev)
# the minimum perms needed to apply RBAC manifests to cloud EKS in scoped
# namespaces:
#   1. IAM:    eks:DescribeCluster on the cloud cluster (so update-kubeconfig works)
#   2. EKS:    Access Entry mapping the worker role to AmazonEKSAdminPolicy
#              scoped to the named namespace(s)
#
# This is the MVP 1 path. MVP 2 will replace with a dedicated GHA OIDC role.
#
# Run with cloud admin SSO once per account/cluster:
#   AWS_PROFILE=usx-dev bash bootstrap-worker-eks-access.sh
#
# Idempotent. Re-run safely. To bridge a new namespace, set NS=<name> and re-run.
set -euo pipefail

ROLE_NAME="${ROLE_NAME:-iaac-octopus-worker-op-usxpress-dev}"
CLUSTER="${CLUSTER:-usxpress-dev}"
REGION="${REGION:-us-east-2}"
NS="${NS:-geoservices}"

ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
ROLE_ARN="arn:aws:iam::${ACCOUNT}:role/${ROLE_NAME}"
CLUSTER_ARN="arn:aws:eks:${REGION}:${ACCOUNT}:cluster/${CLUSTER}"

echo "Account:   $ACCOUNT"
echo "Worker:    $ROLE_NAME ($ROLE_ARN)"
echo "Cluster:   $CLUSTER ($REGION)"
echo "Scope ns:  $NS"
echo

if ! aws iam get-role --role-name "$ROLE_NAME" >/dev/null 2>&1; then
  echo "ERROR: role $ROLE_NAME not found in account $ACCOUNT"
  exit 1
fi

# 1. IAM: eks:DescribeCluster
echo "[1/3] Attaching eks-describe-${CLUSTER} inline policy to ${ROLE_NAME} ..."
aws iam put-role-policy \
  --role-name "$ROLE_NAME" \
  --policy-name "eks-describe-${CLUSTER}" \
  --policy-document "{
    \"Version\": \"2012-10-17\",
    \"Statement\": [{
      \"Sid\": \"DescribeForKubeconfig\",
      \"Effect\": \"Allow\",
      \"Action\": [\"eks:DescribeCluster\"],
      \"Resource\": \"${CLUSTER_ARN}\"
    }]
  }"
echo "   [ok]"
echo

# 2. EKS Access Entry (idempotent)
echo "[2/3] Ensuring EKS Access Entry for ${ROLE_ARN} on ${CLUSTER} ..."
if aws eks describe-access-entry --cluster-name "$CLUSTER" --region "$REGION" \
     --principal-arn "$ROLE_ARN" >/dev/null 2>&1; then
  echo "   already exists - skipping create"
else
  aws eks create-access-entry --cluster-name "$CLUSTER" --region "$REGION" \
    --principal-arn "$ROLE_ARN" --type STANDARD
  echo "   [created]"
fi

# 3. Associate Admin policy (namespace-scoped — admin within ns only, includes RBAC) at namespace scope (idempotent)
POLICY_ARN="arn:aws:eks::aws:cluster-access-policy/AmazonEKSAdminPolicy"
echo
echo "[3/3] Ensuring EKS Admin policy (namespace-scoped — admin within ns only, includes RBAC) assoc scoped to namespace=${NS} ..."

EXISTING=$(aws eks list-associated-access-policies --cluster-name "$CLUSTER" --region "$REGION" \
  --principal-arn "$ROLE_ARN" \
  --query "associatedAccessPolicies[?policyArn=='$POLICY_ARN' && accessScope.type=='namespace' && contains(accessScope.namespaces, \`$NS\`)]" \
  --output json)

if [[ "$EXISTING" != "[]" ]]; then
  echo "   policy already associated for namespace=${NS} - skipping"
else
  aws eks associate-access-policy --cluster-name "$CLUSTER" --region "$REGION" \
    --principal-arn "$ROLE_ARN" --policy-arn "$POLICY_ARN" \
    --access-scope "type=namespace,namespaces=${NS}"
  echo "   [associated]"
fi

echo
echo "=== Done. ${ROLE_NAME} can now create RBAC in namespace=${NS} on ${CLUSTER}."
echo
echo "Verify:"
echo "  aws eks list-associated-access-policies --cluster-name $CLUSTER --region $REGION --principal-arn $ROLE_ARN"
