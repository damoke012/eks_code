#!/usr/bin/env python3
"""Patch package-reference FeedIds in OnPremise project deployment processes.

Idempotent. Hard-locked to OnPremise (Spaces-302); cloud untouched.
"""
import argparse, json, os, sys, urllib.error, urllib.parse, urllib.request

OCTO = "https://octopus.usxpress.io"
SPACE = "Spaces-302"

PACKAGE_FEED_FIXES = {
    "terraform": (
        "Feeds-1587",
        "dx-packages20250326072200906200000001/terraform-variant-apps/terraform-variant-apps",
    ),
}


def api(method, path, body=None, key=None):
    req = urllib.request.Request(
        f"{OCTO}{path}",
        data=json.dumps(body).encode() if body is not None else None,
        headers={"X-Octopus-ApiKey": key, "Content-Type": "application/json"},
        method=method,
    )
    try:
        with urllib.request.urlopen(req) as r:
            data = r.read()
            return json.loads(data) if data else {}
    except urllib.error.HTTPError as e:
        print(f"  HTTP {e.code} on {method} {path}: {e.read().decode()[:300]}", file=sys.stderr)
        return None


def find_project(name, key):
    d = api("GET", f"/api/{SPACE}/projects?partialName={urllib.parse.quote(name)}&take=10", key=key)
    for p in (d or {}).get("Items", []):
        if p["Name"] == name:
            return p
    return None


def patch_project(name, key):
    print(f"\n--- {name} ---")
    proj = find_project(name, key)
    if not proj:
        print(f"  NOT FOUND in OnPremise space")
        return False

    process = api("GET", f"/api/{SPACE}/projects/{proj['Id']}/deploymentprocesses", key=key)
    if not process:
        return False

    changed = False
    for step in process.get("Steps", []):
        for action in step.get("Actions", []):
            for pkg in action.get("Packages", []):
                ref = pkg.get("Name", "")
                if ref not in PACKAGE_FEED_FIXES:
                    continue
                want_feed, want_id = PACKAGE_FEED_FIXES[ref]
                if pkg.get("FeedId") == want_feed and pkg.get("PackageId") == want_id:
                    print(f"  SKIP {ref}: already correct")
                    continue
                print(f"  PATCH {ref}: feed {pkg.get('FeedId')} -> {want_feed}, id {pkg.get('PackageId')} -> {want_id}")
                pkg["FeedId"] = want_feed
                pkg["PackageId"] = want_id
                changed = True

    # Space-name template fix: cloud publishes packages under USXpress/... in S3,
    # but Bento brings in PackageIds templated with #{Octopus.Space.Name} which
    # resolves to "OnPremise" on-prem. Replace with literal "USXpress".
    for step in process.get("Steps", []):
        for action in step.get("Actions", []):
            for pkg in action.get("Packages", []):
                pkg_id = pkg.get("PackageId", "")
                if "#{Octopus.Space.Name}" in pkg_id:
                    new_id = pkg_id.replace("#{Octopus.Space.Name}", "USXpress")
                    print(f"  PATCH {pkg.get('Name')}: PackageId Space.Name template -> USXpress")
                    pkg["PackageId"] = new_id
                    changed = True

    if not changed:
        print(f"  no changes needed")
        return True

    result = api("PUT", f"/api/{SPACE}/deploymentprocesses/{process['Id']}", body=process, key=key)
    if not result:
        print(f"  ERROR: PUT failed")
        return False
    print(f"  UPDATED (new version {result.get('Version')})")
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", "-p", default="brands-api")
    ap.add_argument("--all", action="store_true")
    args = ap.parse_args()
    key = os.environ.get("OCTOPUS_API_KEY")
    if not key:
        sys.exit("OCTOPUS_API_KEY not set")
    projects = ["brands-api","geoenrichment-sync-handler","attrition-api","io-notifications-handler","trailers-api","safetylytx-video-api"] if args.all else [args.project]
    fail = sum(0 if patch_project(n, key) else 1 for n in projects)
    sys.exit(1 if fail else 0)


if __name__ == "__main__":
    main()
