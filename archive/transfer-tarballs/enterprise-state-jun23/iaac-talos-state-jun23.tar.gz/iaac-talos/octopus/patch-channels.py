#!/usr/bin/env python3
"""Idempotent channel-rule patches for OnPremise project channels.

Bento doesn't import channel rules from cloud (they don't exist in cloud), so
the on-prem fork-pinning rule must be created here. The rule pins the `mage`
package reference on the `feature` channel to versions tagged
`^feature-onprem-support`, ensuring on-prem deploys can't accidentally pick
stock cloud `mage` versions.

Idempotent. Hard-locked to OnPremise (Spaces-302); cloud channels untouched.
"""
import argparse, json, os, sys, urllib.error, urllib.parse, urllib.request

OCTO = "https://octopus.usxpress.io"
SPACE = "Spaces-302"
CHANNEL_NAME = "feature"

# Rule template: tag-pin mage package on DX-Apply action
RULE_TAG = "^feature-onprem-support"
RULE_ACTION = "DX-Apply"
RULE_PACKAGE_REF = "mage"


def api(method, path, body=None, key=None):
    req = urllib.request.Request(
        f"{OCTO}{path}",
        data=json.dumps(body).encode() if body is not None else None,
        headers={"X-Octopus-ApiKey": key, "Content-Type": "application/json"},
        method=method,
    )
    try:
        with urllib.request.urlopen(req) as r:
            data = r.read()
            return json.loads(data) if data else {}
    except urllib.error.HTTPError as e:
        print(f"  HTTP {e.code} on {method} {path}: {e.read().decode()[:300]}", file=sys.stderr)
        return None


def find_project(name, key):
    d = api("GET", f"/api/{SPACE}/projects?partialName={urllib.parse.quote(name)}&take=10", key=key)
    for p in (d or {}).get("Items", []):
        if p["Name"] == name:
            return p
    return None


def find_channel(project_id, name, key):
    d = api("GET", f"/api/{SPACE}/projects/{project_id}/channels?take=20", key=key)
    for c in (d or {}).get("Items", []):
        if c["Name"] == name:
            return c
    return None


def patch_project(project_name, key):
    print(f"\n--- {project_name} ---")
    proj = find_project(project_name, key)
    if not proj:
        print(f"  NOT FOUND in OnPremise space")
        return False

    ch = find_channel(proj["Id"], CHANNEL_NAME, key)
    if not ch:
        print(f"  ERROR: channel {CHANNEL_NAME!r} not found")
        return False

    desired_rule = {
        "VersionRange": "",
        "Tag": RULE_TAG,
        "Actions": [RULE_ACTION],
        "ActionPackages": [
            {"DeploymentAction": RULE_ACTION, "PackageReference": RULE_PACKAGE_REF}
        ],
    }

    existing = ch.get("Rules", [])
    matches = [
        r for r in existing
        if r.get("Tag") == RULE_TAG
        and any(
            ap.get("DeploymentAction") == RULE_ACTION
            and ap.get("PackageReference") == RULE_PACKAGE_REF
            for ap in r.get("ActionPackages", [])
        )
    ]
    if matches:
        print(f"  SKIP: rule already present (tag={RULE_TAG} ref={RULE_PACKAGE_REF})")
        return True

    # If a rule with the wrong PackageReference exists (e.g., the historical
    # "mage-runner" mistake), wipe rules and recreate with the correct one.
    if existing:
        print(f"  Replacing {len(existing)} existing rule(s) with corrected rule")
        ch["Rules"] = [desired_rule]
    else:
        ch["Rules"] = [desired_rule]

    # Two-phase write to avoid Octopus's stale-internal-state validation
    # (a rule once created with PackageReference=mage-runner can leave a
    # phantom reference even after PackageReference is set to null on GET).
    ch_clear = {**ch, "Rules": []}
    if not api("PUT", f"/api/{SPACE}/channels/{ch['Id']}", body=ch_clear, key=key):
        print("  ERROR: clearing rules failed")
        return False
    ch_fresh = api("GET", f"/api/{SPACE}/channels/{ch['Id']}", key=key)
    ch_fresh["Rules"] = [desired_rule]
    result = api("PUT", f"/api/{SPACE}/channels/{ch_fresh['Id']}", body=ch_fresh, key=key)
    if result:
        print(f"  CREATED rule: tag={RULE_TAG} action={RULE_ACTION} ref={RULE_PACKAGE_REF}")
        return True
    print("  ERROR: rule create failed")
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", "-p", default="brands-api")
    ap.add_argument("--all", action="store_true")
    args = ap.parse_args()
    key = os.environ.get("OCTOPUS_API_KEY")
    if not key:
        sys.exit("OCTOPUS_API_KEY not set")
    projects = [
        "brands-api","geoenrichment-sync-handler","attrition-api",
        "io-notifications-handler","trailers-api","safetylytx-video-api",
    ] if args.all else [args.project]
    fail = sum(0 if patch_project(n, key) else 1 for n in projects)
    sys.exit(1 if fail else 0)


if __name__ == "__main__":
    main()
