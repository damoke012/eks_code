#!/bin/bash
# Grants IRSA-bootstrap permissions to octopus-usxpress in the current AWS
# account. Additive inline policy; cloud-impact-neutral.
#
# USAGE:
#   Local: AWS_PROFILE=usx-dev CLUSTER_NAME=op-usxpress-dev bash apply-bootstrap-perms.sh
#   GHA:   CLUSTER_NAME=op-usxpress-dev bash apply-bootstrap-perms.sh
#          (creds via aws-actions/configure-aws-credentials@v4 OIDC)
set -euo pipefail

ROLE="${ROLE:-octopus-usxpress}"
CLUSTER_NAME="${CLUSTER_NAME:-op-usxpress-dev}"

ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
echo "Target account: $ACCOUNT"
echo "Target role:    $ROLE"
echo "Cluster name:   $CLUSTER_NAME"

if ! aws iam get-role --role-name "$ROLE" > /dev/null 2>&1; then
  echo "ERROR: role $ROLE not found in account $ACCOUNT."
  exit 1
fi

echo
echo "Attaching iaac-talos-bootstrap inline policy to $ROLE ..."

aws iam put-role-policy \
  --role-name "$ROLE" \
  --policy-name iaac-talos-bootstrap \
  --policy-document "$(cat <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "CloudFrontOAC",
      "Effect": "Allow",
      "Action": [
        "cloudfront:CreateOriginAccessControl",
        "cloudfront:DeleteOriginAccessControl",
        "cloudfront:GetOriginAccessControl",
        "cloudfront:UpdateOriginAccessControl",
        "cloudfront:ListOriginAccessControls"
      ],
      "Resource": "*"
    },
    {
      "Sid": "CloudFrontDistributions",
      "Effect": "Allow",
      "Action": [
        "cloudfront:CreateDistribution",
        "cloudfront:DeleteDistribution",
        "cloudfront:GetDistribution",
        "cloudfront:GetDistributionConfig",
        "cloudfront:UpdateDistribution",
        "cloudfront:TagResource",
        "cloudfront:UntagResource",
        "cloudfront:ListTagsForResource",
        "cloudfront:ListDistributions",
        "cloudfront:CreateInvalidation",
        "cloudfront:GetInvalidation",
        "cloudfront:ListInvalidations"
      ],
      "Resource": "*"
    },
    {
      "Sid": "IAMOIDCProvider",
      "Effect": "Allow",
      "Action": [
        "iam:CreateOpenIDConnectProvider",
        "iam:DeleteOpenIDConnectProvider",
        "iam:GetOpenIDConnectProvider",
        "iam:TagOpenIDConnectProvider",
        "iam:UntagOpenIDConnectProvider",
        "iam:ListOpenIDConnectProviderTags"
      ],
      "Resource": "*"
    },
    {
      "Sid": "IAMRoleManagementClusterScoped",
      "Effect": "Allow",
      "Action": [
        "iam:CreateRole",
        "iam:DeleteRole",
        "iam:GetRole",
        "iam:UpdateRole",
        "iam:UpdateAssumeRolePolicy",
        "iam:TagRole",
        "iam:UntagRole",
        "iam:ListRoleTags",
        "iam:PutRolePolicy",
        "iam:DeleteRolePolicy",
        "iam:GetRolePolicy",
        "iam:ListRolePolicies",
        "iam:AttachRolePolicy",
        "iam:DetachRolePolicy",
        "iam:ListAttachedRolePolicies"
      ],
      "Resource": [
        "arn:aws:iam::${ACCOUNT}:role/${CLUSTER_NAME}-*",
        "arn:aws:iam::${ACCOUNT}:role/iaac-octopus-worker-${CLUSTER_NAME}"
      ]
    }
  ]
}
EOF
)"

echo "  [ok] iaac-talos-bootstrap"
echo
echo "Current inline policies on $ROLE:"
aws iam list-role-policies --role-name "$ROLE" --output text
