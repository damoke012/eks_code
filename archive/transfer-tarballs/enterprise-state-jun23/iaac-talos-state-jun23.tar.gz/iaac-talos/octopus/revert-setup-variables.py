#!/usr/bin/env python3
"""
Reverse of patch-setup-variables.py: removes the patched "Kubeconfig deferred
to DX-Apply" if-block from OnPremise space's DX__SetupVariables ScriptModule.

Rationale: cloud USXpress space (Spaces-245) does not have an
`if ($useEksApi -eq "false")` block - the block was added specifically when the
OnPremise space was created. There is no pristine cloud version to restore.

Instead, we simply DELETE the patched block. This leaves DX__SetupVariables
with no on-prem-specific SSM logic, which is architecturally correct:
the SSM kubeconfig logic lives in DX-Apply (inserted by patch-dx-apply.py),
not in DX__SetupVariables. On a rebuild, patch-setup-variables.py will find
no block to patch and exit cleanly.

Usage:
    OCTOPUS_API_KEY=API-... ./revert-setup-variables.py [--dry-run]

Cloud-safety: WRITES only to Spaces-302 (OnPremise). Never touches cloud.
"""

import argparse
import json
import os
import sys
import urllib.error
import urllib.request

OCTO = "https://octopus.usxpress.io"
DST_SPACE = "Spaces-302"
LVS_NAME = "DX__SetupVariables"
SKIP_MARKER = "Kubeconfig deferred to DX-Apply"
SSM_BLOCK_START = 'if ($useEksApi -eq "false")'


def api(method, path, body=None, key=None):
    req = urllib.request.Request(
        f"{OCTO}/api/{DST_SPACE}{path}",
        data=json.dumps(body).encode() if body is not None else None,
        headers={"X-Octopus-ApiKey": key, "Content-Type": "application/json"},
        method=method,
    )
    try:
        with urllib.request.urlopen(req) as r:
            data = r.read()
            return json.loads(data) if data else {}
    except urllib.error.HTTPError as e:
        sys.exit(f"HTTP {e.code} on {method} {path}: {e.read().decode()[:300]}")


def extract_ssm_block(script):
    if SSM_BLOCK_START not in script:
        return None
    start_idx = script.index(SSM_BLOCK_START)
    depth = 0
    in_body = False
    for i in range(start_idx, len(script)):
        c = script[i]
        if c == '{':
            depth += 1
            in_body = True
        elif c == '}':
            depth -= 1
            if in_body and depth == 0:
                return (start_idx, i + 1, script[start_idx:i + 1])
    return None


def main():
    ap = argparse.ArgumentParser(description="Revert DX__SetupVariables on-prem patch")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    key = os.environ.get("OCTOPUS_API_KEY")
    if not key:
        sys.exit("OCTOPUS_API_KEY not set")

    lvs_list = api("GET", "/libraryvariablesets?take=200", key=key)
    lvs = None
    for item in lvs_list.get("Items", []):
        if item["Name"] == LVS_NAME:
            lvs = item
            break
    if not lvs:
        sys.exit(f"{LVS_NAME} not found in {DST_SPACE}")

    vsid = lvs["VariableSetId"]
    vs = api("GET", f"/variables/{vsid}", key=key)
    script_var = None
    for v in vs["Variables"]:
        if v["Name"] == f"Octopus.Script.Module[{LVS_NAME}]":
            script_var = v
            break
    if not script_var:
        sys.exit(f"Script module variable not found in {LVS_NAME}")

    script = script_var["Value"]

    if SKIP_MARKER not in script and SSM_BLOCK_START not in script:
        print(f"ALREADY REVERTED: no on-prem branch present in {LVS_NAME}")
        return

    found = extract_ssm_block(script)
    if not found:
        sys.exit(f"Marker present but could not isolate if-block. Manual review required.")

    start, end, block = found
    if SKIP_MARKER not in block:
        print(f"WARNING: block does NOT contain marker {SKIP_MARKER!r}. Refusing to delete.")
        print(f"Block preview: {block[:300]}...")
        sys.exit(2)

    rm_start, rm_end = start, end
    while rm_end < len(script) and script[rm_end] in "\r\n":
        rm_end += 1
        if script[rm_end - 1] == "\n":
            break

    new_script = script[:rm_start] + script[rm_end:]

    print(f"Located patched block ({end - start} chars, marker present)")
    if args.dry_run:
        print("DRY-RUN: would delete this block from DX__SetupVariables:")
        print("-" * 60)
        print(block)
        print("-" * 60)
        return

    script_var["Value"] = new_script
    api("PUT", f"/variables/{vsid}", body=vs, key=key)
    print(f"REVERTED: patched block removed from {LVS_NAME} ({end - start} chars)")


if __name__ == "__main__":
    main()
