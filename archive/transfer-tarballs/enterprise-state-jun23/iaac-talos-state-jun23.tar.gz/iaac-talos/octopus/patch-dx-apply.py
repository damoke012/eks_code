#!/usr/bin/env python3
"""
Idempotent patch for DX-Apply deployment process in OnPremise space.

Inserts the on-prem pre-MageRunner block into the DX-Apply inline script.
For deployments with TF_VAR_use_eks_api=false (on-prem path), this block:
  1. Reads cluster endpoint, CA, and token from SSM Parameter Store
  2. Writes a kubeconfig file for kubectl/helm/terraform
  3. Logs into ECR for Helm chart pulls
  4. Strips infrastructure.auth from spec.yaml so the azure_app terraform
     module does not attempt to recreate Azure AD apps / SM secrets that
     are already cloud-managed in the consolidated usx-dev account
     (per Vibin's consolidation directive -- on-prem references, never
     duplicates, cloud-created shared resources). Flux-synced
     ExternalSecrets bridge the shared SM secret into on-prem namespaces.

Re-runnable: the entire block is replaced on each apply, so policy tweaks
propagate just by re-running the script.

Usage:
    OCTOPUS_API_KEY=API-... ./patch-dx-apply.py --project brands-api [--dry-run]
    OCTOPUS_API_KEY=API-... ./patch-dx-apply.py --all [--dry-run]

Cloud-safety: Only modifies deployment processes in Spaces-302 (OnPremise).
"""

import argparse
import json
import os
import sys
import urllib.error
import urllib.request

OCTO = "https://octopus.usxpress.io"
DST_SPACE = "Spaces-302"

BLOCK_START_MARKER = "# === BEGIN onprem-preflight (managed by patch-dx-apply.py) ==="
BLOCK_END_MARKER = "# === END onprem-preflight (managed by patch-dx-apply.py) ==="
INSERTION_MARKER = "chmod +x ./mage/mage"

ONPREM_PREFLIGHT_BLOCK = r"""# === BEGIN onprem-preflight (managed by patch-dx-apply.py) ===
# On-prem preflight: SSM kubeconfig + spec.yaml transformation for shared
# cloud-originated resources. Skipped entirely when TF_VAR_use_eks_api != "false".
$useEksApi = $OctopusParameters["TF_VAR_use_eks_api"]
Write-Host "TF_VAR_use_eks_api = [$useEksApi]"
if ($useEksApi -eq "false")
{
  $prevPref = $PSNativeCommandUseErrorActionPreference
  $PSNativeCommandUseErrorActionPreference = $false

  $clusterName = $OctopusParameters["CLUSTER_NAME"]
  $clusterRegion = $OctopusParameters["CLUSTER_REGION"]
  Write-Host "Building kubeconfig from SSM for cluster=$clusterName region=$clusterRegion"

  Remove-Item Env:AWS_PROFILE -ErrorAction SilentlyContinue
  $env:AWS_DEFAULT_REGION = $clusterRegion
  $env:AWS_REGION = $clusterRegion
  Write-Host "Cleared stale AWS config, region=$clusterRegion, using IRSA natively"

  $ssmEndpoint = aws ssm get-parameter --name "/clusters/$clusterName/endpoint" --with-decryption --query "Parameter.Value" --output text --region $clusterRegion
  Write-Host "endpoint=$ssmEndpoint"
  $ssmCA = aws ssm get-parameter --name "/clusters/$clusterName/certificate_authority" --with-decryption --query "Parameter.Value" --output text --region $clusterRegion
  Write-Host "CA length=$($ssmCA.Length)"
  $ssmToken = aws ssm get-parameter --name "/clusters/$clusterName/token" --with-decryption --query "Parameter.Value" --output text --region $clusterRegion
  Write-Host "token length=$($ssmToken.Length)"

  $kubeconfigPath = Join-Path (Get-Location).Path ".kubeconfig"
  @"
apiVersion: v1
kind: Config
clusters:
- cluster:
    server: $ssmEndpoint
    certificate-authority-data: $ssmCA
  name: cluster
contexts:
- context:
    cluster: cluster
    user: terraform-runner
  name: cluster
current-context: cluster
users:
- name: terraform-runner
  user:
    token: $ssmToken
"@ | Set-Content -Path $kubeconfigPath
  $env:KUBECONFIG = $kubeconfigPath
  New-Item -ItemType Directory -Path /root/.kube -Force -ErrorAction SilentlyContinue | Out-Null
  Copy-Item -Path $kubeconfigPath -Destination /root/.kube/config -Force -ErrorAction SilentlyContinue
  Write-Host "Kubeconfig written to $kubeconfigPath"

  aws ecr get-login-password --region us-east-2 | helm registry login --username AWS --password-stdin 064859874041.dkr.ecr.us-east-2.amazonaws.com

  Write-Host "[onprem-preflight] strip phase: starting"
  $specPath = Join-Path (Get-Location).Path "project/spec.yaml"
  Write-Host "[onprem-preflight] specPath=$specPath exists=$(Test-Path $specPath)"
  if (Test-Path $specPath) {
    $stripPy = Join-Path (Get-Location).Path "onprem-preflight-strip.py"
    # Stdlib-only line-indented YAML strip. Removes top-level keys under
    # `infrastructure:` listed in STRIP_KEYS so the corresponding terraform
    # modules in MageRunner are skipped on on-prem (cloud already owns the
    # shared resources; ExternalSecrets in iaac-talos-flux-platform bridge
    # the cloud-managed AWS SM secrets into on-prem app namespaces).
    @'
import sys
STRIP_KEYS = ["auth"]  # mongodb no longer stripped — atlas-user fork gates the collision at the resource level instead
p = sys.argv[1]
with open(p) as f:
    lines = f.readlines()
out = []
in_strip = False
stripped = []
for line in lines:
    matched = None
    for k in STRIP_KEYS:
        if line.rstrip("\n").rstrip() == "  " + k + ":":
            matched = k
            break
    if matched:
        in_strip = True
        if matched not in stripped:
            stripped.append(matched)
        continue
    if in_strip:
        if line.strip() == "" or line.startswith("    "):
            continue
        in_strip = False
    out.append(line)
with open(p, "w") as f:
    f.writelines(out)
print("[onprem-preflight] file: %d lines in, %d lines out" % (len(lines), len(out)))
if stripped:
    print("[onprem-preflight] stripped infrastructure." + ", infrastructure.".join(stripped))
else:
    print("[onprem-preflight] no shared-resource blocks to strip")
with open(p) as f:
    body = f.read()
auth_present = "\n  auth:\n" in body or body.startswith("  auth:\n")
mongodb_present = "\n  mongodb:\n" in body or body.startswith("  mongodb:\n")
print("[onprem-preflight] post-strip check: auth_present=%s mongodb_present=%s" % (auth_present, mongodb_present))
'@ | Set-Content -Path $stripPy -Encoding UTF8
    Write-Host "[onprem-preflight] wrote strip script to $stripPy"
    $py = (Get-Command python3 -ErrorAction SilentlyContinue)
    if (-not $py) { $py = (Get-Command python -ErrorAction SilentlyContinue) }
    if ($py) {
      Write-Host "[onprem-preflight] invoking $($py.Source) $stripPy $specPath"
      & $py.Source $stripPy $specPath
      Write-Host "[onprem-preflight] strip exit code: $LASTEXITCODE"
    } else {
      Write-Host "[onprem-preflight] WARN: python not available, skip strip"
    }
    Remove-Item $stripPy -Force -ErrorAction SilentlyContinue
  } else {
    Write-Host "[onprem-preflight] WARN: spec.yaml not found at $specPath, skip strip"
  }

  $PSNativeCommandUseErrorActionPreference = $prevPref
}
# === END onprem-preflight (managed by patch-dx-apply.py) ===

"""


def api(method, path, body=None, key=None):
    req = urllib.request.Request(
        f"{OCTO}{path}",
        data=json.dumps(body).encode() if body is not None else None,
        headers={"X-Octopus-ApiKey": key, "Content-Type": "application/json"},
        method=method,
    )
    try:
        with urllib.request.urlopen(req) as r:
            data = r.read()
            return json.loads(data) if data else {}
    except urllib.error.HTTPError as e:
        err = e.read().decode()[:400]
        print(f"  HTTP {e.code} on {method} {path}: {err}", file=sys.stderr)
        return None


def find_project(name, key):
    d = api("GET", f"/api/{DST_SPACE}/projects?partialName={name}&take=10", key=key)
    if not d:
        return None
    for p in d.get("Items", []):
        if p["Name"] == name:
            return p
    return None


def patch_project(project_name, key, dry_run=False):
    print(f"\n{'='*50}")
    print(f"Patching DX-Apply for: {project_name}")

    proj = find_project(project_name, key)
    if not proj:
        print(f"  ERROR: project {project_name!r} not found in {DST_SPACE}")
        return False

    dp_id = f"deploymentprocess-{proj['Id']}"
    dp = api("GET", f"/api/{DST_SPACE}/deploymentprocesses/{dp_id}", key=key)
    if not dp:
        print(f"  ERROR: deployment process not found")
        return False

    for step in dp.get("Steps", []):
        for action in step.get("Actions", []):
            if action["Name"] != "DX-Apply":
                continue

            script = action["Properties"].get("Octopus.Action.Script.ScriptBody", "")

            if BLOCK_START_MARKER in script and BLOCK_END_MARKER in script:
                start = script.index(BLOCK_START_MARKER)
                end = script.index(BLOCK_END_MARKER) + len(BLOCK_END_MARKER)
                while end < len(script) and script[end] == "\n":
                    end += 1
                new_script = script[:start] + ONPREM_PREFLIGHT_BLOCK + script[end:]
                action_taken = "UPDATED existing onprem-preflight block"
            else:
                if INSERTION_MARKER not in script:
                    print(f"  ERROR: insertion marker '{INSERTION_MARKER}' not found in script")
                    return False
                new_script = script.replace(
                    INSERTION_MARKER,
                    ONPREM_PREFLIGHT_BLOCK + INSERTION_MARKER,
                )
                action_taken = "INSERTED onprem-preflight block"

            if new_script == script:
                print("  NO-OP: script already matches target state")
                return True

            if dry_run:
                print(f"  DRY-RUN: would {action_taken.lower()}")
                return True

            action["Properties"]["Octopus.Action.Script.ScriptBody"] = new_script
            result = api("PUT", f"/api/{DST_SPACE}/deploymentprocesses/{dp_id}", body=dp, key=key)
            if result:
                print(f"  {action_taken}")
                return True
            else:
                print("  ERROR: failed to save deployment process")
                return False

    print("  ERROR: DX-Apply action not found in deployment process")
    return False


def main():
    ap = argparse.ArgumentParser(description="Patch DX-Apply for on-prem preflight (SSM kubeconfig + spec strip)")
    ap.add_argument("--project", "-p", default="brands-api")
    ap.add_argument("--all", action="store_true",
                    help="Patch all module-coverage apps")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    key = os.environ.get("OCTOPUS_API_KEY")
    if not key:
        sys.exit("OCTOPUS_API_KEY not set")

    projects = [
        "brands-api",
        "geoenrichment-sync-handler",
        "attrition-api",
        "io-notifications-handler",
        "trailers-api",
        "safetylytx-video-api",
    ] if args.all else [args.project]

    ok = fail = 0
    for name in projects:
        if patch_project(name, key, args.dry_run):
            ok += 1
        else:
            fail += 1

    print(f"\nDone: {ok} ok, {fail} failed")
    if fail > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
