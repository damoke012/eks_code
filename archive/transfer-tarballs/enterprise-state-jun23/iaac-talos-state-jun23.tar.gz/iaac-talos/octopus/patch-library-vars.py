#!/usr/bin/env python3
"""Idempotent library variable patches for OnPremise space.

Flips DX__Runner.SCHEMA_VALIDATE_DRY_RUN to "true" for development env
(Environments-1081). Mage 2.x ValidateSpec needs schemas/ at runtime that
aren't packaged in the fork tarball; the dry-run flag lets the load failure
log as a warning instead of failing the deploy.

Idempotent. Hard-locked to OnPremise (Spaces-302); cloud's DX__Runner in
Spaces-245 untouched.
"""
import argparse, json, os, sys, urllib.error, urllib.request

OCTO = "https://octopus.usxpress.io"
SPACE = "Spaces-302"

# (set_name, var_name, env_id, desired_value)
PATCHES = [
    ("DX__Runner", "SCHEMA_VALIDATE_DRY_RUN", "Environments-1081", "true"),
]


def api(method, path, body=None, key=None):
    req = urllib.request.Request(
        f"{OCTO}{path}",
        data=json.dumps(body).encode() if body is not None else None,
        headers={"X-Octopus-ApiKey": key, "Content-Type": "application/json"},
        method=method,
    )
    try:
        with urllib.request.urlopen(req) as r:
            data = r.read()
            return json.loads(data) if data else {}
    except urllib.error.HTTPError as e:
        print(f"  HTTP {e.code}: {e.read().decode()[:300]}", file=sys.stderr)
        return None


def find_set(name, key):
    sets = api("GET", f"/api/{SPACE}/libraryvariablesets?take=50", key=key)
    for s in (sets or {}).get("Items", []):
        if s["Name"] == name:
            return s
    return None


def patch_one(set_name, var_name, env_id, desired_value, key):
    print(f"\n--- {set_name}.{var_name} for {env_id} -> {desired_value!r} ---")
    s = find_set(set_name, key)
    if not s:
        print(f"  NOT FOUND: {set_name}")
        return False
    vars_doc = api("GET", f"/api/{SPACE}/variables/{s['VariableSetId']}", key=key)
    if not vars_doc:
        return False

    changed = False
    for v in vars_doc["Variables"]:
        if v.get("Name") != var_name:
            continue
        if env_id not in v.get("Scope", {}).get("Environment", []):
            continue
        if v.get("Value") == desired_value:
            print(f"  SKIP: already {desired_value!r}")
            continue
        print(f"  PATCH: {v.get('Value')!r} -> {desired_value!r}")
        v["Value"] = desired_value
        changed = True

    if not changed:
        return True

    result = api("PUT", f"/api/{SPACE}/variables/{s['VariableSetId']}", body=vars_doc, key=key)
    if result:
        print(f"  UPDATED")
        return True
    print(f"  ERROR")
    return False


def main():
    argparse.ArgumentParser().parse_args()
    key = os.environ.get("OCTOPUS_API_KEY")
    if not key:
        sys.exit("OCTOPUS_API_KEY not set")
    fail = 0
    for set_name, var, env, val in PATCHES:
        if not patch_one(set_name, var, env, val, key):
            fail += 1
    sys.exit(1 if fail else 0)


if __name__ == "__main__":
    main()
