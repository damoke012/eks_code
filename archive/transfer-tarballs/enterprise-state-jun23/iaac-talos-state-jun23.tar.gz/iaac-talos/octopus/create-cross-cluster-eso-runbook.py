#!/usr/bin/env python3
"""Create or update the cross-cluster ESO runbooks on the
'onprem-platform-bootstrap' project in OnPremise space (Spaces-302).

Two runbooks:
  1. 'Apply Cross-Cluster ESO RBAC'  - applies RBAC manifests to cloud EKS
  2. 'Seed Cross-Cluster ESO Token'  - extracts cloud SA token, seeds on-prem
                                       k8s secret cloud-eks-reader-token in
                                       external-secrets-system ns

Both run on the on-prem worker (WorkerPools-1922 / iaac-octopus-worker-op-usxpress-dev).
Both are idempotent. Embeds manifests inline; no git clone at run time.

Idempotent. Re-run after manifest or token-source changes.

Usage:
    OCTOPUS_API_KEY=API-... python3 octopus/create-cross-cluster-eso-runbook.py
"""
import argparse, json, os, pathlib, sys, time, urllib.request, urllib.error

OCTO          = "https://octopus.usxpress.io"
SPACE         = "Spaces-302"
PROJECT_NAME  = "onprem-platform-bootstrap"
WORKER_POOL   = "onprem-development"
CLUSTER_NAME  = "usxpress-dev"
CLUSTER_REGION = "us-east-2"

# Cloud SA we read the token from — must match what's deployed by
# 'Apply Cross-Cluster ESO RBAC' runbook (cloud-rbac/onprem-reader-<ns>.yaml).
TOKEN_SOURCE_NS  = "geoservices"
TOKEN_SOURCE_SA  = "onprem-secret-reader"
TOKEN_SOURCE_SEC = f"{TOKEN_SOURCE_SA}-token"

# On-prem destination
ONPREM_ESO_NS    = "external-secrets"
ONPREM_TOKEN_SEC = "cloud-eks-reader-token"

REPO_ROOT = pathlib.Path(__file__).resolve().parents[1]
RBAC_DIR  = REPO_ROOT / "octopus" / "cross-cluster-eso" / "cloud-rbac"


def api(method, path, body=None, key=None):
    req = urllib.request.Request(
        f"{OCTO}{path}",
        data=json.dumps(body).encode() if body is not None else None,
        headers={"X-Octopus-ApiKey": key, "Content-Type": "application/json"},
        method=method,
    )
    try:
        with urllib.request.urlopen(req) as r:
            data = r.read()
            return json.loads(data) if data else {}
    except urllib.error.HTTPError as e:
        print(f"  HTTP {e.code} on {method} {path}: {e.read().decode()[:400]}", file=sys.stderr)
        raise


def find_or_create_project(key):
    proj = api("GET", f"/api/{SPACE}/projects?partialName={PROJECT_NAME}&take=20", key=key)
    existing = next((p for p in proj["Items"] if p["Name"] == PROJECT_NAME), None)
    if existing:
        print(f"  project: {PROJECT_NAME} -> {existing['Id']} (exists)")
        return existing["Id"]
    pg = api("GET", f"/api/{SPACE}/projectgroups?take=20", key=key)
    if not pg["Items"]:
        sys.exit(f"no project groups in {SPACE}")
    sample_proj = api("GET", f"/api/{SPACE}/projects?take=1", key=key)
    if not sample_proj["Items"]:
        sys.exit(f"no projects in {SPACE} to copy lifecycle from")
    body = {
        "Name": PROJECT_NAME,
        "Description": "Platform bootstrap runbooks for on-prem cluster.",
        "ProjectGroupId": pg["Items"][0]["Id"],
        "LifecycleId": sample_proj["Items"][0]["LifecycleId"],
        "IsDisabled": False,
    }
    p = api("POST", f"/api/{SPACE}/projects", body=body, key=key)
    print(f"  project: {PROJECT_NAME} -> {p['Id']} (CREATED)")
    return p["Id"]


def find_worker_pool(key):
    w = api("GET", f"/api/{SPACE}/workerpools?partialName={WORKER_POOL}&take=10", key=key)
    wp = next((x for x in w["Items"] if x["Name"] == WORKER_POOL), None)
    if not wp:
        sys.exit(f"worker pool '{WORKER_POOL}' not found in {SPACE}")
    print(f"  worker pool: {WORKER_POOL} -> {wp['Id']}")
    return wp["Id"]


def upsert_runbook(key, pid, wpid, name, description, script_body):
    rbs = api("GET", f"/api/{SPACE}/projects/{pid}/runbooks?take=100", key=key)
    existing = next((r for r in rbs["Items"] if r["Name"] == name), None)
    if existing:
        rbid = existing["Id"]
        print(f"  runbook exists: '{name}' -> {rbid}")
    else:
        body = {
            "ProjectId": pid, "Name": name, "Description": description,
            "RunbookProcessId": None, "PublishedRunbookSnapshotId": None,
            "ConnectivityPolicy": {
                "AllowDeploymentsToNoTargets": True,
                "ExcludeUnhealthyTargets": False,
                "SkipMachineBehavior": "None"},
            "EnvironmentScope": "All",
            "DefaultGuidedFailureMode": "EnvironmentDefault",
            "RunRetentionPolicy": {"QuantityToKeep": 100, "ShouldKeepForever": False},
            "MultiTenancyMode": "Untenanted"
        }
        rb = api("POST", f"/api/{SPACE}/runbooks", body=body, key=key)
        rbid = rb["Id"]
        print(f"  CREATED runbook: '{name}' -> {rbid}")

    rb = api("GET", f"/api/{SPACE}/runbooks/{rbid}", key=key)
    rb_proc = api("GET", f"/api/{SPACE}/runbookProcesses/{rb['RunbookProcessId']}", key=key)
    rb_proc["Steps"] = [{
        "Name": name, "Properties": {"Octopus.Action.TargetRoles": ""},
        "Condition": "Success", "StartTrigger": "StartAfterPrevious",
        "PackageRequirement": "LetOctopusDecide",
        "Actions": [{
            "Name": name, "ActionType": "Octopus.Script", "IsDisabled": False,
            "WorkerPoolId": wpid,
            "Container": {"Image": None, "FeedId": None},
            "Environments": [], "ExcludedEnvironments": [],
            "Channels": [], "TenantTags": [], "Packages": [],
            "Condition": "Success",
            "Properties": {
                "Octopus.Action.RunOnServer": "false",
                "Octopus.Action.Script.ScriptSource": "Inline",
                "Octopus.Action.Script.Syntax": "Bash",
                "Octopus.Action.Script.ScriptBody": script_body,
            }
        }]
    }]
    api("PUT", f"/api/{SPACE}/runbookProcesses/{rb['RunbookProcessId']}", body=rb_proc, key=key)
    snap_name = time.strftime(f"auto-{name.replace(' ','_')}-%Y%m%d-%H%M%S")
    snap = api("POST", f"/api/{SPACE}/runbookSnapshots?publish=true",
               body={"ProjectId": pid, "RunbookId": rbid, "Name": snap_name,
                     "SelectedPackages": []}, key=key)
    print(f"  snapshot published: {snap['Id']}")
    return rbid, snap["Id"]


def script_apply_rbac():
    yaml_files = sorted(RBAC_DIR.glob("*.yaml"))
    if not yaml_files:
        sys.exit(f"no yaml under {RBAC_DIR}")
    bundle = "\n".join(f.read_text().rstrip() for f in yaml_files)
    return f"""#!/bin/bash
# Generated by octopus/create-cross-cluster-eso-runbook.py - DO NOT EDIT IN OCTOPUS UI.
set -euo pipefail
echo "=== Applying cross-cluster ESO RBAC to {CLUSTER_NAME} ({CLUSTER_REGION})"
echo "    manifests: {', '.join(f.name for f in yaml_files)}"
aws eks update-kubeconfig --name {CLUSTER_NAME} --region {CLUSTER_REGION} --alias cloud-{CLUSTER_NAME}
cat <<'BUNDLE_YAML' | kubectl --context=cloud-{CLUSTER_NAME} apply -f -
{bundle}
BUNDLE_YAML

echo
echo "=== RBAC sanity (expect: yes / no / no / no for {TOKEN_SOURCE_NS} ns)"
SA="system:serviceaccount:{TOKEN_SOURCE_NS}:{TOKEN_SOURCE_SA}"
kubectl --context=cloud-{CLUSTER_NAME} auth can-i list   secrets -n {TOKEN_SOURCE_NS} --as="$SA" || true
kubectl --context=cloud-{CLUSTER_NAME} auth can-i create secrets -n {TOKEN_SOURCE_NS} --as="$SA" || true
kubectl --context=cloud-{CLUSTER_NAME} auth can-i list   pods    -n {TOKEN_SOURCE_NS} --as="$SA" || true
kubectl --context=cloud-{CLUSTER_NAME} auth can-i list   secrets -n kube-system --as="$SA" || true
"""


def script_seed_token():
    return f"""#!/bin/bash
# Generated by octopus/create-cross-cluster-eso-runbook.py - DO NOT EDIT IN OCTOPUS UI.
# Step 1 reads from CLOUD via aws eks update-kubeconfig (worker IAM identity).
# Step 2 writes to ON-PREM via in-cluster pod SA (KUBECONFIG cleared).
set -euo pipefail

# --- Step 1: read cloud SA token (uses worker AWS IAM identity) ---
echo "=== Step 1: extract bearer token from cloud {CLUSTER_NAME}/{TOKEN_SOURCE_NS}/{TOKEN_SOURCE_SEC}"
export CLOUD_KUBECONFIG=/tmp/cloud-kubeconfig.$$
KUBECONFIG=$CLOUD_KUBECONFIG aws eks update-kubeconfig --name {CLUSTER_NAME} --region {CLUSTER_REGION} --alias cloud >/dev/null

CLOUD_TOKEN=$(KUBECONFIG=$CLOUD_KUBECONFIG kubectl --context=cloud -n {TOKEN_SOURCE_NS} get secret {TOKEN_SOURCE_SEC} -o jsonpath='{{.data.token}}' | base64 -d)
if [[ -z "$CLOUD_TOKEN" ]]; then
  echo "ERROR: empty token. Has 'Apply Cross-Cluster ESO RBAC' run yet?"
  exit 1
fi
echo "    token length: $(printf %s "$CLOUD_TOKEN" | wc -c)"

CLOUD_EKS_URL=$(aws --region {CLUSTER_REGION} eks describe-cluster --name {CLUSTER_NAME} --query 'cluster.endpoint' --output text)
CLOUD_EKS_CA_B64=$(aws --region {CLUSTER_REGION} eks describe-cluster --name {CLUSTER_NAME} --query 'cluster.certificateAuthority.data' --output text)
CLOUD_EKS_CA=$(echo -n "$CLOUD_EKS_CA_B64" | base64 -d)
echo "    cloud EKS endpoint: $CLOUD_EKS_URL"
echo "    ca length: ${{#CLOUD_EKS_CA}}"

# --- Step 2: write to ON-PREM via explicit in-cluster kubeconfig ---
# Worker pod has HOME=/tmp so prior runbook left /tmp/.kube/config pointing
# at cloud — `unset KUBECONFIG` is not enough. Build an explicit kubeconfig
# from the in-cluster SA token + CA mounted at /var/run/secrets/kubernetes.io/...
echo
echo "=== Step 2: seed on-prem k8s secret {ONPREM_ESO_NS}/{ONPREM_TOKEN_SEC}"
ONPREM_KUBECONFIG=/tmp/onprem-incluster.$$
cat > "$ONPREM_KUBECONFIG" <<EOF
apiVersion: v1
kind: Config
clusters:
- cluster:
    certificate-authority: /var/run/secrets/kubernetes.io/serviceaccount/ca.crt
    server: https://kubernetes.default.svc
  name: onprem
contexts:
- context:
    cluster: onprem
    user: pod-sa
    namespace: default
  name: onprem
current-context: onprem
users:
- name: pod-sa
  user:
    tokenFile: /var/run/secrets/kubernetes.io/serviceaccount/token
EOF
export KUBECONFIG="$ONPREM_KUBECONFIG"

# Sanity: confirm we are talking to on-prem (k8s API service IP, not cloud endpoint)
echo "    kubectl context: $(kubectl config current-context)"
echo "    kubectl server : $(kubectl config view --raw -o jsonpath='{{.clusters[0].cluster.server}}')"
echo "    pod SA namespace: $(cat /var/run/secrets/kubernetes.io/serviceaccount/namespace 2>/dev/null || echo unknown)"

echo "    (ns {ONPREM_ESO_NS} managed by Flux ESO HelmRelease - not creating)"
kubectl -n {ONPREM_ESO_NS} delete secret {ONPREM_TOKEN_SEC} --ignore-not-found

kubectl -n {ONPREM_ESO_NS} create secret generic {ONPREM_TOKEN_SEC} \\
  --from-literal=token="$CLOUD_TOKEN" \\
  --from-literal=server="$CLOUD_EKS_URL" \\
  --from-literal=ca="$CLOUD_EKS_CA"

echo
echo "=== Verify"
kubectl -n {ONPREM_ESO_NS} get secret {ONPREM_TOKEN_SEC}

# Cleanup ephemeral kubeconfigs
rm -f "$CLOUD_KUBECONFIG" "$ONPREM_KUBECONFIG"

echo
echo "=== Done. ClusterSecretStore can now reference {ONPREM_ESO_NS}/{ONPREM_TOKEN_SEC}."
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    key = os.environ.get("OCTOPUS_API_KEY") or sys.exit("OCTOPUS_API_KEY not set")

    if args.dry_run:
        print("---script: apply RBAC---")
        print(script_apply_rbac())
        print("\n---script: seed token---")
        print(script_seed_token())
        return

    pid = find_or_create_project(key)
    wpid = find_worker_pool(key)

    rbid_apply, snap_apply = upsert_runbook(
        key, pid, wpid,
        "Apply Cross-Cluster ESO RBAC",
        "Applies cross-cluster ESO RBAC to cloud EKS. Generated.",
        script_apply_rbac())

    rbid_seed, snap_seed = upsert_runbook(
        key, pid, wpid,
        "Seed Cross-Cluster ESO Token",
        "Extracts cloud SA token + EKS endpoint/CA, seeds on-prem ESO secret. Generated.",
        script_seed_token())

    print()
    print(f"Runbooks ready (project Projects-9901 / dev env Environments-1081):")
    print(f"  Apply RBAC:  Runbooks={rbid_apply}  Snapshot={snap_apply}")
    print(f"  Seed Token:  Runbooks={rbid_seed}  Snapshot={snap_seed}")


if __name__ == "__main__":
    main()
