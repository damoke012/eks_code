#!/usr/bin/env python3
"""Bento: import a project from cloud USXpress (Spaces-245) to OnPremise (Spaces-302).

Idempotent: skips if project already exists in destination.
Cloud-safety: export is non-mutating on source; only writes to Spaces-302.

Usage:
    OCTOPUS_API_KEY=API-... ./bento-import.py --project geoenrichment-sync-handler
    OCTOPUS_API_KEY=API-... ./bento-import.py --all
"""
import argparse, json, os, sys, time, urllib.error, urllib.parse, urllib.request, uuid

OCTO = "https://octopus.usxpress.io"
SRC_SPACE = "Spaces-245"  # cloud (read)
DST_SPACE = "Spaces-302"  # OnPremise (write, hard-locked)
BENTO_PASSWORD = "OnPremBentoExport2026"
POLL_INTERVAL = 3
POLL_MAX = 300


def api(method, path, body=None, key=None, raw=False):
    req = urllib.request.Request(
        f"{OCTO}{path}",
        data=json.dumps(body).encode() if body is not None else None,
        headers={"X-Octopus-ApiKey": key, "Content-Type": "application/json"},
        method=method,
    )
    try:
        with urllib.request.urlopen(req) as r:
            data = r.read()
            return data if raw else (json.loads(data) if data else {})
    except urllib.error.HTTPError as e:
        err = e.read().decode()[:500]
        print(f"  HTTP {e.code} {method} {path}: {err}", file=sys.stderr)
        return None


def multipart_post(path, fields, files, key):
    boundary = uuid.uuid4().hex
    parts = []
    for n, v in fields.items():
        parts += [
            f"--{boundary}\r\n".encode(),
            f'Content-Disposition: form-data; name="{n}"\r\n\r\n'.encode(),
            f"{v}\r\n".encode(),
        ]
    for n, (fn, content) in files.items():
        parts += [
            f"--{boundary}\r\n".encode(),
            f'Content-Disposition: form-data; name="{n}"; filename="{fn}"\r\n'.encode(),
            b"Content-Type: application/octet-stream\r\n\r\n",
            content,
            b"\r\n",
        ]
    parts.append(f"--{boundary}--\r\n".encode())
    body = b"".join(parts)
    req = urllib.request.Request(
        f"{OCTO}{path}",
        data=body,
        headers={
            "X-Octopus-ApiKey": key,
            "Content-Type": f"multipart/form-data; boundary={boundary}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req) as r:
            data = r.read()
            return json.loads(data) if data else {}
    except urllib.error.HTTPError as e:
        err = e.read().decode()[:500]
        print(f"  HTTP {e.code} POST {path}: {err}", file=sys.stderr)
        return None


def find_project(space, name, key):
    d = api("GET", f"/api/{space}/projects?partialName={urllib.parse.quote(name)}&take=10", key=key)
    for p in (d or {}).get("Items", []):
        if p["Name"] == name:
            return p
    return None


def wait_for_task(task_id, key):
    start = time.time()
    while True:
        t = api("GET", f"/api/tasks/{task_id}", key=key)
        if not t:
            return None
        state = t.get("State", "")
        if state in ("Success", "Failed", "Canceled", "TimedOut"):
            return t
        elapsed = int(time.time() - start)
        print(f"    task {task_id} state={state} elapsed={elapsed}s", flush=True)
        if elapsed > POLL_MAX:
            return t
        time.sleep(POLL_INTERVAL)


def export_project(space, project_id, key):
    body = {
        "IncludedProjectIds": [project_id],
        "IncludedVariableEnvironmentScopes": [],
        "Password": {"HasValue": True, "NewValue": BENTO_PASSWORD},
    }
    r = api("POST", f"/api/{space}/projects/import-export/export", body=body, key=key)
    if not r:
        return None
    task_id = r.get("TaskId") or r.get("Id")
    if not task_id:
        print(f"    no TaskId in: {r}")
        return None
    print(f"  Export task {task_id} started")
    final = wait_for_task(task_id, key)
    if not final or final.get("State") != "Success":
        print(f"    export did not succeed: state={final.get('State') if final else 'none'}")
        return None
    return task_id  # caller passes this to import via ImportSource





def import_project(dst_space, src_space, export_task_id, key):
    body = {
        "ImportSource": {
            "Type": "space",
            "SpaceId": src_space,
            "TaskId": export_task_id,
        },
        "Password": {"HasValue": True, "NewValue": BENTO_PASSWORD},
    }
    r = api("POST", f"/api/{dst_space}/projects/import-export/import", body=body, key=key)
    if not r:
        return None
    task_id = r.get("TaskId") or r.get("Id")
    if not task_id:
        print(f"    no TaskId in import response: {r}")
        return None
    print(f"  Import task {task_id} started")
    return wait_for_task(task_id, key)



def enable_project(space, project_name, key):
    """Bento-imported projects come in disabled. Enable after import."""
    proj = find_project(space, project_name, key)
    if not proj:
        print(f"    ERROR: cannot enable (not found): {project_name}")
        return False
    if not proj.get("IsDisabled", False):
        print(f"  already enabled")
        return True
    proj["IsDisabled"] = False
    r = api("PUT", f"/api/{space}/projects/{proj['Id']}", body=proj, key=key)
    if r:
        print(f"  ENABLED project {proj['Id']}")
        return True
    return False


def bento_one(name, key, dry_run=False):
    print(f"\n=== {name} ===")
    existing = find_project(DST_SPACE, name, key)
    if existing:
        if existing.get("IsDisabled"):
            print(f"  Already in OnPremise but disabled — enabling")
            enable_project(DST_SPACE, name, key)
        else:
            print(f"  SKIP: already in OnPremise and enabled")
        return True
    src = find_project(SRC_SPACE, name, key)
    if not src:
        print(f"  NOT FOUND in cloud")
        return False
    print(f"  Found in cloud: {src['Id']}")
    if dry_run:
        print(f"  DRY-RUN: would export from {SRC_SPACE}, import to {DST_SPACE}")
        return True
    export_task_id = export_project(SRC_SPACE, src["Id"], key)
    if not export_task_id:
        return False
    print(f"  Export complete: {export_task_id}")
    result = import_project(DST_SPACE, SRC_SPACE, export_task_id, key)
    if not result or result.get("State") != "Success":
        print(f"    import task state={result.get('State') if result else 'none'}")
        return False
    new = find_project(DST_SPACE, name, key)
    if new:
        print(f"  Imported as {new['Id']}, enabling...")
        enable_project(DST_SPACE, name, key)
        print(f"  SUCCESS: {name} imported + enabled as {new['Id']}")
        return True
    print(f"  WARN: import completed but project not findable")
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", "-p", default="geoenrichment-sync-handler")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    key = os.environ.get("OCTOPUS_API_KEY")
    if not key:
        sys.exit("OCTOPUS_API_KEY not set")
    projects = [
        "brands-api", "geoenrichment-sync-handler", "attrition-api",
        "io-notifications-handler", "trailers-api", "safetylytx-video-api",
    ] if args.all else [args.project]
    fail = sum(0 if bento_one(n, key, args.dry_run) else 1 for n in projects)
    sys.exit(1 if fail else 0)


if __name__ == "__main__":
    main()
