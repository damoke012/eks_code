#!/bin/bash
# Ensures cluster-level AWS Secrets Manager secrets are populated in the
# TARGET account before Flux reconciles ExternalSecrets that reference them.
#
# Currently covers:
#   - <CLUSTER_NAME>/octopus-worker (required by octopusworker Helm release)
#
# Idempotent: skips secrets that already exist in the target.
# Migration fallback: if missing in target, attempts to copy from a source
# account (default: playground). Useful during Phase 2 migration. When
# Playground is gone (Phase 6), a missing secret will require manual
# provisioning — the script will print a clear error with instructions.
#
# USAGE:
#   Local:  AWS_PROFILE=usx-dev CLUSTER_NAME=op-usxpress-dev bash ensure-cluster-secrets.sh
#   GHA:    CLUSTER_NAME=op-usxpress-dev bash ensure-cluster-secrets.sh
#           (target creds via OIDC; source creds via env if migration is needed)

set -euo pipefail

CLUSTER_NAME="${CLUSTER_NAME:-${1:-op-usxpress-dev}}"
TARGET_REGION="${TARGET_REGION:-us-east-2}"
SOURCE_PROFILE="${SOURCE_PROFILE:-playground}"
SOURCE_REGION="${SOURCE_REGION:-us-east-1}"
SKIP_MIGRATION="${SKIP_MIGRATION:-false}"

TARGET_ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
echo "Target:             account $TARGET_ACCOUNT / $TARGET_REGION"
echo "Source fallback:    profile $SOURCE_PROFILE / $SOURCE_REGION"
echo "Cluster:            $CLUSTER_NAME"
echo

missing=0

check_or_migrate() {
  local secret_name="$1"
  echo "[check] $secret_name"

  if aws --region "$TARGET_REGION" secretsmanager describe-secret --secret-id "$secret_name" > /dev/null 2>&1; then
    echo "  [ok] already exists in target"
    return 0
  fi

  echo "  [missing] not in target"

  if [ "$SKIP_MIGRATION" = "true" ]; then
    echo "  ERROR: SKIP_MIGRATION=true and secret is missing. Provision manually."
    missing=1
    return 1
  fi

  echo "  [migrate] attempting copy from $SOURCE_PROFILE/$SOURCE_REGION ..."
  if ! aws --profile "$SOURCE_PROFILE" --region "$SOURCE_REGION" secretsmanager describe-secret --secret-id "$secret_name" > /dev/null 2>&1; then
    echo "  ERROR: also missing in source. Manual action required:"
    echo "    aws --region $TARGET_REGION secretsmanager create-secret \\"
    echo "      --name $secret_name --secret-string file:///path/to/secret.json"
    missing=1
    return 1
  fi

  local tmpfile; tmpfile=$(mktemp)
  aws --profile "$SOURCE_PROFILE" --region "$SOURCE_REGION" secretsmanager get-secret-value \
    --secret-id "$secret_name" --query SecretString --output text > "$tmpfile"

  aws --region "$TARGET_REGION" secretsmanager create-secret \
    --name "$secret_name" \
    --secret-string "file://$tmpfile" \
    --description "Migrated from $SOURCE_PROFILE/$SOURCE_REGION on $(date +%Y-%m-%d) by ensure-cluster-secrets.sh" \
    > /dev/null

  shred -u "$tmpfile"
  echo "  [ok] migrated"
}

check_or_migrate "$CLUSTER_NAME/octopus-worker"

if [ "$missing" -gt 0 ]; then
  echo
  echo "FAILED: $missing secret(s) missing and could not be migrated."
  exit 1
fi

echo
echo "All cluster-level secrets present in target."
