# Kubernetes Cluster on vSphere with Talos via Terraform

This repository automates the provisioning of a Talos Linux-based Kubernetes cluster on vSphere, using Terraform.

## Components

|Component          | Description                                                                           |
|-------------------|---------------------------------------------------------------------------------------|
| vSphere VM        | Provisions control plane and worker nodes using a Talos OVA                           |
| Talos             | Installs and configures Talos OS and bootstraps the Kubernetes cluster                |
| Terraform Modules | Modular design for flexible infrastructure and deployment                             |

## Project Structure

```text
terraform/
├── main.tf                 # Entry point wiring vSphere and Talos modules
├── variables.tf            # Root input variables
├── outputs.tf              # Outputs for kubeconfig and IPs
├── providers.tf            # Provider definitions
└── modules/
    ├── vsphere_vm/         # VM provisioning module
    └── talos/              # Talos cluster bootstrap and kubeconfig generation

```

## Requirements

* Terraform `>= 1.3`

* Providers:

    * `vmware/vsphere >= 2.1.1`
    
    * `siderolabs/talos >= 0.8.0`

* vSphere Environment Prerequisites

    * A Content Library hosting a valid Talos OVA

    * Configured network, datastore, and compute cluster

## Configuration

Define variables in a `terraform.tfvars` file or pass them via CLI/environment variables.

### vSphere Settings

| Variable                    | Description                        |
|-----------------------------|------------------------------------|
| `vsphere_user`              | vSphere username                   |
| `vsphere_password`          | vSphere password                   |
| `vsphere_server`            | vSphere server address             |
| `datacenter`                | Name of the vSphere datacenter     |
| `datastore`                 | Datastore for VM storage           |
| `vm_cluster_name`           | vSphere compute cluster name       |
| `vm_folder`                 | Folder path for VMs (within DC)    |
| `network_name`              | Network to attach VM NICs          |
| `content_library_name`      | Name of the content library        |
| `content_library_item_name` | Name of the Talos OVA image        |

### Cluster Configuration

| Variable                      | Description                                |
|-------------------------------|--------------------------------------------|
| `cluster_name`                | Talos Kubernetes cluster name              |
| `control_plane_vip`           | VIP for control-plane API endpoint         |
| `endpoint`                    | Full Kubernetes API endpoint (e.g., `https://192.168.1.100:6443`) |
| `talos_version`               | Talos OS version to deploy                 |

### Node Settings

| Variable                      | Description                                |
|-------------------------------|--------------------------------------------|
| `control_plane_count`         | Number of control-plane nodes              |
| `worker_count`                | Number of worker nodes                     |
| `control_plane_name_prefix`   | Prefix for control-plane VM names          |
| `worker_name_prefix`          | Prefix for worker VM names                 |
| `cp_cpus`, `cp_memory_mb`     | vCPU and RAM for control-plane VMs         |
| `worker_cpus`, `worker_memory_mb` | vCPU and RAM for worker VMs          |
| `disk_size_gb`                | Root disk size in GB for all VMs           |

## Deployment Steps

1. Clone & Initialize
   ```bash
    git clone iaac-talos
    cd terraform
    terraform init
   ```

2. Define Variables
  Create a `terraform.tfvars` file or pass values via CLI.
   ```hcl
    vsphere_user               = "administrator@vsphere.local"
    vsphere_password           = "your-password"
    vsphere_server             = "vcenter.yourdomain.com"
    datacenter                 = "Datacenter"
    datastore                  = "datastore1"
    vm_cluster_name            = "Cluster01"
    vm_folder                  = "Talos-VMs"
    network_name               = "VM Network"
    content_library_name       = "TalosLibrary"
    content_library_item_name  = "Talos-1.6.0"
    cluster_name               = "talos-cluster"
    control_plane_vip          = "192.168.1.100"
    endpoint                   = "https://192.168.1.100:6443"
    talos_version              = "1.6.0"
    control_plane_count        = 3
    worker_count               = 2
    cp_cpus                    = 2
    cp_memory_mb               = 4096
    worker_cpus                = 2
    worker_memory_mb           = 4096
    disk_size_gb               = 40
    control_plane_name_prefix  = "cp"
    worker_name_prefix         = "worker"
   ```

3. Apply Terraform
   ```bash
    terraform apply
   ```

>   This will:
> * Provision VMs on vSphere
> * Bootstrap a Talos-based Kubernetes control plane
> * Output the `kubeconfig` to interact with your cluster


## Outputs
| Output              | Description                                             |
| ------------------- | ------------------------------------------------------- |
| `control_plane_ips` | IP addresses of control-plane nodes                     |
| `worker_ips`        | IP addresses of worker nodes                            |
| `kubeconfig`        | Raw Kubeconfig to access the cluster (sensitive)        |

## Cleanup

To destroy the entire environment:

```bash
terraform destroy
```

## References
* [Talos Docs](https://www.talos.dev/latest/)
* [Terraform vSphere Provider](https://registry.terraform.io/providers/vmware/vsphere/latest/docs)
* [Terraform Talos Provider](https://registry.terraform.io/providers/siderolabs/talos/latest/docs)