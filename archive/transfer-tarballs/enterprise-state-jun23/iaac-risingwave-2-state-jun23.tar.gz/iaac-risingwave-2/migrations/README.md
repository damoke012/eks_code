# migrations/

SQL migration scripts managed by **Flyway** (Phase 2 — Tim).

## Naming convention

```
V{version}__{description}.sql
```

Examples:
- `V1__create_risingwave_sources.sql`
- `V2__add_materialized_views.sql`
- `V3__alter_sink_configuration.sql`

## Running locally

```bash
flyway \
  -url="jdbc:postgresql://localhost:4567/dev?user=root" \
  -locations="filesystem:migrations" \
  info
```

## Running in CI

Use the `flyway-migrate.yaml` workflow with `dry_run=true` to preview, then re-run with `dry_run=false` to apply.

## Required GitHub secrets

| Secret | Description |
|---|---|
| `PG_JDBC_URL` | JDBC connection URL for the target Postgres instance |
| `PG_USER` | Database username |
| `PG_PASSWORD` | Database password |
