#!/usr/bin/env bash
# deploy.sh — Octopus runs this to apply Terraform and bootstrap the cluster.
# Invoked by Octopus Deploy with environment variables injected via the project.
set -euo pipefail

ENVIRONMENT="${ENVIRONMENT:-op-usxpress-dev}"
CLUSTER_NAME="${CLUSTER_NAME:-risingwave-${ENVIRONMENT}}"
AWS_REGION="${AWS_REGION:-us-east-1}"
KUBECONFIG_PATH="${KUBECONFIG_PATH:-/tmp/kubeconfig}"

echo "==> [deploy.sh] Environment : ${ENVIRONMENT}"
echo "==> [deploy.sh] Cluster     : ${CLUSTER_NAME}"
echo "==> [deploy.sh] Region      : ${AWS_REGION}"

# ── 1. Terraform apply ──────────────────────────────────────────────────────
echo ""
echo "==> [Step 1] Terraform apply"
pushd "$(dirname "$0")/../terraform" > /dev/null

terraform init -input=false
terraform workspace select "${ENVIRONMENT}" 2>/dev/null || terraform workspace new "${ENVIRONMENT}"
terraform apply \
  -var="environment=${ENVIRONMENT}" \
  -var="cluster_name=${CLUSTER_NAME}" \
  -var="aws_region=${AWS_REGION}" \
  -auto-approve

popd > /dev/null

# ── 2. Update kubeconfig ─────────────────────────────────────────────────────
echo ""
echo "==> [Step 2] Update kubeconfig for ${CLUSTER_NAME}"
aws eks update-kubeconfig \
  --region "${AWS_REGION}" \
  --name "${CLUSTER_NAME}" \
  --kubeconfig "${KUBECONFIG_PATH}"

export KUBECONFIG="${KUBECONFIG_PATH}"

# ── 3. Verify cluster connectivity ──────────────────────────────────────────
echo ""
echo "==> [Step 3] Cluster connectivity check"
kubectl cluster-info --request-timeout=15s

# ── 4. Apply namespace (idempotent) ─────────────────────────────────────────
echo ""
echo "==> [Step 4] Ensure namespace exists"
kubectl create namespace risingwave --dry-run=client -o yaml | kubectl apply -f -

# ── 5. Bootstrap / sync manifests via Kustomize ──────────────────────────────
echo ""
echo "==> [Step 5] Apply kustomize manifests — ${ENVIRONMENT}"
MANIFESTS_DIR="$(dirname "$0")/../manifests/${ENVIRONMENT}"

if [[ ! -d "${MANIFESTS_DIR}" ]]; then
  echo "ERROR: manifests directory not found: ${MANIFESTS_DIR}"
  exit 1
fi

kubectl apply --server-side -k "${MANIFESTS_DIR}"

# ── 6. Wait for operator to be ready ────────────────────────────────────────
echo ""
echo "==> [Step 6] Wait for RisingWave operator rollout"
kubectl rollout status deployment/risingwave-operator-controller-manager \
  -n risingwave-operator-system \
  --timeout=180s

# ── 7. Wait for RisingWave CR to be ready ───────────────────────────────────
echo ""
echo "==> [Step 7] Wait for RisingWave CR — risingwave"
kubectl wait risingwave/risingwave \
  -n risingwave \
  --for=condition=Running \
  --timeout=300s

echo ""
echo "==> [deploy.sh] Done. Deployment to ${ENVIRONMENT} succeeded."
