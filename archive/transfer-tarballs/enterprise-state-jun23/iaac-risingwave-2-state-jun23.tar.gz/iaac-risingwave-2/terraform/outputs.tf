output "s3_bucket_name" {
  description = "Name of the RisingWave S3 bucket"
  value       = aws_s3_bucket.risingwave.bucket
}

output "s3_bucket_arn" {
  description = "ARN of the RisingWave S3 bucket"
  value       = aws_s3_bucket.risingwave.arn
}

output "irsa_role_arn" {
  description = "IAM role ARN to annotate on the RisingWave service account"
  value       = aws_iam_role.risingwave_irsa.arn
}
