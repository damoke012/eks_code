terraform {
  required_version = ">= 1.6"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  backend "s3" {
    # Populated by -backend-config or workspace-specific tfvars.
    # Run: terraform init -backend-config=backend.hcl
    bucket         = "lazy-tf-state-65v583i6my68y6x9"
    key            = "iaac/risingwave/op-usxpress-dev.tfstate"
    region         = "us-east-2"
  }
}

provider "aws" {
  region = var.region

  profile = var.aws_profile
}

# ── S3 bucket for RisingWave object storage ──────────────────────────────────
resource "aws_s3_bucket" "risingwave" {
  bucket = "${var.s3_bucket_prefix}"
}

resource "aws_s3_bucket_versioning" "risingwave" {
  bucket = aws_s3_bucket.risingwave.id

  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "risingwave" {
  bucket = aws_s3_bucket.risingwave.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

resource "aws_s3_bucket_public_access_block" "risingwave" {
  bucket = aws_s3_bucket.risingwave.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# ── IRSA: IAM role for the RisingWave service account ────────────────────────
data "aws_eks_cluster" "cluster" {
  name = var.cluster_name
}

data "aws_iam_openid_connect_provider" "cluster" {
  url = data.aws_eks_cluster.cluster.identity[0].oidc[0].issuer
}

data "aws_iam_policy_document" "risingwave_assume_role" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRoleWithWebIdentity"]

    principals {
      type        = "Federated"
      identifiers = [data.aws_iam_openid_connect_provider.cluster.arn]
    }

    condition {
      test     = "StringEquals"
      variable = "${replace(data.aws_iam_openid_connect_provider.cluster.url, "https://", "")}:sub"
      values   = ["system:serviceaccount:risingwave:risingwave"]
    }

    condition {
      test     = "StringEquals"
      variable = "${replace(data.aws_iam_openid_connect_provider.cluster.url, "https://", "")}:aud"
      values   = ["sts.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "risingwave_irsa" {
  name               = "risingwave-irsa"
  assume_role_policy = data.aws_iam_policy_document.risingwave_assume_role.json
}

data "aws_iam_policy_document" "risingwave_s3" {
  statement {
    effect = "Allow"
    actions = [
      "s3:GetObject",
      "s3:PutObject",
      "s3:DeleteObject",
      "s3:ListBucket",
      "s3:GetBucketLocation",
    ]
    resources = [
      aws_s3_bucket.risingwave.arn,
      "${aws_s3_bucket.risingwave.arn}/*",
    ]
  }
}

resource "aws_iam_role_policy" "risingwave_s3" {
  name   = "risingwave-s3-access"
  role   = aws_iam_role.risingwave_irsa.id
  policy = data.aws_iam_policy_document.risingwave_s3.json
}
