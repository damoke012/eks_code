variable "cluster_name" {
  type = string
}

variable "region" {
  type    = string
  default = "us-east-2"
}

variable "aws_profile" {
  type = string
}

variable "oidc_issuer" {
  type = string
}

variable "namespace" {
  type    = string
  default = "risingwave"
}

variable "service_account" {
  type    = string
  default = "risingwave"
}

variable "s3_bucket_prefix" {
  type = string
}
