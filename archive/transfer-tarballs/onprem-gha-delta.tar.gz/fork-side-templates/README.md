# Fork-side dispatcher templates

These files are templates that belong in the **fork repos**, not in this repo.
They wire cloud forks (on `feature/onprem-support` branch only) to the
event-driven re-mirror workflow in `variant-inc/iaac-octopus-config`
(`.github/workflows/remirror-on-fork-push.yaml`).

## Zero cloud impact

Each template MUST be committed only to the `feature/onprem-support` branch of
the respective repo. It MUST NOT land on `master`. Cloud's release pipeline
on master stays byte-identical to upstream.

If/when `feature/onprem-support` is ever PRed upstream, these dispatcher
files must be stripped from the PR in the same way other on-prem-only
changes are gated (env flags, `count = var.use_eks_api ? 0 : 1`, etc.).

## Files

| Template | Target repo | Target path |
|---|---|---|
| `mage-runner-onprem-dispatch.yaml` | `variant-inc/mage-runner` | `.github/workflows/onprem-dispatch.yaml` |
| `terraform-variant-apps-onprem-dispatch.yaml` | `variant-inc/terraform-variant-apps` | `.github/workflows/onprem-dispatch.yaml` |

Templates are stored here (in `iaac-octopus-config`) at
`deploy/scripts/onprem/fork-side-templates/`.

## One-time secret setup

In each fork repo, store a PAT as `IAAC_OCTOPUS_DISPATCH_PAT` via the UI:
Settings -> Secrets and variables -> Actions -> New repository secret.

The PAT needs `repo` scope including `repo:dispatch` on
`variant-inc/iaac-octopus-config`. Recommend a fine-grained PAT scoped to
that single repo with `Contents: read` + `Metadata: read` +
`Dispatch: write` permissions, expiring in 90 days.

## Checklist per fork repo

From your WSL2 checkout of the fork (on branch `feature/onprem-support`):

```bash
# mage-runner fork
cd ~/mage-runner
git checkout feature/onprem-support
mkdir -p .github/workflows
cp /path/to/iaac-octopus-config/deploy/scripts/onprem/fork-side-templates/mage-runner-onprem-dispatch.yaml \
   .github/workflows/onprem-dispatch.yaml
git add .github/workflows/onprem-dispatch.yaml
git commit -m "ci(onprem): dispatch to iaac-octopus-overrides after package push

Feature-branch-only: fires repository_dispatch to trigger on-prem release
re-mirror for enrolled apps. Does NOT exist on master. Zero cloud impact."
# DO NOT push yet — first set IAAC_OCTOPUS_DISPATCH_PAT secret in the repo
```

Repeat for terraform-variant-apps fork.

## Verification

After pushing and the next `feature/onprem-support` push:

1. In fork repo Actions tab: `On-Prem Dispatch` workflow should run and show
   `Fire repository_dispatch` step green.
2. In `iaac-octopus-overrides` Actions tab: `Re-mirror on-prem releases
   (fork package published)` should auto-run within seconds of step 1.
3. Check OnPremise Octopus space for updated release records on enrolled apps.

## Related files in iaac-octopus-config

- `.github/workflows/remirror-on-fork-push.yaml` — target workflow for the
  dispatch. Runs `mirror-release.py --all` for enrolled apps.
- `deploy/scripts/onprem/mirror-release.py` — script that reads the
  enrollment manifest and mirrors cloud releases into OnPremise space.
- `deploy/scripts/onprem/onprem-enrolled-apps.yaml` — declarative list of
  apps enrolled for on-prem release mirroring. Edit this to add/remove apps.
