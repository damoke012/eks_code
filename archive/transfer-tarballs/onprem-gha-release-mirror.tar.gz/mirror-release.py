#!/usr/bin/env python3
"""
Mirror a cloud Octopus release to the OnPremise space.

Reads the latest release from the cloud USXpress space, overrides packages
that need on-prem-specific forks (e.g. mage-runner with cloud-safe namespace
patch), and creates a release in OnPremise. Idempotent: skips if the version
already exists in OnPremise.

Usage:
    OCTOPUS_API_KEY=API-... ./mirror-release.py [--project brands-api] [--dry-run]
    OCTOPUS_API_KEY=API-... ./mirror-release.py --all   # mirror all module-coverage apps

Cloud-safety: reads Spaces-245 (USXpress) read-only; only writes to
Spaces-302 (OnPremise).
"""

import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request

OCTO = "https://octopus.usxpress.io"
SRC_SPACE = "Spaces-245"   # USXpress (cloud, read-only)
DST_SPACE = "Spaces-302"   # OnPremise (write target)
DST_CHANNEL_NAME = "feature"

# Packages that must be replaced with the on-prem fork version. Each entry:
#   {package_reference_name: {"feed_id": "Feeds-...", "package_id": "...", "tag_filter": "<substring>"}}
# tag_filter is the substring that must appear in the version's pre-release tag
# (e.g., "feature-onprem-support" for our mage-runner fork). The latest matching
# version is selected at mirror time.
PACKAGE_OVERRIDES = {
    "mage-runner": {
        "feed_id": "Feeds-1587",
        "package_id": "dx-packages20250326072200906200000001/mage-runner/mage-runner",
        "tag_filter": "feature-onprem-support",
    },
    "terraform": {
        "feed_id": "Feeds-1587",
        "package_id": "dx-packages20250326072200906200000001/terraform-variant-apps/terraform-variant-apps",
        "tag_filter": "feature-onprem-support",
    },
}


def api(method, path, body=None, key=None):
    req = urllib.request.Request(
        f"{OCTO}{path}",
        data=json.dumps(body).encode() if body is not None else None,
        headers={
            "X-Octopus-ApiKey": key,
            "Content-Type": "application/json",
        },
        method=method,
    )
    try:
        with urllib.request.urlopen(req) as r:
            data = r.read()
            return json.loads(data) if data else {}
    except urllib.error.HTTPError as e:
        err = e.read().decode()[:400]
        print(f"  HTTP {e.code} on {method} {path}: {err}", file=sys.stderr)
        return None


def find_project(space_id, name, key):
    d = api("GET", f"/api/{space_id}/projects?partialName={urllib.parse.quote(name)}&take=10", key=key)
    if not d:
        return None
    for p in d.get("Items", []):
        if p["Name"] == name:
            return p
    return None


def get_latest_release(space_id, project_id, key):
    d = api("GET", f"/api/{space_id}/projects/{project_id}/releases?take=1", key=key)
    if not d or not d.get("Items"):
        return None
    return d["Items"][0]


def get_existing_releases(space_id, project_id, key, take=20):
    d = api("GET", f"/api/{space_id}/projects/{project_id}/releases?take={take}", key=key)
    if not d:
        return []
    return [r["Version"] for r in d.get("Items", [])]


def get_channel_by_name(space_id, project_id, name, key):
    d = api("GET", f"/api/{space_id}/projects/{project_id}/channels?take=20", key=key)
    if not d:
        return None
    for c in d.get("Items", []):
        if c["Name"] == name:
            return c
    return None


def get_latest_matching_version(space_id, feed_id, package_id, tag_filter, key):
    """Find the highest-numbered version whose Version string contains tag_filter."""
    encoded = urllib.parse.quote(package_id, safe="")
    d = api(
        "GET",
        f"/api/{space_id}/feeds/{feed_id}/packages/versions?packageId={encoded}&filter={urllib.parse.quote(tag_filter)}&take=1",
        key=key,
    )
    if not d or not d.get("Items"):
        return None
    return d["Items"][0]["Version"]


def apply_overrides(packages, key):
    """Replace any package in `packages` whose ref name is in PACKAGE_OVERRIDES
    with the latest matching version from the configured feed."""
    overridden = []
    for sp in packages:
        ref = sp.get("PackageReferenceName") or sp.get("ActionName") or ""
        if ref in PACKAGE_OVERRIDES:
            cfg = PACKAGE_OVERRIDES[ref]
            latest = get_latest_matching_version(
                DST_SPACE, cfg["feed_id"], cfg["package_id"], cfg["tag_filter"], key,
            )
            if not latest:
                print(f"  ERROR: no version of {ref} matching tag {cfg['tag_filter']!r} found in feed")
                return None
            old = sp.get("Version")
            sp["Version"] = latest
            overridden.append((ref, old, latest))
    return overridden


def mirror_release(project_name, key, dry_run=False):
    print(f"\n{'='*60}")
    print(f"Mirroring: {project_name}")
    print(f"  source: USXpress ({SRC_SPACE})")
    print(f"  target: OnPremise ({DST_SPACE}) channel={DST_CHANNEL_NAME}")

    src_proj = find_project(SRC_SPACE, project_name, key)
    if not src_proj:
        print(f"  ERROR: project {project_name!r} not found in USXpress space")
        return False

    latest = get_latest_release(SRC_SPACE, src_proj["Id"], key)
    if not latest:
        print(f"  ERROR: no releases found for {project_name} in USXpress")
        return False

    version = latest["Version"]
    packages = json.loads(json.dumps(latest.get("SelectedPackages", [])))  # deep copy
    print(f"  cloud release: {version}")
    for sp in packages:
        print(f"    {sp.get('PackageReferenceName','?'):24} = {sp.get('Version','?')}  (cloud)")

    dst_proj = find_project(DST_SPACE, project_name, key)
    if not dst_proj:
        print(f"  ERROR: project {project_name!r} not found in OnPremise space")
        print(f"         (run Bento import first)")
        return False

    existing = get_existing_releases(DST_SPACE, dst_proj["Id"], key)
    if version in existing:
        print(f"  SKIP: version {version} already exists in OnPremise")
        return True

    channel = get_channel_by_name(DST_SPACE, dst_proj["Id"], DST_CHANNEL_NAME, key)
    if not channel:
        print(f"  ERROR: {DST_CHANNEL_NAME!r} channel not found in OnPremise project")
        return False

    overrides = apply_overrides(packages, key)
    if overrides is None:
        return False
    if overrides:
        print(f"  Applied on-prem package overrides:")
        for ref, old, new in overrides:
            print(f"    {ref:24} {old} -> {new}")
    else:
        print(f"  No on-prem package overrides apply")

    release_body = {
        "ProjectId": dst_proj["Id"],
        "ChannelId": channel["Id"],
        "Version": version,
        "SelectedPackages": packages,
    }

    if dry_run:
        print(f"  DRY-RUN: would create release {version} on OnPremise/{project_name}")
        print(f"           channel={channel['Name']} ({channel['Id']})")
        for sp in packages:
            print(f"           {sp.get('PackageReferenceName','?'):24} = {sp.get('Version','?')}")
        return True

    result = api("POST", f"/api/{DST_SPACE}/releases", body=release_body, key=key)
    if not result:
        print(f"  ERROR: release creation failed (check channel rules)")
        return False

    print(f"  CREATED: release {result.get('Id')} version {result.get('Version')}")
    return True


def load_enrolled_apps():
    """Extract app names from onprem-enrolled-apps.yaml next to this script.

    Deliberately uses a minimal regex parser instead of PyYAML so the script
    has zero extra dependencies in CI. The manifest format is fixed and simple:
    each app is declared as `  - name: <identifier>` under the `apps:` key.
    """
    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(here, "onprem-enrolled-apps.yaml")
    if not os.path.exists(path):
        sys.exit(f"enrollment manifest not found: {path}")
    names = []
    with open(path) as f:
        for line in f:
            m = re.match(r"^\s*-\s+name:\s+([A-Za-z0-9][A-Za-z0-9_-]*)\s*$", line)
            if m:
                names.append(m.group(1))
    if not names:
        sys.exit(f"no apps enrolled in {path}")
    return names


def main():
    ap = argparse.ArgumentParser(description="Mirror cloud Octopus releases to OnPremise space")
    ap.add_argument("--project", "-p",
                    help="Single project to mirror (bypasses enrollment manifest)")
    ap.add_argument("--all", action="store_true",
                    help="Mirror all apps listed in onprem-enrolled-apps.yaml")
    ap.add_argument("--dry-run", action="store_true",
                    help="Preview without creating releases")
    args = ap.parse_args()

    if not (args.all or args.project):
        ap.error("specify --all (read enrollment manifest) or --project NAME")

    key = os.environ.get("OCTOPUS_API_KEY")
    if not key:
        sys.exit("OCTOPUS_API_KEY not set")

    if args.all:
        projects = load_enrolled_apps()
        print(f"Enrolled apps ({len(projects)}): {', '.join(projects)}")
    else:
        projects = [args.project]

    ok = 0
    fail = 0
    for name in projects:
        if mirror_release(name, key, args.dry_run):
            ok += 1
        else:
            fail += 1

    print(f"\nDone: {ok} ok, {fail} failed")
    if fail > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
