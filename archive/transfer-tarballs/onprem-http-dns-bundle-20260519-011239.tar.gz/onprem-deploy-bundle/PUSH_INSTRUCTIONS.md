# On-prem HTTP DNS deploy bundle — PUSH INSTRUCTIONS

Bundle date: **2026-05-18**.
Scope: **HTTP DNS only** — piece 1 (istio-ingressgateway) + piece 2 (external-dns + Route 53) + brands-api smoke test.

Excluded from this bundle (out of scope for now):
- GHA OIDC provider creation (no current consumer needs it)
- Tim's `risingwave-poc` workflow (RW work)
- Cert-manager public ClusterIssuer (piece 3 — later)

---

## Order of operations

```
A. iaac-talos       (Terraform) → trigger Octopus runbook → extd-usxpress-io role created
B. iaac-talos-flux-platform (Flux manifests for istio-ingress + external-dns)
C. iaac-talos-flux-cluster  (Kustomization wiring)
                                                ↓
                              Flux reconciles → workloads come up (~5 min)
                                                ↓
D. kubectl apply (brands-api Gateway) — smoke test
                                                ↓
E. dig + curl from VPN — verify HTTP DNS end-to-end
```

A is the gate — must finish before B/C have meaningful effect.

---

## A. `variant-inc/iaac-talos` — Terraform IRSA module

**Branch**: `feature/irsa` (or whichever active branch). PR to main when ready.
**Destination**: `deploy/terraform/modules/irsa/`

### Files in `for-iaac-talos/`

| File | Action |
|---|---|
| `extd-usxpress-io-role.tf` | **COPY** as new file into module dir |
| `extd-usxpress-io-output-APPEND.tf` | **APPEND** contents to existing `outputs.tf` |

### Commands

```bash
cd ~/work/iaac-talos
git checkout feature/irsa
git pull --ff-only origin feature/irsa

# Copy the new TF file
cp ~/onprem-deploy-bundle/for-iaac-talos/extd-usxpress-io-role.tf  deploy/terraform/modules/irsa/

# Append the output block to existing outputs.tf
echo "" >> deploy/terraform/modules/irsa/outputs.tf
cat ~/onprem-deploy-bundle/for-iaac-talos/extd-usxpress-io-output-APPEND.tf \
  >> deploy/terraform/modules/irsa/outputs.tf

# Validate locally before pushing
cd deploy/terraform
terraform init -backend=false
terraform validate

# Commit + push
cd ..
git status
git add deploy/terraform/modules/irsa/
git diff --cached deploy/terraform/modules/irsa/outputs.tf | head -30   # verify only an addition
git commit -m "feat(irsa): add extd-usxpress-io source role for on-prem external-dns

Role name matches the existing wildcard trust pattern on
iaac-route53-zone (arn:aws:iam::*:role/extd-usxpress-io-*) so no
network-team trust patch is required."
git push origin feature/irsa
```

### After push — apply via Octopus

The TF doesn't apply via `terraform apply` locally. It applies via the
**iaac-talos Octopus runbook**:

1. Merge the PR to the branch Octopus tracks
2. Trigger the iaac-talos runbook in the Octopus UI
3. Watch the apply logs — expect: `+ aws_iam_role.extd_usxpress_io`, `+ aws_iam_role_policy.extd_usxpress_io_assume`, `+ output.extd_usxpress_io_role_arn`

### Verify after Octopus apply

```bash
# Role should now exist
aws iam get-role --role-name extd-usxpress-io-op-usxpress-dev --profile usx-dev \
  --query 'Role.Arn'
# Expected: arn:aws:iam::700736442855:role/extd-usxpress-io-op-usxpress-dev
```

---

## B. `variant-inc/iaac-talos-flux-platform` — Flux manifests

**Branch**: `op-dev`
**Destination**: `infrastructure/`

### Contents

```
infrastructure/istio-ingress/
├── namespace.yaml     — PSA-privileged namespace
├── release.yaml       — HelmRelease for istio gateway chart
└── values.yaml        — ConfigMap with DaemonSet + hostNetwork values

infrastructure/external-dns/
├── namespace.yaml     — external-dns namespace
├── repository.yaml    — HelmRepository (flux-system ns)
└── release.yaml       — HelmRelease for extd-usxpress-io
```

### Commands

```bash
cd ~/work/iaac-talos-flux-platform
git checkout op-dev
git pull --ff-only origin op-dev

# Copy both directories — paths already at the right relative depth in the bundle
cp -r ~/onprem-deploy-bundle/for-iaac-talos-flux-platform/infrastructure/istio-ingress  infrastructure/
cp -r ~/onprem-deploy-bundle/for-iaac-talos-flux-platform/infrastructure/external-dns   infrastructure/

git status
git add infrastructure/istio-ingress/ infrastructure/external-dns/
git commit -m "feat(networking): istio-ingressgateway DaemonSet + external-dns

- istio-ingress: hostNetwork DaemonSet, binds 80/443 on every worker.
- external-dns: extd-usxpress-io mirroring cloud pattern. Uses wildcard
  trust on iaac-route53-zone via extd-usxpress-io-* naming. No
  network-team coordination required.
"
git push origin op-dev
```

---

## C. `variant-inc/iaac-talos-flux-cluster` — Kustomization wiring

**Branch**: `master`
**Destination**: `clusters/bm-dev/flux-system/infra.yaml` (APPEND only)

### Commands

```bash
cd ~/work/iaac-talos-flux-cluster
git checkout master
git pull --ff-only origin master

# Append both Kustomization snippets
echo "" >> clusters/bm-dev/flux-system/infra.yaml
cat ~/onprem-deploy-bundle/for-iaac-talos-flux-cluster/istio-ingress-kustomization-APPEND.yaml \
  >> clusters/bm-dev/flux-system/infra.yaml
echo "" >> clusters/bm-dev/flux-system/infra.yaml
cat ~/onprem-deploy-bundle/for-iaac-talos-flux-cluster/external-dns-kustomization-APPEND.yaml \
  >> clusters/bm-dev/flux-system/infra.yaml

# Verify the addition looks correct (no replacement, no edits to existing)
git diff clusters/bm-dev/flux-system/infra.yaml | head -80

git add clusters/bm-dev/flux-system/infra.yaml
git commit -m "feat(bm-dev): wire istio-ingress + external-dns Kustomizations"
git push origin master
```

### Wait for Flux reconciliation

```bash
kubectl config use-context admin@op-usxpress-dev

# Force reconcile (optional; Flux will catch the change within 10 min anyway)
flux reconcile source git infra
flux reconcile kustomization istio-ingress
flux reconcile kustomization external-dns

# Watch — both should reach READY=True within ~5 min
kubectl get ks -n flux-system | grep -E "istio-ingress|external-dns"

# Pod state
kubectl get pods -n istio-ingress -o wide       # 5 DaemonSet pods, one per worker
kubectl get pods -n external-dns -o wide        # 1 deployment pod

# external-dns log check — confirm IRSA + AssumeRole work
kubectl logs -n external-dns -l app.kubernetes.io/name=external-dns --tail=30
# Expect: clean log entries, no AccessDenied / WebIdentityErr
# (the role's "All records are already up to date" message comes after a Gateway exists)
```

---

## D. Smoke test — apply brands-api Gateway

### File

`for-kubectl-apply/brands-api-gateway.yaml` → applied with `kubectl apply -f`

### Commands

```bash
# 1. PRE-FLIGHT RW protection check (per memory/feedback_protect_rw_onprem_workload.md)
kubectl get rw risingwave -n risingwave
kubectl get pods -n risingwave --no-headers | awk '$2 != "1/1" && $2 != "0/1"'
PGPASSWORD='WLThdeIQznAJ9RxSdWV3SaCFMY1yFjO1' \
  psql -h 10.10.82.26 -p 32567 -U root -d dev -c 'SELECT 1;'
# Save these outputs — re-run after apply, values must match

# 2. Apply the Gateway
kubectl apply -f ~/onprem-deploy-bundle/for-kubectl-apply/brands-api-gateway.yaml

# 3. Verify the Gateway resource exists
kubectl -n enterprise get gateway brands-api -o wide

# 4. Wait ~30s for external-dns to write the Route 53 record + Envoy to apply
sleep 30

# 5. Smoke test from VPN — direct worker IP first (proves istio-ingressgateway)
curl -v -H "Host: api.brands.dev.usxpress.io" http://10.10.82.26/
# Expected: real brands-api HTTP response (200 / health / etc.)

# 6. DNS resolution test (proves external-dns wrote the record)
dig +short api.brands.dev.usxpress.io
# Expected: one or more worker IPs (10.10.82.26, .27, .28, .178, .180)

# 7. End-to-end via DNS (proves the full pipeline)
curl -v http://api.brands.dev.usxpress.io/
# Expected: same brands-api response, resolved via DNS

# 8. POST-FLIGHT RW protection check — re-run step 1's commands, values MUST match
kubectl get rw risingwave -n risingwave
kubectl get pods -n risingwave --no-headers | awk '$2 != "1/1" && $2 != "0/1"'
PGPASSWORD='WLThdeIQznAJ9RxSdWV3SaCFMY1yFjO1' \
  psql -h 10.10.82.26 -p 32567 -U root -d dev -c 'SELECT 1;'
```

If post-flight differs from pre-flight in any meaningful way → execute Rollback (next section) immediately.

---

## Rollback (if anything goes sideways)

### Roll back just the Gateway (safest)

```bash
kubectl delete -f ~/onprem-deploy-bundle/for-kubectl-apply/brands-api-gateway.yaml
# DNS record auto-deletes (external-dns policy: sync), Envoy listener disappears
```

### Roll back the entire infrastructure

```bash
# Step 1: Revert cluster repo (stops Flux applying)
cd ~/work/iaac-talos-flux-cluster
git revert HEAD
git push origin master
flux reconcile kustomization istio-ingress
flux reconcile kustomization external-dns
# Kustomizations delete (prune=true), namespaces go away

# Step 2: Platform repo commit can stay — without cluster Kustomization, Flux doesn't apply it

# Step 3: Roll back Terraform (if needed)
# - Revert the iaac-talos PR
# - Trigger Octopus runbook again → destroys the role
```

---

## Quick file index

```
/PUSH_INSTRUCTIONS.md                              ← THIS FILE
for-iaac-talos/
  extd-usxpress-io-role.tf
  extd-usxpress-io-output-APPEND.tf
for-iaac-talos-flux-platform/
  infrastructure/istio-ingress/{namespace,release,values}.yaml
  infrastructure/external-dns/{namespace,repository,release}.yaml
for-iaac-talos-flux-cluster/
  istio-ingress-kustomization-APPEND.yaml
  external-dns-kustomization-APPEND.yaml
for-kubectl-apply/
  brands-api-gateway.yaml
```
