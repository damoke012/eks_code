# Talos Platform Reference

An on-premise Kubernetes platform reference built on **Talos Linux** running on **vSphere**, with **Cilium** as the CNI, **Istio Ambient** as the service mesh, and **Flux** driving GitOps for all platform infrastructure.

This repository contains the bootstrap Terraform and the Flux manifests that together stand up a complete cluster — from bare VMs through CNI, service mesh, certificate management, secret management, autoscaling, and observability. It is a sanitized reference; application workloads and org-specific identifiers have been stripped.

---

## Stack at a glance

| Layer | Component | Role |
|---|---|---|
| OS / Kubernetes | **Talos Linux** | Immutable, API-driven Kubernetes-native OS. Cluster is bootstrapped entirely via the Talos machine API — no SSH, no package managers. |
| Virtualization | **vSphere** | VMs are cloned from a Talos OVA in a Content Library. IPs are assigned via DHCP and read back through VMware Tools. |
| CNI | **Cilium** | Primary CNI, installed as a Talos `inline_manifest` at bootstrap. Istio compatibility mode (`cni.exclusive=false`, `socketLB.hostNamespaceOnly=true`, BPF masquerading disabled). |
| Load balancing | **Cilium L2 announcements** | Advertises LoadBalancer service IPs on the LAN via L2 (ARP/NDP) — no external LB appliance needed. |
| Service mesh | **Istio Ambient** (istiod + ztunnel + istio-cni) | Sidecar-less mesh. `ambient` profile, mTLS terminated by ztunnel, L4 policy at the node. |
| Cert mgmt | **cert-manager** + **istio-csr** | cert-manager issues the Istio root CA; istio-csr gives Istio workloads short-lived certs signed by cert-manager. |
| Secrets | **External Secrets Operator** | Pulls secrets from AWS Secrets Manager into Kubernetes `Secret` objects via `ClusterSecretStore`. |
| IRSA on-prem | **pod-identity-webhook** + **CloudFront-hosted OIDC** | Reproduces the EKS IRSA pattern on-prem: the Talos cluster publishes an OIDC discovery document via S3 + CloudFront, AWS trusts it as an OIDC provider, and workloads assume AWS IAM roles using projected service account tokens. |
| Autoscaling | **KEDA** | Event-driven pod autoscaling. |
| GitOps | **Flux v2** | Cluster watches a Git repo; every platform component is a `Kustomization` or `HelmRelease`. |
| Gateway API | Upstream `gateway-api` CRDs | Experimental channel, pinned tag. |
| Observability | **Prometheus** | Baseline metrics stack. |

---

## Repository layout

```
talos-platform-reference/
├── terraform/                          # Bootstrap: vSphere VMs → Talos → Cilium → Flux → IRSA
│   ├── main.tf                         # Wires modules together
│   ├── providers.tf                    # vSphere, Talos, Flux, AWS providers
│   ├── variables.tf
│   ├── outputs.tf
│   ├── deploy.ps1                      # Example CI/CD deploy wrapper (Octopus-style)
│   └── modules/
│       ├── vsphere_vm/                 # Clone VMs from OVA, read IPs back via VMware Tools
│       ├── cilium/                     # Render Cilium inline manifest for Talos
│       ├── talos/                      # Generate machine configs, bootstrap cluster
│       ├── flux/                       # Flux CLI bootstrap into the cluster
│       └── irsa/                       # S3 + CloudFront OIDC provider + example IAM roles
│
├── flux-cluster/                       # Per-cluster Flux entrypoint (what Flux reconciles first)
│   └── clusters/
│       └── onprem-dev/
│           └── flux-system/
│               ├── kustomization.yaml
│               ├── infra-source.yaml   # GitRepository pointing at flux-platform
│               └── infra.yaml          # All platform Kustomizations + dependsOn chain
│
└── flux-platform/                      # The actual platform manifests (pulled by flux-cluster)
    └── infrastructure/
        ├── cert-manager/
        ├── cert-manager-issuers/       # Self-signed root → istio-ca CA issuer
        ├── cilium-lb/                  # CiliumLoadBalancerIPPool + L2AnnouncementPolicy
        ├── external-secrets/           # ESO Helm release
        ├── external-secrets-config/    # ClusterSecretStore → AWS Secrets Manager
        ├── istio/
        │   ├── base/
        │   ├── istiod/
        │   ├── cni/
        │   └── ztunnel/
        ├── istio-csr/                  # cert-manager plugin that signs Istio workload certs
        ├── istio-namespace/
        ├── keda/
        ├── pod-identity-webhook/       # Mutating webhook that injects IRSA env/volumes
        └── prometheus/
```

---

## How it comes up

### Phase 1 — Terraform bootstrap (`terraform/`)

```hcl
module "vsphere_cp"      # clone N control-plane VMs, read IPs via VMware Tools
module "vsphere_worker"  # clone N worker VMs, read IPs via VMware Tools
module "cilium"          # render Cilium Helm chart as Talos inline_manifest
module "talos"           # generate machine configs, bootstrap first CP node,
                         #   join remaining CP + worker nodes
module "flux"            # install Flux CLI bootstrap into the cluster
module "irsa"            # S3 + CloudFront OIDC discovery + IAM roles
                         #   (optional — only if workloads need AWS access)
```

Key mechanics:

- **Cilium is installed at Talos bootstrap time**, not via Helm post-install. The Cilium module renders the Helm chart to YAML and hands it to Talos as an `inline_manifest`, so the control plane comes up already networked.
- **Control-plane VIP** is a shared virtual IP announced by Cilium L2, giving the Kubernetes API a stable address independent of individual control-plane node IPs.
- **Flux bootstrap** installs the Flux controllers and commits a `GitRepository` pointing at this repo's `flux-platform/` branch. From that moment, all further platform changes are Git-driven.

### Phase 2 — Flux takes over (`flux-cluster/` + `flux-platform/`)

Flux reconciles the kustomizations in `flux-cluster/clusters/onprem-dev/flux-system/infra.yaml`, which express the dependency chain:

```
istio-namespace
cert-manager
  └── cert-manager-issuers
       └── istio-csr
            └── istio-base
                 └── istiod
                      ├── istio-cni
                      └── ztunnel
cilium-lb
pod-identity-webhook
  └── external-secrets
       └── external-secrets-config
gateway-api (upstream CRDs)
prometheus
keda
```

All `Kustomization` resources use `dependsOn` to guarantee ordering — Flux won't apply `istio-csr` until `cert-manager-issuers` is healthy, won't apply `istiod` until `istio-base` is healthy, and so on.

---

## Notable design choices

### Cilium + Istio Ambient coexistence

Running Istio Ambient on top of Cilium requires a few non-default Cilium settings ([`terraform/main.tf`](terraform/main.tf)):

```hcl
"cni.exclusive"              = "false"   # let istio-cni install its chained plugin
"socketLB.hostNamespaceOnly" = "true"    # don't intercept ztunnel socket ops
"l7Proxy"                    = "false"
# BPF masquerading disabled — known incompat with Istio ambient link-local health checks
# (https://github.com/istio/istio/issues/52208)
```

### IRSA on-prem

Because there is no EKS control plane, the cluster self-hosts its own OIDC discovery:

1. Terraform creates an **S3 bucket** with two keys: `.well-known/openid-configuration` and `keys.json`.
2. A **CloudFront distribution** fronts the bucket (public HTTPS with an OAC-only S3 policy — bucket itself stays private).
3. An **IAM OIDC provider** in AWS is registered against the CloudFront URL.
4. The `keys.json` file is generated by a script ([`terraform/modules/irsa/scripts/jwks.sh`](terraform/modules/irsa/scripts/jwks.sh)) that reads the cluster's service-account signing key.
5. In-cluster, **pod-identity-webhook** (a mutating webhook) injects the projected token volume + `AWS_ROLE_ARN` env var into any pod whose ServiceAccount carries `eks.amazonaws.com/role-arn` — exactly the way EKS does it.

End result: workloads on-prem use the same `ServiceAccount` annotation and AWS SDK behavior as they would on EKS. No pod-level credential files, no long-lived IAM users.

### Cilium L2 LoadBalancer IPs

On-prem, there's no cloud LB provider. Cilium L2 advertises configured LoadBalancer IPs via ARP from a selected node set ([`flux-platform/infrastructure/cilium-lb/resources.yaml`](flux-platform/infrastructure/cilium-lb/resources.yaml)):

```yaml
kind: CiliumLoadBalancerIPPool
spec:
  blocks:
  - start: "10.0.0.20"
    stop: "10.0.0.254"
---
kind: CiliumL2AnnouncementPolicy
spec:
  nodeSelector:
    matchExpressions:
      - key: node-role.kubernetes.io/control-plane
        operator: DoesNotExist
```

Announcement is restricted to workers (control plane excluded) to avoid mixing traffic concerns.

### Istio root CA lifecycle

`cert-manager` issues a long-lived (10-year) self-signed root via `Issuer/selfsigned` → `Certificate/istio-ca`. `istio-csr` then acts as the gRPC signer that Istio workloads use to obtain short-lived certs. A small Job ([`flux-platform/infrastructure/cert-manager-issuers/root-ca-secret.yaml`](flux-platform/infrastructure/cert-manager-issuers/root-ca-secret.yaml)) extracts the root CA into the well-known `istio-root-ca` secret and `istio-ca-root-cert` ConfigMap that ztunnel and the sidecars expect.

---

## What this repo is **not**

- Not a drop-in deployment — placeholders (`example-*`, `0.0.0.0`, `000000000000`) must be replaced for your environment.
- No application workloads. Platform only.
- No secrets, no state, no kubeconfigs, no tfvars. Generate your own.
- No CI/CD wiring beyond `deploy.ps1` (example Octopus wrapper).

## Requirements

- vSphere 7+ with a Content Library containing the Talos OVA
- AWS account (for IRSA S3/CloudFront + Secrets Manager, if used)
- DHCP on the VM network (or adapt the vSphere module for static IPs)
- `terraform` ≥ 1.5, `flux` CLI, `talosctl`, `kubectl`
- A Git repo that Flux can pull from (fork this one)

## License

MIT — see [LICENSE](LICENSE).
