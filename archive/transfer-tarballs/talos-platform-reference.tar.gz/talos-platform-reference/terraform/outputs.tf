output "kubeconfig" {
  description = "Kubeconfig for the new cluster"
  value       = module.talos.kubeconfig_raw
  sensitive   = true
}

output "control_plane_ips" {
  description = "IP addresses of control-plane nodes"
  value       = module.vsphere_cp.ip_addresses
}

output "worker_ips" {
  description = "IP addresses of worker nodes"
  value       = module.vsphere_worker.ip_addresses
}

output "flux_manifests_path" {
  description = "Path in repository where Flux manifests are stored"
  value       = module.flux.path
}
