module "vsphere_cp" {
  source                    = "./modules/vsphere_vm"
  vm_count                  = var.control_plane_count
  vm_folder                 = var.vm_folder
  datacenter                = var.datacenter
  datastore                 = var.datastore
  vm_cluster_name           = var.vm_cluster_name
  content_library_name      = var.content_library_name
  content_library_item_name = var.content_library_item_name
  network_name              = var.network_name
  cpus                      = var.cp_cpus
  memory_mb                 = var.cp_memory_mb
  disk_size_gb              = var.disk_size_gb
  name_prefix               = var.control_plane_name_prefix
  sleep_seconds             = var.sleep_seconds
}

module "vsphere_worker" {
  source                    = "./modules/vsphere_vm"
  vm_count                  = var.worker_count
  vm_folder                 = var.vm_folder
  datacenter                = var.datacenter
  datastore                 = var.datastore
  vm_cluster_name           = var.vm_cluster_name
  content_library_name      = var.content_library_name
  content_library_item_name = var.content_library_item_name
  network_name              = var.network_name
  cpus                      = var.worker_cpus
  memory_mb                 = var.worker_memory_mb
  disk_size_gb              = var.disk_size_gb
  name_prefix               = var.worker_name_prefix
  sleep_seconds             = var.sleep_seconds
}

module "cilium" {
  source            = "./modules/cilium"
  chart_version     = var.cilium_chart_version
  cli_image         = var.cilium_cli_image
  control_plane_vip = var.control_plane_vip

  extra_set = {
    # security
    "enableRemoteNodeIdentity"  = "true"
    "encryption.enabled"        = "true"
    "encryption.type"           = "wireguard"
    "encryption.nodeEncryption" = "true"
    # experimental features so we won't enable them for now
    # "identityManagementMode"    = "operator"

    # performance
    "routingMode"           = "native"
    "ipv4NativeRoutingCIDR" = "10.244.0.0/16"

    "bandwidthManager.enabled" = "true"
    "bandwidthManager.bbr"     = "true"

    # Load Balancing
    "l2announcements.enabled"            = "true"
    "l2announcements.leaseDuration"      = "10s"
    "l2announcements.leaseRenewDeadline" = "3s"
    "l2announcements.leaseRetryPeriod"   = "1s"

    "k8sClientRateLimit.qps"   = "80"
    "k8sClientRateLimit.burst" = "200"

    "externalIPs" = "true"

    # istio compatibility
    "socketLB.hostNamespaceOnly" = "true"
    "cni.exclusive"              = "false"
    "l7Proxy"                    = "false"

    # Cilium's BPF masquerading is currently disabled by default, and has issues with Istio’s use of link-local IPs for Kubernetes health checking. 
    # Enabling BPF masquerading via bpf.masquerade=true is not currently supported, and results in non-functional pod health checks in Istio ambient. 
    # Cilium's default iptables masquerading implementation should continue to function correctly.
    # github issue: https://github.com/istio/istio/issues/52208
    # "bpf.masquerade"             = "true"
    # "bpf.distributedLRU.enabled" = "true"
    # "bpf.mapDynamicSizeRatio"    = "0.08"
    # experimental features so we won't enable them for now
    # "bpf.datapathMode"           = "netkit"
    # "bpfClockProbe"              = "true"

    # observability
    # "hubble.relay.enabled"             = "true"
    # "hubble.ui.enabled"                = "true"
    # "hubble.metrics.enableOpenMetrics" = "true"
    # "hubble.metrics.enabled"           = "{dns,drop,tcp,flow,icmp,port-distribution}"

    # "prometheus.enabled"              = "true"
    # "operator.prometheus.enabled"     = "true"
    # "hubble.relay.prometheus.enabled" = "true"
  }
}

module "talos" {
  source                    = "./modules/talos"
  cluster_name              = var.cluster_name
  control_plane_vip         = var.control_plane_vip
  endpoint                  = var.endpoint
  talos_version             = var.talos_version
  control_plane_ips         = module.vsphere_cp.ip_addresses
  worker_ips                = module.vsphere_worker.ip_addresses
  control_plane_count       = var.control_plane_count
  worker_count              = var.worker_count
  control_plane_name_prefix = var.control_plane_name_prefix
  worker_name_prefix        = var.worker_name_prefix

  inline_manifests = [module.cilium.inline_manifest]

  depends_on = [module.vsphere_cp, module.vsphere_worker]
}

locals {
  kubeconfig_raw = module.talos.kubeconfig_raw
  kubeconfig     = yamldecode(local.kubeconfig_raw)
  
  cluster_host = try(
    local.kubeconfig.clusters[0].cluster.server,
    "https://localhost:6443"
  )
  cluster_endpoint = replace(replace(local.cluster_host, "https://", ""), "http://", "")
}

module "flux" {
  source = "./modules/flux"

  target_path      = var.flux_target_path
  cluster_endpoint = local.cluster_endpoint

  depends_on = [module.talos]
}
