if ($PSEdition -eq "Core") {
  $PSStyle.OutputRendering = "PlainText"
}

$ErrorActionPreference = "Stop"
$InformationPreference = "Continue"
$RootPath = Get-Location

Trap {
  Write-Error $_ -ErrorAction Continue
  Set-Location $RootPath
  exit 1
}

$OctopusParameters.GetEnumerator() `
| Where-Object { $_.Key -like "TF_*" } `
| ForEach-Object {
  $key = $_.Key
  $value = $_.Value
  try {
    [Environment]::SetEnvironmentVariable($key, $value)
  }
  catch {
    [Environment]::SetEnvironmentVariable($key, ($value | ConvertTo-Json))
  }
}

$env:S3_BUCKET           = $S3_BUCKET
$env:AWS_DEFAULT_REGION  = $AWS_DEFAULT_REGION
$env:TfDestroy           = $TfDestroy

# ---------------------------------------------
Write-Host "`n[STEP] Running Terraform"

Set-Location terraform
tfswitch

ce terraform init -no-color `
  -backend-config="bucket=$S3_BUCKET" `
  -backend-config="key=iaac/talos/cluster.tfstate" `
  -backend-config="region=$AWS_DEFAULT_REGION" `
  -backend-config="encrypt=true"

if ($TfDestroy -eq "true") {
  ce terraform plan -destroy -out=tfplan -input=false -no-color
  ce terraform apply tfplan
}
else {
  ce terraform plan -out=tfplan -input=false -no-color

  if ($TfApply -eq "true") {
    ce terraform apply tfplan
    Write-Host "[STEP] Capturing Terraform outputs..."
    $terraformOutputs = ce terraform output -json | ConvertFrom-Json | ConvertTo-Yaml
    if (!(Test-Path "../../outputs")) {
      New-Item -ItemType Directory -Path "../../outputs"
    }
    
    $terraformOutputs | Out-File "../../outputs/terraform_outputs.yml" -Encoding utf8
    Write-Host "[STEP] Uploading outputs as Octopus artifact..."
    New-OctopusArtifact -Path "../../outputs/terraform_outputs.yml"
  }
}

Set-Location $RootPath
Write-Host "`n Terraform Talos Cluster Deployment Complete"
