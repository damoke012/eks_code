terraform {
  required_providers {
    flux = {
      source = "fluxcd/flux"
    }
  }
}

locals {
  is_windows  = length(regexall("^[A-Za-z]:/", abspath(path.root))) > 0
  interpreter = local.is_windows ? ["PowerShell", "-NoProfile", "-NonInteractive", "-Command"] : ["/bin/bash", "-c"]
  
  endpoint_parts = split(":", var.cluster_endpoint)
  host = local.endpoint_parts[0]
  port = length(local.endpoint_parts) > 1 ? local.endpoint_parts[1] : "6443"
  
  wait_script = local.is_windows ? (<<-PS
    $targetHost = "${local.host}"
    $targetPort = ${local.port}
    $maxRetries = ${var.max_retries}
    $retryInterval = ${var.retry_interval}
    
    Write-Host "Waiting for cluster API at ${local.host}:${local.port}..."
    
    for ($i = 1; $i -le $maxRetries; $i++) {
      Write-Host "Attempt $i of $maxRetries..."
      
      $tcpClient = $null
      try {
        $tcpClient = New-Object System.Net.Sockets.TcpClient
        $tcpClient.Connect($targetHost, $targetPort)
        
        if ($tcpClient.Connected) {
          Write-Host "Successfully connected to cluster API!"
          $tcpClient.Close()
          exit 0
        }
      } catch {
        Write-Host "Not ready yet: $_"
        if ($tcpClient) { $tcpClient.Close() }
      }
      
      if ($i -lt $maxRetries) {
        Write-Host "Waiting $retryInterval seconds before retry..."
        Start-Sleep -Seconds $retryInterval
      }
    }
    
    Write-Host "Failed to connect after $maxRetries attempts"
    exit 1
  PS
  ) : (<<-SH
    host="${local.host}"
    port="${local.port}"
    max_retries="${var.max_retries}"
    retry_interval="${var.retry_interval}"
    
    echo "Waiting for cluster API at ${local.host}:${local.port}..."
    
    for i in $(seq 1 $max_retries); do
      echo "Attempt $i of $max_retries..."
      
      if timeout 5 bash -c "</dev/tcp/$host/$port" 2>/dev/null; then
        echo "Successfully connected to cluster API!"
        exit 0
      else
        echo "Not ready yet"
      fi
      
      if [ $i -lt $max_retries ]; then
        echo "Waiting $retry_interval seconds before retry..."
        sleep $retry_interval
      fi
    done
    
    echo "Failed to connect after $max_retries attempts"
    exit 1
  SH
  )
}

resource "terraform_data" "wait_for_cluster" {
  triggers_replace = {
    always_run = timestamp()
  }

  provisioner "local-exec" {
    interpreter = local.interpreter
    command     = local.wait_script
  }
}

resource "flux_bootstrap_git" "this" {
  embedded_manifests = true
  path               = var.target_path
  components_extra   = var.components_extra
  
  depends_on = [terraform_data.wait_for_cluster]
}