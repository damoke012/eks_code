variable "target_path" {
  description = "Path in repository for this cluster/environment"
  type        = string
}

variable "components_extra" {
  description = "Extra Flux components to install"
  type        = list(string)
  default     = []
}

variable "cluster_endpoint" {
  description = "Kubernetes API endpoint (host:port)"
  type        = string
}

variable "max_retries" {
  description = "Maximum number of connection attempts"
  type        = number
  default     = 20
}

variable "retry_interval" {
  description = "Seconds to wait between retry attempts"
  type        = number
  default     = 10
}
