terraform {
  required_providers {
    talos = {
      source = "siderolabs/talos"
    }
  }
}

resource "talos_machine_secrets" "cluster" {
  talos_version = var.talos_version
}

data "talos_machine_configuration" "cp" {
  cluster_name     = var.cluster_name
  machine_type     = "controlplane"
  cluster_endpoint = var.endpoint
  machine_secrets  = talos_machine_secrets.cluster.machine_secrets
  talos_version    = var.talos_version

  config_patches = [
    yamlencode({
      cluster = {
        network         = { cni = { name = "none" } }
        proxy           = { disabled = true }
        inlineManifests = var.inline_manifests
      }
    })
  ]
}

data "talos_machine_configuration" "worker" {
  cluster_name     = var.cluster_name
  machine_type     = "worker"
  cluster_endpoint = var.endpoint
  machine_secrets  = talos_machine_secrets.cluster.machine_secrets
  talos_version    = var.talos_version

  config_patches = [
    yamlencode({
      cluster = {
        network = { cni = { name = "none" } }
        proxy   = { disabled = true }
      }
    })
  ]
}

resource "talos_machine_configuration_apply" "init" {
  client_configuration        = talos_machine_secrets.cluster.client_configuration
  machine_configuration_input = data.talos_machine_configuration.cp.machine_configuration
  node                        = var.control_plane_ips[0]

  config_patches = [
    yamlencode({
      machine = {
        network = {
          hostname = "${var.control_plane_name_prefix}-1"
          interfaces = [
            {
              interface = "eth0"
              dhcp      = true
              vip = {
                ip = var.control_plane_vip
              }
            }
          ]
        }
      }
    })
  ]
}

resource "talos_machine_bootstrap" "init" {
  depends_on           = [talos_machine_configuration_apply.init]
  node                 = var.control_plane_ips[0]
  endpoint             = var.control_plane_ips[0]
  client_configuration = talos_machine_secrets.cluster.client_configuration
}

resource "talos_machine_configuration_apply" "join_cp" {
  count                       = max(var.control_plane_count - 1, 0)
  client_configuration        = talos_machine_secrets.cluster.client_configuration
  machine_configuration_input = data.talos_machine_configuration.cp.machine_configuration
  node                        = var.control_plane_ips[count.index + 1]

  config_patches = [
    yamlencode({
      machine = {
        network = {
          hostname = "${var.control_plane_name_prefix}-${count.index + 2}"
          interfaces = [
            {
              interface = "eth0"
              dhcp      = true
              vip = {
                ip = var.control_plane_vip
              }
            }
          ]
      } }
    })
  ]

  depends_on = [talos_machine_bootstrap.init]
}

resource "talos_machine_configuration_apply" "join_workers" {
  count                       = var.worker_count
  client_configuration        = talos_machine_secrets.cluster.client_configuration
  machine_configuration_input = data.talos_machine_configuration.worker.machine_configuration
  node                        = var.worker_ips[count.index]

  endpoint = var.worker_ips[count.index]

  config_patches = [
    yamlencode({
      machine = {
        network = {
          hostname = "${var.worker_name_prefix}-${count.index + 1}"
          interfaces = [
            {
              interface = "eth0"
              dhcp      = true
            }
          ]
      } }
    })
  ]

  depends_on = [talos_machine_bootstrap.init]
}

resource "talos_cluster_kubeconfig" "kube" {
  depends_on           = [talos_machine_bootstrap.init]
  client_configuration = talos_machine_secrets.cluster.client_configuration
  node                 = var.control_plane_ips[0]
}
