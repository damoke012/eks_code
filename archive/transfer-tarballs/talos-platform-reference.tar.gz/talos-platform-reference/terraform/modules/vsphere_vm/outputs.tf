output "ip_addresses" {
  description = "IP addresses of the created VMs"
  value       = compact([for vm in data.vsphere_virtual_machine.vm_info : try(vm.default_ip_address, "")])
}
