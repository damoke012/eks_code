variable "datacenter" {
  description = "vSphere datacenter name"
  type        = string
}

variable "datastore" {
  description = "vSphere datastore name"
  type        = string
}

variable "vm_cluster_name" {
  description = "The name of the vSphere cluster"
  type        = string
}

variable "content_library_name" {
  description = "Name of the vSphere Content Library containing the Talos OVA"
  type        = string
}

variable "content_library_item_name" {
  description = "Name of the Talos OVA item in that Content Library"
  type        = string
}

variable "network_name" {
  description = "vSphere network name to attach VM NICs to"
  type        = string
}

variable "name_prefix" {
  description = "Prefix for naming each VM"
  type        = string
}

variable "vm_count" {
  description = "How many VMs to create"
  type        = number
}

variable "cpus" {
  description = "Number of vCPUs per VM"
  type        = number
}

variable "memory_mb" {
  description = "RAM in MB per VM"
  type        = number
}

variable "disk_size_gb" {
  description = "Disk size in GB per VM"
  type        = number
}

variable "sleep_seconds" {
  description = "Pause after VM creation before reading IPs"
  type        = number
}

variable "vm_folder" {
  description = "vSphere folder path (relative to datacenter) to place the VMs in"
  type        = string
}
