# Exercise 05 — Design SLIs + SLOs + alerting (INTERVIEWER SOLVE NOTES)

**For interviewer eyes only. Never share with candidates. Never push to a public/candidate-facing repo.**

## What the exercise tests

A 10-minute design conversation. There's no code to write. We're testing:

1. **Edge-vs-app measurement understanding** — do they know WHERE to measure and why it matters?
2. **Concrete math, not round numbers** — can they justify "99.9%" with budget math?
3. **Distinction between paging vs ticketing** — do they think about who gets woken up at 3am?
4. **Error budget policy thinking** — do they understand the negotiating-with-product part?
5. **What NOT to alert on** — can they explicitly de-prioritize?

The service description (`api-description.md`) is the source of truth. Re-read it before the interview; it gives you specific failure modes (RDS failover, cache cold-start, deploy regression, Kafka outage) to probe.

A senior who's run SLOs in production will have opinions about the failure modes. A senior who hasn't will reason from first principles. A mid will name SRE book chapters without applying them.

## The service in one screen (from `api-description.md`)

- `shipment-tracking-api` — public REST, 12 replicas, behind ALB → ingress-nginx
- 3 read endpoints + 1 internal write endpoint
- 200-2000 RPS, peaks 4-5 PM ET
- p50 80ms / p95 250ms / p99 400ms
- Failure modes seen: RDS failover (~90s of 5xx), cache cold-start (2x p99 for 5 min), Kafka outage (0 HTTP impact — fire-and-forget), bad deploy with N+1 query (p99 → 8s)
- Customers: "99.9% loosely"; care most about freshness within 5 min of dispatch; do NOT care if `/history` is slow

## The 5 sub-questions and how to grade them

The exercise has 5 sub-prompts; treat them as a sequence:

1. **SLIs** — what do you measure, where, why?
2. **SLOs** — what target, over what window, why those numbers?
3. **Alert rules** — what fires, at what thresholds, paging vs ticketing?
4. **Error budget policy** — what does the team do at 50% / 80% / 100% consumed?
5. **What NOT to alert on** — what would you de-prioritize?

---

## Q1 — The SLI (what / where / why)

### Layer 1 — what the candidate sees

> "What do you measure, where, and why?"

### Layer 2 — plain English

"Pick one or two numbers that, when they change, indicate the user is having a worse time. WHERE you measure matters. WHY you picked those matters."

### Layer 3 — mechanism (where to measure and why)

Three measurement points and their tradeoffs:

| Point | What you see | What you miss |
|---|---|---|
| **Inside the app** | App-emitted metrics (request count, latency from app's perspective) | App can lie or be down; misses cases where the app never received the request |
| **At the ingress / edge** (nginx, ALB) | What the user actually experienced (network + app + downstream) | Costs more (sidecar metric collection); needs deliberate configuration |
| **From a synthetic prober** (Pingdom, Synthetics) | User-perspective availability, geo-distributed | Doesn't see real-traffic patterns; sampling issue |

**Strong candidate's recommendation**: measure at the **ingress/edge** for SLI of record. Reasons:
- That's what the user actually experiences
- Survives app being unreachable (because ingress would 503 or timeout — and that's a user-visible failure)
- App metrics are supplementary for diagnosis

### Layer 4 — what SLIs to actually pick

For `shipment-tracking-api`, the strongest SLI set:

1. **Availability SLI**: `% of HTTP requests returning a non-5xx response, measured at the ingress` (excluding 4xx because those are client errors). Some teams exclude 4xx; some include only specific 5xx; the candidate should articulate why.

2. **Latency SLI**: `% of HTTP requests with response time < N ms at p99 at the ingress`, scoped to specific endpoints (NOT the global p99 — that's noise from `/history` which they admit nobody cares about).

3. **Freshness SLI** (this is the senior signal): customers care about "shipments visible within 5 min of dispatch creation." This is an end-to-end SLI: time from dispatcher service emit → `GET /shipments/{id}` returns the new shipment. Strong candidates volunteer this even though it's not explicitly asked.

### Layer 5 — what NOT to use as SLI

- **CPU % / Memory %** — these are SAT (saturation), not SLIs. They are leading indicators but the user doesn't experience them directly.
- **Pod restart count** — internal cluster behavior, not user-facing.
- **DB connection count** — same.

The general rule: **SLI should reflect user experience**. If you don't fix it within the window, the user notices. CPU at 80% with 200ms latency = no user impact = not an SLI of record.

### Layer 6 — probes

| Probe | Strong | Weak |
|---|---|---|
| "Why measure at the edge?" | "Closest to the user. App can lie or be down." | "It's just convenient" |
| "Should you include 4xx in availability?" | "Usually not — those are caller errors. But authentication 401 storms might warrant a separate SLI." | "Yes, count everything" |
| "Why scope to specific endpoints?" | "Global p99 includes `/history` which customers don't care about. Mixes signals." | "Easier to manage" |
| "How would you measure freshness?" | "Synthetic prober that creates a shipment and polls until it appears, or log timestamps end-to-end" | Doesn't think of freshness at all |

### Layer 7 — strong vs weak phrases

**STRONG**
- "Measure at the edge — closest to user experience."
- "Scope to user-facing endpoints; per-endpoint SLIs, not global."
- "Freshness is the customer-stated need; that becomes a separate SLI."
- "CPU and memory are saturation indicators, not SLIs."

**WEAK**
- "Measure inside the app." (Without justifying.)
- "Use CPU%" (Confuses SAT with SLI.)
- "Average latency." (Hides tail; senior should mention p95/p99.)

---

## Q2 — The SLO (target / window / math)

### Layer 1 — what the candidate sees

> "What target, over what window, and why those numbers?"

### Layer 2 — plain English

"Don't just say '99.9% over 30 days'. Show the math. What does the customer expect? What can you actually deliver? What's the error budget that gives you?"

### Layer 3 — mechanism (the math)

Error budget arithmetic:
- 99.9% over 28 days = 0.1% × 28 × 24 × 60 = **40.32 minutes/month of allowable downtime**
- 99.95% over 28 days = 0.05% × 28 × 24 × 60 = **20.16 minutes/month**
- 99.99% over 28 days = 0.01% × 28 × 24 × 60 = **4 minutes/month**

**Reality check**: the failure modes in the service description include:
- RDS failover: ~90 seconds of 5xx per event. If you have ~1 failover/quarter, that's ~30s/month. Fits 99.99%.
- Bad deploy with N+1 query: 5 min × 12 deploys/month if it happened every deploy = blast budget. So deploy gates matter.

The customer says "99.9% loosely." That's the starting point but it's negotiable based on:
- What customers actually expect (loose = wiggle room)
- What's achievable given known failure modes (RDS failover is recurring)
- What it costs to go higher (multi-region adds capex + ops complexity)

### Layer 4 — what good SLO design looks like

Strong candidate would propose:

| SLI | SLO | Window | Why |
|---|---|---|---|
| Availability (5xx rate) | 99.9% | 28 days rolling | Matches customer "loose 99.9%"; 40 min/month covers RDS failover + 1 bad deploy |
| Latency p99 (key endpoints) | 99% under 800ms | 28 days rolling | Doubles current p99 to accommodate cache cold-start; tighter would page on every deploy |
| Freshness | 95% of new shipments visible in < 5 min | 28 days | Customer-stated; tighter than they need but gives margin |

Note: separate SLOs per SLI. Combining them into one is amateur.

### Layer 5 — common mistakes

- **No math**: "99.9% feels right" — what does that buy you in minutes?
- **Same SLO for all endpoints**: lumping `/shipments/{id}` with `/history` ignores that they have different criticality
- **No window discussion**: SLO without window is meaningless. 99.9% over an hour is laughably loose; 99.9% over a year is harder than it sounds.
- **Forgetting freshness**: customers told you what they care about; ignoring that means weaker user-centeredness

### Layer 6 — probes

| Probe | Strong | Weak |
|---|---|---|
| "How many minutes is 99.9% over 28 days?" | "About 40" | Doesn't know |
| "Why 28 days and not 30?" | "Aligns with on-call rotation; matches Google SRE convention" | Doesn't matter |
| "What if the SLO is too tight to hit?" | "Either invest in reliability or renegotiate with product" | "We try harder" |
| "What if it's too loose?" | "You're leaving reliability on the table; customers may not feel the difference" | Doesn't see a problem |
| "When would 99.99% make sense?" | "When customer pays for it, or when downtime cost is much higher than ops cost" | "Always" |

### Layer 7 — strong vs weak phrases

**STRONG**
- "99.9% over 28 days = 40 minutes/month. Fits 1 RDS failover + 1 bad deploy."
- "Customer said 'loose 99.9%' — that's negotiating leverage."
- "Per-endpoint SLOs; global p99 hides regressions."
- "SLO without a window is meaningless."

**WEAK**
- "Three 9s." (No math.)
- "99.99% to be safe." (No cost-benefit thinking.)
- Doesn't bring up window at all.

---

## Q3 — Alert rules (paging vs ticketing)

### Layer 1 — what the candidate sees

> "What alerts fire, at what thresholds, paging vs ticketing?"

### Layer 2 — plain English

"Translate the SLO into actual alerts. Who gets woken up? Who gets a ticket the next day?"

### Layer 3 — mechanism (multi-window burn-rate)

The naive approach: page when SLO is consumed below threshold. **Doesn't work** — by the time you've burned the whole budget, you're in incident mode.

The strong approach: **multi-window burn-rate alerts**. Burn-rate = how fast you're consuming error budget relative to "normal." Standard pattern:

- **Fast burn (page)**: 2% of monthly budget in 1 hour → burn rate ~14.4x. Page someone.
- **Slow burn (page)**: 5% in 6 hours → burn rate ~6x. Page someone.
- **Drift (ticket)**: 10% in 3 days → burn rate ~1x. Ticket the team; investigate in business hours.

This pattern catches both "we are on fire RIGHT NOW" (fast burn) and "something is slowly eroding our budget" (drift) without alerting on every transient blip.

### Layer 4 — what good answers include

Strong candidate proposes:

1. **Page**: fast burn (1h, 14.4x rate) → on-call engineer
2. **Page**: slow burn (6h, 6x rate) → on-call engineer
3. **Ticket**: budget consumed > 50% with > 14 days remaining → team backlog
4. **No alert**: latency above SLI threshold for < 30s — transient, not actionable

Strong also mentions:
- Page only on user-impacting signals; tickets for SAT and capacity
- Page should be **deduplicated** (one alert per incident, not 50)
- Alert routing per service / per team; not all alerts to one channel
- 5-min secondary escalation (per the service description) is good design

### Layer 5 — common mistakes

- **Single threshold alerts** ("page if p99 > 500ms for 5 min"): no budget-awareness, wakes you up too often
- **Alerting on SAT** (CPU > 80%): not user-facing; tickets, not pages
- **Same alert routes for all severities**: page-storm during incidents
- **No suppression for known transients** (cache cold-start happens every deploy): false-positive page

### Layer 6 — probes

| Probe | Strong | Weak |
|---|---|---|
| "Why multi-window?" | "Catches fast burn AND slow burn without paging on transients" | "Better coverage" |
| "What burn rate would you page on?" | Names 14.4x / 6x or equivalent math | Doesn't know burn rates |
| "Should you page on CPU > 80%?" | "No — that's saturation, not user-facing. Ticket." | "Yes" |
| "How do you keep alerts from waking on every deploy?" | "Suppress during deploy windows; budget-aware burn rates absorb the cold-start" | "Just make them less sensitive" |
| "What if PagerDuty itself is down?" | "Secondary escalation path; maybe Slack-based channel as fallback" | Doesn't think about it |

### Layer 7 — strong vs weak phrases

**STRONG**
- "Multi-window burn rate: fast for active fires, slow for drift."
- "Page on user-facing signals only; ticket for SAT."
- "Suppress cache-cold-start window after deploys."
- "Per-team routing; dedup; secondary escalation."

**WEAK**
- "Page if p99 spikes." (No burn-rate awareness.)
- "Alert on CPU." (Wrong layer.)
- "Send everything to oncall." (Page storm.)

---

## Q4 — Error budget policy

### Layer 1 — what the candidate sees

> "What does the team do at 50% / 80% / 100% consumed?"

### Layer 2 — plain English

"This is the negotiating-with-product part. What do you DO when you're burning budget? Is it just an alert, or is there a process?"

### Layer 3 — mechanism

Error budget policy is the **organizational lever** that translates SLOs into action. Standard tiers:

- **50% consumed**: Notify team. Review recent changes. Maybe slow down risky deploys. **Discussion, not action.**
- **80% consumed**: Freeze non-critical feature work. Focus on reliability. **Action required.**
- **100% consumed (burned out)**: Freeze all feature deploys. Mandatory reliability sprint. **Hard stop.**

Tiers should be:
1. **Pre-agreed with product** (this is the negotiation)
2. **Documented as policy**, not interpreted ad-hoc
3. **Reviewed quarterly** based on actual budget consumption patterns

### Layer 4 — what good answers include

Strong candidate names:
- The tiered policy above
- "I'd negotiate this with product before it's needed, not in the middle of an incident"
- "Budget freeze means feature freeze, not deploy freeze — bug fixes and security still ship"
- "Reset quarterly or rolling, depending on the SLO window"

### Layer 5 — common mistakes

- **No policy, just alerts**: "When budget is gone, we'll figure it out." Doesn't translate to action.
- **Treating budget as advisory**: if breaking budget has no consequence, it's not a budget.
- **Penalizing the team**: budget burns are signal, not punishment; the response is *prioritization*, not blame.
- **Confusion about scope**: bug fixes during a budget freeze are still allowed (they reduce future burn).

### Layer 6 — probes

| Probe | Strong | Weak |
|---|---|---|
| "What's the point of an error budget?" | "Translates reliability into a tradeable currency between product and engineering" | "To measure SLO" |
| "Who decides the tier responses?" | "Pre-agreed with product before incident" | "I do, in the moment" |
| "What's the difference between budget freeze and deploy freeze?" | "Freeze new features; bug fixes still ship" | Treats them the same |
| "When do you reset the budget?" | "End of window — rolling or quarterly" | Doesn't know |

### Layer 7 — strong vs weak phrases

**STRONG**
- "Tiered policy: 50% notify, 80% freeze features, 100% hard stop."
- "Pre-agreed with product, not negotiated in incidents."
- "Budget freeze is feature freeze; bug fixes still ship."
- "Budget is a tradeable currency between product and eng."

**WEAK**
- "We'd just communicate." (No policy.)
- "Freeze all deploys at 80%." (Too blunt; ignores fix-vs-feature distinction.)
- Doesn't mention pre-agreement with product.

---

## Q5 — What NOT to alert on

### Layer 1 — what the candidate sees

> "What would you explicitly de-prioritize?"

### Layer 2 — plain English

"Most teams have too many alerts. Show me you'll cut some on purpose."

### Layer 3 — what strong candidates pick

- **`/history` endpoint latency**: customer said they don't care; don't alert on it
- **Kafka broker outage**: the description says HTTP unaffected; alert only if app behavior actually degrades
- **CPU / Memory / Disk usage**: these are SAT, not SLIs; ticket not page
- **Pod restart counts**: internal cluster behavior, not user-facing
- **Deploy success rate**: deploy frequency is a CI/CD metric, ticket not page
- **DB query latency**: leading indicator; useful for diagnosis but not an alert of record

Strong candidates volunteer this WITHOUT being prompted on "what NOT to do."

### Layer 4 — common mistakes

- **Alerting on everything because "I might miss something"**: drives alert fatigue → alerts get ignored → real ones get missed
- **Not distinguishing alerts from dashboards**: SAT belongs on a dashboard; SLI burn belongs in alerts
- **Page on deploys**: deploy events should be timeline annotations, not pages

### Layer 5 — probes

| Probe | Strong | Weak |
|---|---|---|
| "Why de-prioritize `/history`?" | "Customer told us they don't care; alerting on it wastes attention" | "Sure" |
| "What's the cost of alerting on everything?" | "Alert fatigue. Real ones get missed." | "Coverage" |
| "Where does CPU go?" | "Dashboard, not page" | "Page" |
| "Kafka broker down — page?" | "No — HTTP unaffected per design. Alert if app behavior degrades." | "Yes" |

### Layer 6 — strong vs weak phrases

**STRONG**
- "Customer told us `/history` doesn't matter — drop it."
- "SAT lives on dashboards, not pages."
- "Alert fatigue means real ones get missed."
- "Kafka outage doesn't page if HTTP isn't impacted."

**WEAK**
- "Alert on everything in case." (Fatigue path.)
- "I don't see anything to cut." (No prioritization sense.)

---

## What to do during the exercise

### Open with

> "Walk me through SLOs and alerting for `shipment-tracking-api`. Read the spec, then in about 10 minutes propose SLIs, SLOs, alert rules, error-budget policy, and what you'd explicitly NOT alert on. Expect me to probe edges and what-ifs."

### While they work

- **First minute**: are they asking clarifying questions about traffic, customer expectations, on-call rotation? Good signal.
- **SLI choice**: are they measuring at the edge? Justifying why? If they jump to in-app metrics without rationale, probe.
- **SLO math**: do they show the math? "99.9%" without "= 40 min/month" is weaker.
- **Multi-window burn**: this is the senior gate for alerting. If they don't volunteer it, ask: "How do you keep this from waking you up on every transient blip?"
- **Error budget policy**: weak candidates skip this entirely. Strong candidates have a tiered framework ready.
- **What NOT to alert**: strong candidates volunteer the `/history` cut without prompting. Weak candidates need to be asked.

### Probes during

Don't wait until the end. Inject:
- "What's the customer cost if you're wrong about freshness?"
- "If your cache hit rate drops from 85% to 60%, does that hit your SLO?"
- "RDS failover happens — does your SLO accommodate that?"

These force them to connect SLO design to operational reality.

## Scoring rubric

| Tier | Signal |
|---|---|
| **STRONG hire** | Measures at the edge with justification. Names freshness SLI unprompted. SLO math with budget calculation. Multi-window burn-rate alerts. Tiered error-budget policy pre-agreed with product. Volunteers `/history` cut. Distinguishes pages from tickets from dashboards. Asks clarifying questions. |
| **Hire** | Edge measurement; sensible SLOs with some math. Burn-rate awareness even if not multi-window. Error-budget policy at least mentioned. Most "what NOT to alert" surfaces with mild prompting. |
| **Borderline** | SLI choice mechanical (no rationale). SLO target without math. Single-threshold alerts. No error-budget policy. Misses freshness entirely. |
| **No hire** | "Page on CPU." "99.9% three 9s." No window. No budget policy. No prioritization. "Alert on everything." |

## Time budget

- ~10 min total
- 1-2 min reading the spec
- 7-8 min discussion across all 5 sub-questions
- Move on if they're flailing; depth beats coverage

## Tying it back

After they finish, optionally ask:

> "If you were the on-call engineer covering this service tonight, and you got paged at 3am, what would the alert tell you and what would you do first?"

This is the synthesis question. Strong candidates name:
1. What the alert SAYS (which SLI burned, which endpoint, current rate)
2. What runbook they'd open (per-alert runbook is good practice)
3. First diagnostic step (check recent deploys, check RDS health, check cache hit rate)
4. When they'd escalate (if recovery > N minutes, secondary)

Weak candidates say "I'd check the dashboard" without specifics.
