# Exercise 05 — Design SLIs + SLOs + alerting for an API

**Time:** ~10 minutes (discussion + light writing)

## The service

`shipment-tracking-api` — a public-facing REST API used by ~30 customer-facing apps. Customers hit it 200-2000 RPS depending on time of day. P50 latency is 80ms; p99 is 400ms today.

[`api-description.md`](api-description.md) has the full picture: endpoints, dependencies, traffic shape, on-call rotation.

## Your task

In 10 minutes, propose:

1. **The SLI(s)** — what do you measure, where, and why?
2. **The SLO(s)** — what target(s), over what window, and why those numbers?
3. **The alert rules** — what alerts fire, at what thresholds, paging vs ticketing?
4. **The error budget policy** — what does the team do when budget is 50% / 80% / 100% consumed?
5. **What NOT to alert on** — what would you explicitly de-prioritize?

You can sketch in [`api-description.md`](api-description.md) or talk it through.

## What we're looking for

- You measure SLI at the **edge** (load balancer or ingress), not inside the app
- You use a **multi-window burn-rate** alert (fast burn pages, slow burn tickets)
- You can do the budget math from an SLO (28d × 0.1% = ~40 min)
- You understand the **error budget policy is a negotiation with product**, not an engineering decree
- You distinguish symptoms (HTTP 5xx) from causes (DB connection pool exhausted)
- You **don't** propose CPU% as an SLI

## Probes I'll ask during

- What about the "soft" failures — a 200 response with empty body when DB times out? How do you SLI those?
- One specific endpoint (`/shipments/{id}/history`) is 10× slower than the rest and customers tolerate it. Do you SLO it separately?
- You burned 90% of budget at day 24 of a 28-day window. What's the conversation with product?
