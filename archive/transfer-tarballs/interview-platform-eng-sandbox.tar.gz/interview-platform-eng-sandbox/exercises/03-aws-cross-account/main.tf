terraform {
  required_version = ">= 1.5"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

# Two providers — one per account. Both use placeholders; this exercise is
# `terraform plan`-only against a sandbox role (no real apply).
provider "aws" {
  alias   = "account_a"
  region  = "us-east-1"
  profile = "interview-sandbox" # placeholder
}

provider "aws" {
  alias   = "account_b"
  region  = "us-east-1"
  profile = "interview-sandbox" # placeholder
}

variable "account_a_id" {
  type    = string
  default = "111111111111"
}

variable "account_b_id" {
  type    = string
  default = "222222222222"
}

# ----- ACCOUNT A: pod's source role (assumed via IRSA) -----
resource "aws_iam_role" "pod_source_role" {
  provider = aws.account_a
  name     = "demo-pod-secret-reader"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Federated = "arn:aws:iam::${var.account_a_id}:oidc-provider/oidc.eks.us-east-1.amazonaws.com/id/EXAMPLE"
      }
      Action = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          "oidc.eks.us-east-1.amazonaws.com/id/EXAMPLE:sub" = "system:serviceaccount:demo:demo-sa"
          "oidc.eks.us-east-1.amazonaws.com/id/EXAMPLE:aud" = "sts.amazonaws.com"
        }
      }
    }]
  })
}

# Bug #1 (interviewer hint): the permissions policy below grants secret read
# DIRECTLY (no AssumeRole chain). For a cross-account secret in B, this won't
# work — see what the candidate identifies.
resource "aws_iam_role_policy" "pod_source_perms" {
  provider = aws.account_a
  role     = aws_iam_role.pod_source_role.id
  name     = "wrong-direct-secret-read"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "secretsmanager:GetSecretValue"
      Resource = "arn:aws:secretsmanager:us-east-1:${var.account_b_id}:secret:demo-app/db-creds-*"
    }]
  })
}

# ----- ACCOUNT B: target role that should be assumed cross-account -----
# Bug #2 (interviewer hint): the trust policy below is wildly overpermissive.
# The Principal is `*` (literally anyone), and there's no ExternalId, no
# org-id check, no source-arn check. The candidate should rewrite this.
resource "aws_iam_role" "cross_account_reader" {
  provider = aws.account_b
  name     = "cross-account-secret-reader"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        AWS = "*" # XXX — way too open; fix this
      }
      Action = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy" "cross_account_reader_perms" {
  provider = aws.account_b
  role     = aws_iam_role.cross_account_reader.id
  name     = "read-demo-secret"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "secretsmanager:GetSecretValue"
      Resource = "arn:aws:secretsmanager:us-east-1:${var.account_b_id}:secret:demo-app/db-creds-*"
    }]
  })
}

# Bug #3 (interviewer hint): the secret in account B is referenced above but
# there's NO resource policy on the secret itself granting cross-account
# access. The candidate should mention this — production needs both the IAM
# policy on the role AND the resource policy on the secret.
