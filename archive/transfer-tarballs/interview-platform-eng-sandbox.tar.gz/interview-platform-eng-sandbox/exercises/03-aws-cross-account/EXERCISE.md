# Exercise 03 — Fix the cross-account IAM trust policy

**Time:** ~10 minutes

## Scenario

A pod in **Account A** (EKS) needs to read a secret from **Account B** (Secrets Manager). The infrastructure was scaffolded by a junior engineer; the Terraform plan succeeds, but in practice the assume-role chain fails.

Open [`main.tf`](main.tf) and identify what's wrong with the trust policy on the **cross-account-reader** role in account B.

You won't need to run `terraform apply` — fix the file, then we'll talk through why it's wrong and what production-grade looks like.

## What we're looking for

- You can spot **at least 3 problems** with the trust policy
- You can name the security implications (confused deputy attack, blanket trust)
- You know what `ExternalId` is for
- You can describe the end-to-end auth chain: pod → SA → IRSA → STS in A → AssumeRole into B → SM `GetSecretValue`
- You also remember the **resource policy on the secret itself** — IAM policy on a role isn't enough across accounts

## After fixing

We'll ask:

- IRSA vs EKS Pod Identity — pick one for a new cluster and why
- How would you debug this if it weren't working in prod? (Hint: CloudTrail in *both* accounts)
- What's the default session duration on AssumeRole? When would you change it?

## Bonus

There's actually a **second** issue beyond the trust policy. The Terraform also wires the source role's permissions policy wrong. See if you spot it.
