#!/usr/bin/env python3
"""
Onboard an app to the OnPremise Octopus space for on-prem deployment.

Combines all per-app setup steps into one idempotent script:
  1. Seed terraform state (auth + mongodb-user) from cloud S3
  2. Fix SM ARNs in auth state (cloud account → usx-dev account — same account
     now, so this becomes a no-op for most cases; retained for edge cases)
  3. Copy MongoDB Atlas certificate secret (usually a no-op — secrets are now
     native to usx-dev SM rather than copied cross-account)
  4. Copy missing project variables from cloud to OnPremise
  5. Patch DX-Apply deployment process with SSM kubeconfig block

Prerequisites:
  - App already imported via Bento (project exists in OnPremise space)
  - OCTOPUS_API_KEY set
  - AWS profile: usx-dev (700736442855) — on-prem now authenticates into the
    same AWS account as cloud dev (migration 2026-04-21). Prior to migration
    this used profile=playground (786352483360). See phase2 plan doc.
  - AWS CLI available

Usage:
    OCTOPUS_API_KEY=API-... ./onboard-app.py brands-api [--dry-run]
    OCTOPUS_API_KEY=API-... ./onboard-app.py --all [--dry-run]

Cloud-safety: Reads from cloud S3 (read-only). Writes only to usx-dev S3 under
the op-usxpress-dev-tfstate on-prem-scoped bucket and OnPremise Octopus space.
"""

import argparse
import json
import os
import subprocess
import sys
import urllib.error
import urllib.request

OCTO = "https://octopus.usxpress.io"
SRC_SPACE = "Spaces-245"   # USXpress (cloud, read-only)
DST_SPACE = "Spaces-302"   # OnPremise (write target)

# S3 buckets for terraform state
CLOUD_STATE_BUCKET = "usxpress-tf-state-8300lkoz74prn4fd"
CLOUD_STATE_REGION = "us-east-2"
CLOUD_AWS_PROFILE = "usx-dev"
CLOUD_AWS_ACCOUNT = "700736442855"

ONPREM_STATE_BUCKET = "op-usxpress-dev-tfstate"
ONPREM_STATE_REGION = "us-east-2"
ONPREM_AWS_PROFILE = "usx-dev"
ONPREM_AWS_ACCOUNT = "700736442855"

# Modules whose state should be seeded from cloud
STATE_MODULES = ["common/auth", "common/mongodb-user"]

# MongoDB Atlas secrets to copy from cloud dev to playground
MONGO_SECRETS_PATTERNS = [
    "mongo-cluster-{env}-{group}",
]


def api(method, path, body=None, key=None):
    req = urllib.request.Request(
        f"{OCTO}{path}",
        data=json.dumps(body).encode() if body is not None else None,
        headers={"X-Octopus-ApiKey": key, "Content-Type": "application/json"},
        method=method,
    )
    try:
        with urllib.request.urlopen(req) as r:
            data = r.read()
            return json.loads(data) if data else {}
    except urllib.error.HTTPError as e:
        err = e.read().decode()[:400]
        print(f"  HTTP {e.code} on {method} {path}: {err}", file=sys.stderr)
        return None


def run(cmd, check=True):
    """Run a shell command and return stdout."""
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if check and result.returncode != 0:
        print(f"  CMD FAILED: {cmd}", file=sys.stderr)
        print(f"  stderr: {result.stderr[:300]}", file=sys.stderr)
        return None
    return result.stdout.strip()


def find_project(space_id, name, key):
    d = api("GET", f"/api/{space_id}/projects?partialName={name}&take=10", key=key)
    if not d:
        return None
    for p in d.get("Items", []):
        if p["Name"] == name:
            return p
    return None


# ─── Step 1: Seed terraform state ───

def seed_state(app_name, module_path, dry_run=False):
    """Copy terraform state for a module from cloud S3 to on-prem S3."""
    cloud_key = f"USXpress/{app_name}/{module_path}"
    onprem_key = f"USXpress/{app_name}/{module_path}"
    tmp_file = f"/tmp/state-{app_name}-{module_path.replace('/', '-')}.json"

    print(f"\n  Seeding state: {module_path}")

    # Check if on-prem state already exists
    check = run(
        f"aws s3 ls s3://{ONPREM_STATE_BUCKET}/{onprem_key} "
        f"--profile {ONPREM_AWS_PROFILE} --region {ONPREM_STATE_REGION} 2>/dev/null",
        check=False,
    )
    if check:
        print(f"    SKIP: state already exists in on-prem bucket")
        return True

    # Download from cloud
    result = run(
        f"aws s3 cp s3://{CLOUD_STATE_BUCKET}/{cloud_key} {tmp_file} "
        f"--profile {CLOUD_AWS_PROFILE} --region {CLOUD_STATE_REGION}"
    )
    if not result:
        print(f"    WARN: no cloud state found for {cloud_key} — skipping")
        return True  # Not an error — module may not have run in cloud

    # Fix SM ARNs for auth state. Post-2026-04-21 migration, cloud and on-prem
    # share the same AWS account (usx-dev 700736442855 us-east-2), so this is
    # usually a no-op — retained for edge cases where old state still has
    # playground ARNs lingering from the pre-migration era.
    if "auth" in module_path:
        fix_auth_state_arns(app_name, tmp_file, dry_run)

    if dry_run:
        print(f"    DRY-RUN: would upload state to s3://{ONPREM_STATE_BUCKET}/{onprem_key}")
        return True

    # Upload to on-prem
    result = run(
        f"aws s3 cp {tmp_file} s3://{ONPREM_STATE_BUCKET}/{onprem_key} "
        f"--profile {ONPREM_AWS_PROFILE} --region {ONPREM_STATE_REGION}"
    )
    if result is not None:
        print(f"    DONE: state seeded")
        return True
    return False


def fix_auth_state_arns(app_name, state_file, dry_run=False):
    """Reconcile auth state SM ARNs against on-prem account.

    Post 2026-04-21 migration, cloud and on-prem share the same AWS account
    and region (usx-dev 700736442855 us-east-2). In the common case this is
    a no-op. Edge cases retained:
      - old state files seeded before the migration still carry Playground
        (786352483360 us-east-1) ARNs — those need rewrite.
      - secret not yet provisioned in on-prem account — stub with -PENDING
        so terraform re-creates on first apply.
    """
    secret_name = f"azure-app-dx-dev-usxpress-{app_name}"

    # Get the on-prem SM secret ARN (in usx-dev)
    onprem_arn = run(
        f"aws secretsmanager describe-secret --secret-id {secret_name} "
        f"--profile {ONPREM_AWS_PROFILE} --region {ONPREM_STATE_REGION} "
        f"--query ARN --output text 2>/dev/null",
        check=False,
    )

    with open(state_file) as f:
        state = f.read()

    # Find any SM ARN that does NOT match the on-prem account/region.
    # Post-migration cloud == on-prem, so mismatches are legacy Playground ARNs.
    import re
    legacy_arn_pattern = (
        rf"arn:aws:secretsmanager:[\w-]+:\d+:secret:{re.escape(secret_name)}-[A-Za-z0-9]{{6}}"
    )
    matches = [
        m for m in re.findall(legacy_arn_pattern, state)
        if not m.startswith(f"arn:aws:secretsmanager:{ONPREM_STATE_REGION}:{ONPREM_AWS_ACCOUNT}:")
    ]

    if not matches:
        print(f"    No stale SM ARNs found for {secret_name} — state is clean")
        return

    if onprem_arn:
        for old_arn in set(matches):
            count = state.count(old_arn)
            state = state.replace(old_arn, onprem_arn)
            print(f"    Replaced {count}x: {old_arn[:60]}... → on-prem ARN")
    else:
        print(f"    SM secret {secret_name} not in on-prem account — terraform will create on first deploy")
        for old_arn in set(matches):
            state = state.replace(old_arn, f"arn:aws:secretsmanager:{ONPREM_STATE_REGION}:{ONPREM_AWS_ACCOUNT}:secret:{secret_name}-PENDING")

    if not dry_run:
        with open(state_file, "w") as f:
            f.write(state)


# ─── Step 2: Copy MongoDB Atlas secrets ───

def copy_mongo_secrets(app_name, env="dev", group="enterprise", dry_run=False):
    """Ensure MongoDB Atlas certificate secret exists in the on-prem AWS account.

    Post 2026-04-21 migration cloud and on-prem share the same account, so this
    is typically a pure existence-check with no copy needed. Retained to catch
    the edge case where an app references a secret that hasn't been provisioned
    in usx-dev yet.
    """
    for pattern in MONGO_SECRETS_PATTERNS:
        secret_name = pattern.format(env=env, group=group)
        print(f"\n  MongoDB secret: {secret_name}")

        # Check if exists in on-prem account (usx-dev)
        check = run(
            f"aws secretsmanager describe-secret --secret-id {secret_name} "
            f"--profile {ONPREM_AWS_PROFILE} --region {ONPREM_STATE_REGION} "
            f"--query Name --output text 2>/dev/null",
            check=False,
        )
        if check == secret_name:
            print(f"    OK: already exists in on-prem account")
            continue

        # Fallback: not present in on-prem. Since cloud == on-prem post-migration,
        # this means the secret genuinely doesn't exist anywhere — nothing to copy.
        # Older cloud-to-onprem copy path retained below only for legacy callers
        # where profiles point at different accounts (e.g. during rollback).
        if CLOUD_AWS_ACCOUNT == ONPREM_AWS_ACCOUNT:
            print(f"    WARN: {secret_name} not found in usx-dev — provision it before running app")
            continue

        value = run(
            f"aws secretsmanager get-secret-value --secret-id {secret_name} "
            f"--profile {CLOUD_AWS_PROFILE} --region {CLOUD_STATE_REGION} "
            f"--query SecretString --output text 2>/dev/null",
            check=False,
        )
        if not value:
            print(f"    WARN: not found in cloud dev — skipping")
            continue

        if dry_run:
            print(f"    DRY-RUN: would create {secret_name} in on-prem account")
            continue

        result = run(
            f"aws secretsmanager create-secret --name {secret_name} "
            f"--secret-string '{value}' "
            f"--profile {ONPREM_AWS_PROFILE} --region {ONPREM_STATE_REGION}",
        )
        if result is not None:
            print(f"    DONE: secret created in on-prem account")


# ─── Step 3: Copy project variables ───

def copy_project_variables(app_name, key, dry_run=False):
    """Copy missing project variables from cloud to OnPremise project."""
    print(f"\n  Syncing project variables")

    src_proj = find_project(SRC_SPACE, app_name, key)
    dst_proj = find_project(DST_SPACE, app_name, key)
    if not src_proj or not dst_proj:
        print(f"    WARN: project not found in {'source' if not src_proj else 'target'} — skipping")
        return

    src_vs = api("GET", f"/api/{SRC_SPACE}/variables/{src_proj['VariableSetId']}", key=key)
    dst_vs = api("GET", f"/api/{DST_SPACE}/variables/{dst_proj['VariableSetId']}", key=key)

    dst_names = {v["Name"] for v in dst_vs.get("Variables", [])}
    added = 0

    for v in src_vs.get("Variables", []):
        name = v["Name"]
        # Only copy variables that don't exist in destination
        if name not in dst_names:
            # Skip sensitive variables (they'll be empty in API response)
            if v.get("IsSensitive"):
                continue
            dst_vs["Variables"].append({
                "Name": name,
                "Value": v.get("Value", ""),
                "Scope": {},  # unscoped — Octopus resolves per environment
                "IsSensitive": False,
                "IsEditable": True,
                "Type": v.get("Type", "String"),
            })
            print(f"    + ADD {name} = {(v.get('Value') or '')[:50]!r}")
            added += 1

    if added == 0:
        print(f"    All variables already present")
        return

    if dry_run:
        print(f"    DRY-RUN: would add {added} variables")
        return

    api("PUT", f"/api/{DST_SPACE}/variables/{dst_proj['VariableSetId']}", body=dst_vs, key=key)
    print(f"    DONE: added {added} variables")


# ─── Main ───

def onboard_app(app_name, key, dry_run=False):
    print(f"\n{'='*60}")
    print(f"Onboarding: {app_name}")
    print(f"  cloud: {SRC_SPACE} ({CLOUD_AWS_ACCOUNT})")
    print(f"  onprem: {DST_SPACE} ({ONPREM_AWS_ACCOUNT})")

    # Verify project exists in OnPremise
    proj = find_project(DST_SPACE, app_name, key)
    if not proj:
        print(f"  ERROR: {app_name!r} not found in OnPremise space")
        print(f"  Run Bento import first: USXpress → OnPremise")
        return False

    ok = True

    # Step 1: Seed terraform state
    for module in STATE_MODULES:
        if not seed_state(app_name, module, dry_run):
            ok = False

    # Step 2: Copy MongoDB Atlas secrets
    # Detect env/group from spec or use defaults
    copy_mongo_secrets(app_name, env="dev", group="enterprise", dry_run=dry_run)

    # Step 3: Copy project variables
    copy_project_variables(app_name, key, dry_run)

    # Step 4: Patch DX-Apply (delegate to patch-dx-apply.py logic)
    print(f"\n  DX-Apply patch: run ./patch-dx-apply.py --project {app_name}")

    return ok


def main():
    ap = argparse.ArgumentParser(description="Onboard app to OnPremise space")
    ap.add_argument("app", nargs="?", default="brands-api",
                    help="App name to onboard (default: brands-api)")
    ap.add_argument("--all", action="store_true",
                    help="Onboard all 6 module-coverage apps")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    key = os.environ.get("OCTOPUS_API_KEY")
    if not key:
        sys.exit("OCTOPUS_API_KEY not set")

    apps = [
        "brands-api",
        "geoenrichment-sync-handler",
        "attrition-api",
        "io-notifications-handler",
        "trailers-api",
        "safetylytx-video-api",
    ] if args.all else [args.app]

    ok = fail = 0
    for name in apps:
        if onboard_app(name, key, args.dry_run):
            ok += 1
        else:
            fail += 1

    print(f"\nDone: {ok} ok, {fail} failed")
    if fail > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
