#!/bin/bash
# Apply inline IAM policies to the on-prem Octopus worker role.
#
# Used after iaac-talos terraform apply creates the worker role fresh
# (without any inline policies). Until worker-iam-policies.tf is re-homed
# to a separate terraform root, this script is the source of truth for
# the policies.
#
# Idempotent: put-role-policy overwrites in place.
#
# Cloud-safety: only modifies the on-prem worker role in USX-Dev
# (account 700736442855). Cloud team's EKS IAM roles are untouched.
# (Prior to 2026-04-21 this targeted Playground 786352483360 us-east-1.)

set -euo pipefail

ROLE=iaac-octopus-worker-op-usxpress-dev
CLUSTER=op-usxpress-dev
ACCOUNT=700736442855
STATE_BUCKET=op-usxpress-dev-tfstate
PROFILE=usx-dev

if ! aws --profile "$PROFILE" iam get-role --role-name "$ROLE" > /dev/null 2>&1; then
  echo "ERROR: role $ROLE not found. Has the cluster terraform apply completed?"
  exit 1
fi

echo "Applying inline policies to $ROLE ..."

# 1. SSM - read cluster parameters (endpoint, CA, token, oidc_issuer) for kubeconfig build
aws --profile "$PROFILE" iam put-role-policy --role-name "$ROLE" \
  --policy-name ssm-cluster-params-read \
  --policy-document "$(cat <<EOF
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": ["ssm:GetParameter"],
    "Resource": ["arn:aws:ssm:us-east-2:$ACCOUNT:parameter/clusters/$CLUSTER/*"]
  }]
}
EOF
)"
echo "  [ok] ssm-cluster-params-read"

# 2. ECR - pull images/Helm charts from devops account (cross-account)
aws --profile "$PROFILE" iam put-role-policy --role-name "$ROLE" \
  --policy-name ecr-login \
  --policy-document '{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": [
      "ecr:GetAuthorizationToken",
      "ecr:BatchGetImage",
      "ecr:GetDownloadUrlForLayer",
      "ecr:BatchCheckLayerAvailability",
      "ecr:ListImages",
      "ecr:DescribeImages",
      "ecr:DescribeRepositories"
    ],
    "Resource": "*"
  }]
}'
echo "  [ok] ecr-login"

# 3. S3 - terraform state read/write
aws --profile "$PROFILE" iam put-role-policy --role-name "$ROLE" \
  --policy-name s3-tfstate \
  --policy-document "$(cat <<EOF
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": [
      "s3:GetObject",
      "s3:PutObject",
      "s3:ListBucket",
      "s3:DeleteObject"
    ],
    "Resource": [
      "arn:aws:s3:::$STATE_BUCKET",
      "arn:aws:s3:::$STATE_BUCKET/*"
    ]
  }]
}
EOF
)"
echo "  [ok] s3-tfstate"

# 4. Secrets Manager - full CRUD for app secrets (auth module, ExternalSecrets)
aws --profile "$PROFILE" iam put-role-policy --role-name "$ROLE" \
  --policy-name secretsmanager-rw \
  --policy-document '{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": [
      "secretsmanager:CreateSecret",
      "secretsmanager:GetSecretValue",
      "secretsmanager:PutSecretValue",
      "secretsmanager:DescribeSecret",
      "secretsmanager:UpdateSecret",
      "secretsmanager:DeleteSecret",
      "secretsmanager:RestoreSecret",
      "secretsmanager:TagResource",
      "secretsmanager:UntagResource",
      "secretsmanager:GetResourcePolicy",
      "secretsmanager:PutResourcePolicy",
      "secretsmanager:DeleteResourcePolicy"
    ],
    "Resource": "*"
  }]
}'
echo "  [ok] secretsmanager-rw"

echo
echo "Done. Applied policies:"
aws --profile "$PROFILE" iam list-role-policies --role-name "$ROLE" --output text
