# Phase 2 Migration — Apply Instructions

## What's in this tarball

| Path | Where it goes on WSL2 |
|---|---|
| `phase2_usx_dev_migration_plan.md` | Keep for record (e.g., `~/phase2_usx_dev_migration_plan.md` or commit to `~/iaac-octopus-overrides/docs/`) |
| `iaac-talos/deploy/terraform/main.tf` | overlay `~/iaac-talos/deploy/terraform/main.tf` |
| `iaac-talos/deploy/terraform/variables.tf` | overlay |
| `iaac-talos/deploy/terraform/outputs.tf` | overlay |
| `iaac-talos/deploy/terraform/modules/irsa/` | **new** module — add `~/iaac-talos/deploy/terraform/modules/irsa/` |
| `iaac-octopus-overrides/*` | overlay files in `~/iaac-octopus-overrides/` |
| `iaac-talos-flux-platform/infrastructure/*` | overlay files in `~/iaac-talos-flux-platform/infrastructure/` |

## Step-by-step

```bash
# 1. Extract next to your repos (WSL2 home)
cd ~
tar xzf phase2-migration.tar.gz
cd phase2-migration

# 2. Overlay each repo and review
for repo in iaac-talos iaac-octopus-overrides iaac-talos-flux-platform; do
  echo "=== $repo ==="
  cp -rv $repo/* ~/$repo/
  # show hidden files (.github/)
  if [ -d $repo/.github ]; then
    cp -rv $repo/.github ~/$repo/
  fi
done

# 3. Review diffs per repo
cd ~/iaac-talos && git diff
cd ~/iaac-octopus-overrides && git diff
cd ~/iaac-talos-flux-platform && git diff

# 4. Per-repo branch + commit + push (adjust branch names as needed)

## iaac-talos (already on feature/irsa on codespace; check yours)
cd ~/iaac-talos
git checkout -b feature/op-usxpress-dev    # or whatever feature branch you prefer
git add deploy/terraform/
git commit -m "feat(onprem): wire IRSA module; retarget to USX-Dev account

Adds module \"irsa\" invocation in main.tf so cluster rebuild provisions
its own S3+CloudFront+OIDC+IAM roles in whichever AWS account the
terraform provider targets. Required for the Playground -> USX-Dev
migration. See phase2_usx_dev_migration_plan.md."
git push -u origin feature/op-usxpress-dev

## iaac-octopus-overrides
cd ~/iaac-octopus-overrides
git checkout -b feature/usx-dev-migration
git add onprem-development.yaml terraform/worker-iam-policies.tf \
        apply-worker-iam-policies.sh onboard-app.py \
        .github/workflows/onboard-app.yaml README.md
git commit -m "feat(onprem): migrate AWS backend from Playground to USX-Dev

Flips onprem-development.yaml library variables, worker-iam-policies.tf
backend+provider, apply-worker-iam-policies.sh account/region, onboard-app.py
AWS profile/region, GHA workflow region, and README table from Playground
(786352483360 us-east-1) to USX-Dev (700736442855 us-east-2). Rationale:
consolidates on-prem dev onto the same AWS account as cloud dev so secrets
(Kafka, Mongo) do not need to be duplicated. See phase2 plan."
git push -u origin feature/usx-dev-migration

## iaac-talos-flux-platform
cd ~/iaac-talos-flux-platform
git checkout -b feature/usx-dev-migration   # or stay on dpl if that's your working branch
git add infrastructure/external-secrets-config/clustersecretstore.yaml \
        infrastructure/external-secrets/helmrelease.yaml \
        infrastructure/ecr-credentials/rbac.yaml \
        infrastructure/octopus-worker/release.yaml \
        infrastructure/app-namespaces/serviceaccounts.yaml
git commit -m "feat(onprem): flip all IRSA role ARNs to USX-Dev account

ClusterSecretStore region us-east-1 -> us-east-2. ESO, ECR credentials,
Octopus worker role ARNs account 786352483360 -> 700736442855. 19 app
SA annotations: account flipped (role names kept as dpl2-* for now;
separate initiative). See phase2 plan doc."
git push -u origin feature/usx-dev-migration
```

## IMPORTANT: Do NOT run terraform/apply yet

These edits describe the *target* state. Actual execution (destroy+rebuild of
the cluster against USX-Dev) happens after the push is complete and you've
reviewed the diffs.

Sequence after push:

1. Ensure `ONPREM_DEPLOY_ROLE_ARN` GitHub secret in iaac-octopus-overrides points at USX-Dev role ARN (currently assumes Playground)
2. Apply Octopus library vars: `python apply.py` in iaac-octopus-overrides against OnPremise space
3. Destroy current cluster pointing at Playground (`AWS_PROFILE=playground ... terraform destroy`)
4. Rebuild cluster pointing at USX-Dev (`AWS_PROFILE=usx-dev ... terraform apply`)
5. Apply worker inline policies (`cd ~/iaac-octopus-overrides/terraform && terraform init -reconfigure && terraform apply`)
6. Validate brands-api + geo-handler
7. Phase 6 cleanup of Playground resources (≥48h after stable cutover)
