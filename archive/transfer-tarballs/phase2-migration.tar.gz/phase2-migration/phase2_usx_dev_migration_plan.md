# Phase 2 — On-prem AWS Control-Plane Migration: Playground → USX-Development

**Author:** Dare Oke (Cloud Platform Team)
**Date:** 2026-04-21
**Status:** Approved — execution in progress
**Driver:** Vibin Daniel architectural decision (2026-04-21)
**Target completion:** Before May 4, 2026 (user PTO)

---

## 1. Context

### Why
On-prem dev cluster (`op-usxpress-dev`, Talos v1.32.0 on vSphere, 3 CP + 5 workers) currently authenticates into AWS **Playground account (786352483360, us-east-1)**. Playground is a sandbox account and does not contain production secrets. This has already caused blockers:

- **brands-api**: works (MongoDB creds were manually copied from cloud to Playground SM).
- **geoenrichment-sync-handler**: blocked on `dx__geoservices-kafka-creds` — this secret has **automatic 60-day rotation via Lambda** in USX-Dev and does not exist in Playground. Copying it creates permanent drift and defeats the rotation automation.

Vibin's directive (2026-04-21): **move on-prem dev AWS control-plane to USX-Development account (700736442855, us-east-2)** so on-prem mirrors the same AWS account boundary cloud dev uses. This removes the secret-duplication class of problem entirely.

### Non-goals
- Not touching the cloud-side `usxpress-dev` EKS cluster or any cloud team resources.
- Not moving any on-prem workload compute to AWS — on-prem workers stay on-prem.
- Not changing ECR image source — images still pulled from devops account `064859874041`.

### Cloud-safety invariants
- Changes are **additive in USX-Dev** (create new resources; do not modify cloud team's existing resources).
- No shared Octopus Space (OnPremise space `Spaces-302` is write-scoped; USXpress space `Spaces-245` is read-only reference).
- No shared library variable sets modified outside `Environments-1081` (development) scope.
- Playground resources stay in place until cutover is validated stable, then cleaned up in Phase 6.

---

## 2. Phase 1 discovery — current state (verified 2026-04-21)

### Playground (786352483360, us-east-1)
| Kind | Resource | Purpose |
|---|---|---|
| IAM Role | `onprem-eso-role` | External Secrets |
| IAM Role | `onprem-s3-full-access`, `onprem-s3-readonly-access` | S3 access |
| IAM Role | `op-usxpress-dev-external-secrets` | ESO (IRSA) |
| IAM Role | `op-usxpress-dev-ecr-credentials-sync` | ECR credential sync (IRSA) |
| IAM Role | `iaac-octopus-worker-op-usxpress-dev` | Octopus worker (IRSA) |
| OIDC Provider | `dkrpl45zmi6ob.cloudfront.net`, `drabsoyu9b2fp.cloudfront.net` | IRSA trust anchor (2 rebuilds' worth) |
| S3 | `dpl2-local-test-tfstate` (us-east-1) | tf state + MageRunner local test state |
| SM | `mongo-cluster-dev-enterprise` | brands-api MongoDB (manually copied from cloud) |

### USX-Development (700736442855, us-east-2) — target
| Kind | Resource | Status |
|---|---|---|
| S3 | `op-usxpress-dev-tfstate` (us-east-2) | ✅ already exists (created 2026-03-24, likely pre-provisioned) |
| SM | `dx__geoservices-kafka-creds` (us-east-2) | ✅ exists, auto-rotated every 60 days by `ccloud-kafka-key-rotation` Lambda |
| SM | `mongo-cluster-dev-enterprise` (us-east-2) | ✅ exists (real source) |
| SM | `mongo-cluster-dev-edi` (us-east-2) | ✅ exists |
| IAM Roles | On-prem-specific | ❌ to be created |
| OIDC Provider | On-prem CloudFront | ❌ to be created |

---

## 3. Execution plan

### Step 1 — Wire `irsa` module into `iaac-talos` terraform (IaC first)

**File:** `iaac-talos/deploy/terraform/main.tf`

**Change:** add a `module "irsa"` invocation so cluster rebuild creates its own OIDC + IAM roles in whichever AWS account the terraform provider targets. Currently the module exists at `modules/irsa/` but is not called. Also add variables `aws_region`, `oidc_bucket_name` to `variables.tf`.

**Why IaC:** removes manual step of creating OIDC+roles; makes the rebuild completely reproducible.

### Step 2 — Flip Octopus variables for on-prem dev

**File:** `iaac-octopus-overrides/onprem-development.yaml`

Changes (development scope only, Environments-1081):
| Variable | Before | After |
|---|---|---|
| `DX__EKSCluster.CLUSTER_REGION` | us-east-1 | us-east-2 |
| `DX__TFState.S3_BUCKET` | dpl2-local-test-tfstate | op-usxpress-dev-tfstate |
| `DX__AWSAccounts.AWS_ACCOUNT_dev` | 786352483360 | 700736442855 |
| `DX__AWSAccounts.AWS_REGION_dev` | us-east-1 | us-east-2 |
| `DX__AWSAccessKeys.AWS_ROLE_TO_ASSUME` | `…:786352483360:role/iaac-octopus-worker-op-usxpress-dev` | `…:700736442855:role/iaac-octopus-worker-op-usxpress-dev` |
| `DX__AWSAccessKeys.AWS_DEFAULT_REGION` | us-east-1 | us-east-2 |

**Role name stays identical** so the `irsa` module's role creation matches what Octopus expects.

### Step 3 — Update worker inline policies terraform

**File:** `iaac-octopus-overrides/terraform/worker-iam-policies.tf`

Changes:
- Backend: `dpl2-local-test-tfstate / us-east-1 / profile=playground` → `op-usxpress-dev-tfstate / us-east-2 / profile=usx-dev`
- Provider: `region=us-east-1, profile=playground` → `region=us-east-2, profile=usx-dev`
- SSM policy resource ARN: `us-east-1:786352483360` → `us-east-2:700736442855`

### Step 4 — Update flux-platform manifests

| File | Change |
|---|---|
| `iaac-talos-flux-platform/infrastructure/external-secrets-config/clustersecretstore.yaml` | `region: us-east-1` → `us-east-2` |
| `iaac-talos-flux-platform/infrastructure/external-secrets/helmrelease.yaml` | role-arn account: 786352483360 → 700736442855; role name: `dpl2-external-secrets` → `op-usxpress-dev-external-secrets` |
| `iaac-talos-flux-platform/infrastructure/ecr-credentials/rbac.yaml` | role-arn account: 786352483360 → 700736442855; role name: `dpl2-ecr-credentials-sync` → `op-usxpress-dev-ecr-credentials-sync` |
| `iaac-talos-flux-platform/infrastructure/app-namespaces/serviceaccounts.yaml` | 19 SA role-arns: account 786352483360 → 700736442855 (role names kept as `dpl2-*` for now; separate rename initiative) |

**Note on ECR**: `cronjob.yaml` keeps the ECR registry account `064859874041` unchanged (images come from devops regardless of cluster's home account). Only the IRSA role identity used to pull changes.

### Step 5 — Update onboard-app.py + GHA workflow

| File | Change |
|---|---|
| `iaac-octopus-overrides/onboard-app.py` | `ONPREM_STATE_REGION=us-east-2`, `ONPREM_AWS_PROFILE=usx-dev`, `ONPREM_AWS_ACCOUNT=700736442855`. Remove mongo-atlas-copy logic (Mongo secrets already native in usx-dev). |
| `iaac-octopus-overrides/.github/workflows/onboard-app.yaml` | `aws-region: us-east-1 → us-east-2` |

### Step 6 — Destroy current cluster

Routine by now (April 16 session codified this):
```
export AWS_PROFILE=playground
export AWS_DEFAULT_REGION=us-east-1
export S3_BUCKET=dpl2-local-test-tfstate
cd ~/iaac-talos/deploy
terraform -chdir=terraform init -backend-config=...
terraform -chdir=terraform destroy -auto-approve
```

Leaves Playground state + IAM roles + OIDC in place (cleanup Phase 6).

### Step 7 — Rebuild cluster pointing at usx-dev

```
export AWS_PROFILE=usx-dev
export AWS_DEFAULT_REGION=us-east-2
export S3_BUCKET=op-usxpress-dev-tfstate
cd ~/iaac-talos/deploy
terraform -chdir=terraform init -backend-config=...
terraform -chdir=terraform apply -auto-approve
```

Terraform creates in usx-dev:
- S3 bucket for OIDC discovery (e.g. `op-usxpress-dev-irsa-oidc`)
- CloudFront distribution fronting it
- IAM OIDC provider registered to the CloudFront URL
- IAM roles: `op-usxpress-dev-external-secrets`, `op-usxpress-dev-ecr-credentials-sync`, `iaac-octopus-worker-op-usxpress-dev`
- vSphere VMs (new), Talos cluster, Cilium, Flux
- Flux reconciles platform with new ARNs

### Step 8 — Apply worker inline policies

```
cd ~/iaac-octopus-overrides/terraform
terraform init -reconfigure
terraform apply
```

Attaches SSM/ECR/SM inline policies to the `iaac-octopus-worker-op-usxpress-dev` role in usx-dev.

### Step 9 — Validate

- [ ] Flux reconciles cleanly (no ImagePullBackOff, no ExternalSecret errors)
- [ ] brands-api pod 1/1 Running
- [ ] geoenrichment-sync-handler pod 1/1 Running (Kafka creds native this time — no copy needed)
- [ ] Octopus MageRunner deploy of a new app end-to-end (Bento → apply → running pod)

### Step 10 — Phase 6 cleanup (AFTER ≥2 days stable)

Manually revoke in Playground:
- 6 IAM roles
- 2 CloudFront distributions + their OIDC providers
- `dpl2-local-test-tfstate` (after copying any historical MageRunner state off)
- `mongo-cluster-dev-enterprise` secret (once confirmed ESO is pulling from usx-dev copy)

Separate cleanup PR for record-keeping.

---

## 4. Decisions and assumptions

1. **Role naming**: preserve `op-usxpress-dev-external-secrets`, `-ecr-credentials-sync`, `iaac-octopus-worker-op-usxpress-dev` exactly in usx-dev (matches Octopus expectations, minimizes diff).
2. **SA (app) role naming**: keep `dpl2-*` prefix in usx-dev for now — renaming those is a broader initiative, out of scope for Phase 2. **Account flipped now (786→700), but the per-app roles do not yet exist in usx-dev.** Apps with IRSA needs (driver-insights-cron, ocs-cisive-handler, etc.) will fail AWS assumes until Phase 3 creates per-app roles. Since most of these apps were already in CrashLoopBackOff on placeholder secrets, this migration is not a regression for them.
3. **iaac-talos branch policy**: changes go on fork branch `feature/op-usxpress-dev`. PR to upstream deferred pending Vibin sign-off.
4. **Region**: us-east-2 throughout (matches usx-dev workload region + Kafka creds + pre-provisioned state bucket).
5. **Playground cleanup**: deferred until ≥2 days of stable cutover.
6. **Rollback**: if usx-dev cutover fails, revert Octopus variables + flux annotations, re-run with `AWS_PROFILE=playground` (playground infra still fully in place).

---

## 5. Risk register

| Risk | Mitigation |
|---|---|
| Terraform backend switch orphans state | Playground state left intact (not deleted). Can rebuild from either account for ~2 weeks. |
| `irsa` module first-time wiring has bugs | Test in usx-dev is effectively a net-new deploy; zero blast radius on cloud or playground. Can destroy+retry freely. |
| CloudFront provisioning slow (~15min) | Plan cutover window assuming ~20 min just for CF + OIDC provider creation. |
| SM Kafka auto-rotation breaks mid-cutover | Unlikely (60-day cadence, last rotated 2026-03-15 → next 2026-05-15). Well outside cutover window. |
| ExternalSecret refresh picks up stale cached SM data | Tighten `refreshInterval` to 1h on Kafka-backed ExternalSecrets; audit after rebuild. |
| Octopus on-prem worker pool registration lost | Worker pool is in OnPremise space; IRSA role name kept identical so worker registration continues to work. Verify post-cutover. |

---

## 6. Review checkpoints

- [ ] **Pre-execution**: this document reviewed by user (self-review 2026-04-21).
- [ ] **Post-edit**: all file diffs reviewed before git push.
- [ ] **Pre-destroy**: final confirmation before destroying current cluster.
- [ ] **Post-rebuild**: brands-api + geo-handler validated before declaring cutover done.
- [ ] **Pre-cleanup (Phase 6)**: ≥48h stable + user approval before touching Playground.

---

## 7. Timeline

- **2026-04-21**: Phase 2a plan + edits (today)
- **2026-04-22**: Rebuild + validate
- **2026-04-24** (earliest): Playground cleanup if stable
- **2026-05-04**: User PTO (should be done well before)

---

## 8. Related docs / memory

- `memory/onprem_session_april16_2026.md` — brands-api success + codified destroy+rebuild runbook
- `memory/vibin_decisions_march31.md` — Vibin's architectural direction
- `memory/feedback_zero_cloud_impact.md` — cloud-safety invariants
- Phase 1 discovery: inline above
