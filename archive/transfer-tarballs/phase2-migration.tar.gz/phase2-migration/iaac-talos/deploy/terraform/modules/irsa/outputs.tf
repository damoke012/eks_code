output "oidc_issuer_url" {
  description = "Full OIDC issuer URL (used by Talos API server and IAM role trust policies)"
  value       = "https://${local.oidc_issuer_hostpath}"
}

output "oidc_provider_arn" {
  description = "ARN of the IAM OIDC Identity Provider (used in IAM role trust policies)"
  value       = aws_iam_openid_connect_provider.irsa.arn
}

output "oidc_bucket_arn" {
  description = "ARN of the S3 OIDC bucket"
  value       = aws_s3_bucket.oidc.arn
}

output "cloudfront_domain_name" {
  description = "CloudFront domain name serving OIDC discovery documents"
  value       = aws_cloudfront_distribution.oidc.domain_name
}

output "cloudfront_distribution_id" {
  description = "CloudFront distribution ID (used for cache invalidation)"
  value       = aws_cloudfront_distribution.oidc.id
}

output "oidc_bucket_name" {
  description = "S3 bucket name for OIDC discovery"
  value       = aws_s3_bucket.oidc.id
}

output "ecr_credentials_role_arn" {
  description = "ARN of the ECR credentials sync IAM role"
  value       = aws_iam_role.ecr_credentials.arn
}

output "external_secrets_role_arn" {
  description = "ARN of the External Secrets IAM role"
  value       = aws_iam_role.external_secrets.arn
}

output "octopus_worker_role_arn" {
  description = "ARN of the Octopus Worker IAM role (used by the on-prem octopus-worker StatefulSet via IRSA)"
  value       = aws_iam_role.octopus_worker.arn
}

