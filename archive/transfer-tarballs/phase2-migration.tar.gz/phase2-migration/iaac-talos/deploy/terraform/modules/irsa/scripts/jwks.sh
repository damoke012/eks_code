#!/bin/bash
set -e

# Read the PEM key from Terraform external data source input
eval "$(jq -r '@sh "PEM_KEY=\(.pem_key)"')"

# Talos stores the key as base64-encoded PEM — decode it first
TMPFILE=$(mktemp)
echo "$PEM_KEY" | base64 -d > "$TMPFILE"

# Extract RSA modulus in hex, convert to base64url (using python3 instead of xxd for portability)
MODULUS_HEX=$(openssl rsa -in "$TMPFILE" -modulus -noout | cut -d'=' -f2)
MODULUS_B64URL=$(python3 -c "import sys,base64; print(base64.urlsafe_b64encode(bytes.fromhex('${MODULUS_HEX}')).rstrip(b'=').decode())")

rm -f "$TMPFILE"

# Output JSON with modulus and exponent (65537 = AQAB in base64url)
jq -n --arg n "$MODULUS_B64URL" --arg e "AQAB" '{"n": $n, "e": $e}'
