locals {
  oidc_issuer_hostpath = aws_cloudfront_distribution.oidc.domain_name
  s3_origin_id         = "S3-${var.oidc_bucket_name}"
}

# --- S3 Bucket for OIDC Discovery (private) ---
resource "aws_s3_bucket" "oidc" {
  bucket = var.oidc_bucket_name

  tags = {
    Cluster = var.cluster_name
    Purpose = "IRSA OIDC Discovery"
  }
}

# --- CloudFront Origin Access Control ---
resource "aws_cloudfront_origin_access_control" "oidc" {
  name                              = "${var.oidc_bucket_name}-oac"
  origin_access_control_origin_type = "s3"
  signing_behavior                  = "always"
  signing_protocol                  = "sigv4"
}

# --- S3 Bucket Policy: Allow CloudFront OAC only ---
resource "aws_s3_bucket_policy" "oidc" {
  bucket = aws_s3_bucket.oidc.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect    = "Allow"
        Principal = { Service = "cloudfront.amazonaws.com" }
        Action    = "s3:GetObject"
        Resource  = "${aws_s3_bucket.oidc.arn}/*"
        Condition = {
          StringEquals = {
            "AWS:SourceArn" = aws_cloudfront_distribution.oidc.arn
          }
        }
      }
    ]
  })
}

# --- CloudFront Distribution ---
resource "aws_cloudfront_distribution" "oidc" {
  enabled             = true
  comment             = "IRSA OIDC Discovery for ${var.cluster_name}"
  default_root_object = ""
  price_class         = "PriceClass_100"

  origin {
    domain_name              = aws_s3_bucket.oidc.bucket_regional_domain_name
    origin_id                = local.s3_origin_id
    origin_access_control_id = aws_cloudfront_origin_access_control.oidc.id
  }

  default_cache_behavior {
    allowed_methods        = ["GET", "HEAD"]
    cached_methods         = ["GET", "HEAD"]
    target_origin_id       = local.s3_origin_id
    viewer_protocol_policy = "redirect-to-https"

    forwarded_values {
      query_string = false
      cookies {
        forward = "none"
      }
    }

    min_ttl     = 0
    default_ttl = 86400
    max_ttl     = 86400
  }

  restrictions {
    geo_restriction {
      restriction_type = "none"
    }
  }

  viewer_certificate {
    cloudfront_default_certificate = true
  }

  tags = {
    Cluster = var.cluster_name
    Purpose = "IRSA OIDC Discovery"
  }
}

# --- OIDC Discovery Document ---
resource "aws_s3_object" "oidc_discovery" {
  bucket       = aws_s3_bucket.oidc.id
  key          = ".well-known/openid-configuration"
  content_type = "application/json"

  content = jsonencode({
    issuer                                = "https://${local.oidc_issuer_hostpath}"
    jwks_uri                              = "https://${local.oidc_issuer_hostpath}/keys.json"
    authorization_endpoint                = "urn:kubernetes:programmatic_authorization"
    response_types_supported              = ["id_token"]
    subject_types_supported               = ["public"]
    id_token_signing_alg_values_supported = ["RS256"]
    claims_supported                      = ["sub", "iss"]
  })

  depends_on = [aws_s3_bucket_policy.oidc]
}

# --- IAM OIDC Identity Provider ---
resource "aws_iam_openid_connect_provider" "irsa" {
  url             = "https://${local.oidc_issuer_hostpath}"
  client_id_list  = ["sts.amazonaws.com"]
  # Use all-zeros thumbprint — AWS no longer validates CloudFront/S3 thumbprints
  # for OIDC providers. This avoids cert rotation issues.
  thumbprint_list = ["0000000000000000000000000000000000000000"]

  tags = {
    Cluster = var.cluster_name
    Purpose = "IRSA"
  }
}

# --- IAM Role: ECR Credentials Sync ---
resource "aws_iam_role" "ecr_credentials" {
  name = "${var.cluster_name}-ecr-credentials-sync"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Federated = aws_iam_openid_connect_provider.irsa.arn }
      Action    = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          "${local.oidc_issuer_hostpath}:sub" = "system:serviceaccount:ecr-credentials:ecr-credentials-sync"
          "${local.oidc_issuer_hostpath}:aud" = "sts.amazonaws.com"
        }
      }
    }]
  })

  tags = {
    Cluster = var.cluster_name
    Purpose = "ECR credentials sync"
  }
}

resource "aws_iam_role_policy_attachment" "ecr_credentials" {
  role       = aws_iam_role.ecr_credentials.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
}

# --- IAM Role: External Secrets ---
resource "aws_iam_role" "external_secrets" {
  name = "${var.cluster_name}-external-secrets"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Federated = aws_iam_openid_connect_provider.irsa.arn }
      Action    = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          "${local.oidc_issuer_hostpath}:sub" = "system:serviceaccount:external-secrets:external-secrets"
          "${local.oidc_issuer_hostpath}:aud" = "sts.amazonaws.com"
        }
      }
    }]
  })

  tags = {
    Cluster = var.cluster_name
    Purpose = "External Secrets Operator"
  }
}

resource "aws_iam_role_policy" "external_secrets" {
  name = "secrets-manager"
  role = aws_iam_role.external_secrets.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = [
        "secretsmanager:GetSecretValue",
        "secretsmanager:DescribeSecret",
        "secretsmanager:ListSecrets"
      ]
      Resource = "*"
    }]
  })
}

# --- IAM Role: Octopus Worker ---
# Mirrors the cloud iaac-octopus-worker-usxpress-dev role pattern: minimal
# permissions, just `assume_any` so the worker can chain into deployment-
# specific roles, plus `s3` access to dx-packages* buckets for pulling DX
# deployment packages. The trust policy points at this cluster's CloudFront
# OIDC provider so the role is rebuilt automatically with each cluster.
resource "aws_iam_role" "octopus_worker" {
  name = "iaac-octopus-worker-${var.cluster_name}"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Federated = aws_iam_openid_connect_provider.irsa.arn }
      Action    = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          "${local.oidc_issuer_hostpath}:sub" = "system:serviceaccount:octopus:octopusworker"
          "${local.oidc_issuer_hostpath}:aud" = "sts.amazonaws.com"
        }
      }
    }]
  })

  tags = {
    Cluster = var.cluster_name
    Purpose = "Octopus worker on-prem MageRunner runner"
  }
}

# Allows the worker to chain into any downstream IAM role (e.g. octopus-usxpress
# in Playground for app deploys). Mirrors cloud `assume_any` inline policy.
resource "aws_iam_role_policy" "octopus_worker_assume_any" {
  name = "assume_any"
  role = aws_iam_role.octopus_worker.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Sid      = "AssumeAll"
      Effect   = "Allow"
      Action   = ["sts:AssumeRole"]
      Resource = ["*"]
    }]
  })
}

# Read access to dx-packages* buckets for DX deployment package downloads.
# Mirrors cloud `s3` inline policy.
resource "aws_iam_role_policy" "octopus_worker_s3" {
  name = "s3"
  role = aws_iam_role.octopus_worker.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = ["s3:ListBucket", "s3:GetBucketLocation"]
        Resource = "arn:aws:s3:::dx-packages*"
      },
      {
        Effect   = "Allow"
        Action   = "s3:GetObject"
        Resource = "arn:aws:s3:::dx-packages*/*"
      }
    ]
  })
}

