output "kubeconfig" {
  description = "Kubeconfig for the new cluster"
  value       = module.talos.kubeconfig_raw
  sensitive   = true
}

output "control_plane_ips" {
  description = "IP addresses of control-plane nodes"
  value       = module.vsphere_cp.ip_addresses
}

output "worker_ips" {
  description = "IP addresses of worker nodes"
  value       = module.vsphere_worker.ip_addresses
}

output "flux_manifests_path" {
  description = "Path in repository where Flux manifests are stored"
  value       = module.flux.path
}

output "oidc_issuer_url" {
  description = "IRSA OIDC issuer URL (register this in IAM if any external account needs to trust it)"
  value       = module.irsa.oidc_issuer_url
}

output "oidc_provider_arn" {
  description = "IAM OIDC provider ARN for IRSA"
  value       = module.irsa.oidc_provider_arn
}

output "external_secrets_role_arn" {
  description = "IAM role ARN for External Secrets Operator (annotate the SA with this)"
  value       = module.irsa.external_secrets_role_arn
}

output "ecr_credentials_role_arn" {
  description = "IAM role ARN for ECR credentials sync"
  value       = module.irsa.ecr_credentials_role_arn
}

output "octopus_worker_role_arn" {
  description = "IAM role ARN for Octopus worker (on-prem MageRunner runner)"
  value       = module.irsa.octopus_worker_role_arn
}
