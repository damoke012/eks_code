#!/usr/bin/env python3
"""
Reverse of patch-setup-variables.py: restores the original SSM kubeconfig
block in OnPremise space's DX__SetupVariables ScriptModule.

Source of truth is cloud USXpress space (Spaces-245). The OnPremise space was
cloned from cloud, so cloud still has the pristine SetupVariables module.
We fetch the original `if ($useEksApi -eq "false") { ... }` block from cloud
and paste it in place of the "Kubeconfig deferred to DX-Apply" skip message.

READS: Spaces-245 (cloud, USXpress)   — DX__SetupVariables ScriptModule only
WRITES: Spaces-302 (OnPremise)        — DX__SetupVariables ScriptModule only

Usage:
    OCTOPUS_API_KEY=API-... ./revert-setup-variables.py [--dry-run]
"""

import argparse
import json
import os
import sys
import urllib.error
import urllib.request

OCTO = "https://octopus.usxpress.io"
SRC_SPACE = "Spaces-245"   # cloud USXpress (READ only)
DST_SPACE = "Spaces-302"   # OnPremise (WRITE)
LVS_NAME = "DX__SetupVariables"
SKIP_MARKER = "Kubeconfig deferred to DX-Apply"
SSM_BLOCK_START = 'if ($useEksApi -eq "false")'


def api(method, path, space, body=None, key=None):
    # Enforce write-lock: only DST_SPACE may be written to.
    if method != "GET" and space != DST_SPACE:
        sys.exit(f"REFUSING: write to {space} blocked; only {DST_SPACE} allowed")
    req = urllib.request.Request(
        f"{OCTO}/api/{space}{path}",
        data=json.dumps(body).encode() if body is not None else None,
        headers={"X-Octopus-ApiKey": key, "Content-Type": "application/json"},
        method=method,
    )
    try:
        with urllib.request.urlopen(req) as r:
            data = r.read()
            return json.loads(data) if data else {}
    except urllib.error.HTTPError as e:
        sys.exit(f"HTTP {e.code} on {method} {path} ({space}): {e.read().decode()[:300]}")


def get_script_module_body(space, key):
    lvs_list = api("GET", "/libraryvariablesets?take=200", space, key=key)
    lvs = None
    for item in lvs_list.get("Items", []):
        if item["Name"] == LVS_NAME:
            lvs = item
            break
    if not lvs:
        sys.exit(f"{LVS_NAME} not found in {space}")
    vsid = lvs["VariableSetId"]
    vs = api("GET", f"/variables/{vsid}", space, key=key)
    for v in vs["Variables"]:
        if v["Name"] == f"Octopus.Script.Module[{LVS_NAME}]":
            return vs, vsid, v
    sys.exit(f"Script module variable not found in {space}")


def extract_ssm_block(script):
    """Find the `if ($useEksApi -eq "false") { ... }` block by brace counting."""
    if SSM_BLOCK_START not in script:
        return None
    start_idx = script.index(SSM_BLOCK_START)
    depth = 0
    in_body = False
    for i in range(start_idx, len(script)):
        c = script[i]
        if c == '{':
            depth += 1
            in_body = True
        elif c == '}':
            depth -= 1
            if in_body and depth == 0:
                return script[start_idx:i + 1]
    return None


def main():
    ap = argparse.ArgumentParser(description="Revert DX__SetupVariables on-prem patch")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    key = os.environ.get("OCTOPUS_API_KEY")
    if not key:
        sys.exit("OCTOPUS_API_KEY not set")

    # Pull cloud original
    print(f"Reading cloud {LVS_NAME} from {SRC_SPACE} (read-only)...")
    _, _, cloud_var = get_script_module_body(SRC_SPACE, key)
    cloud_script = cloud_var["Value"]
    original_block = extract_ssm_block(cloud_script)
    if not original_block:
        sys.exit(
            f"Could not find {SSM_BLOCK_START!r} block in cloud {LVS_NAME}. "
            "Cloud module may have changed — manual review required."
        )
    print(f"  extracted original block ({len(original_block)} chars)")

    # Pull onprem patched
    onprem_vs, onprem_vsid, onprem_var = get_script_module_body(DST_SPACE, key)
    onprem_script = onprem_var["Value"]

    if SKIP_MARKER not in onprem_script:
        print(f"ALREADY REVERTED (no {SKIP_MARKER!r} marker found in {DST_SPACE})")
        return

    # The patched block is the if-block containing SKIP_MARKER. Find & replace.
    patched_block = extract_ssm_block(onprem_script)
    if not patched_block or SKIP_MARKER not in patched_block:
        sys.exit(
            f"Found marker but could not isolate patched block. "
            "Manual review of onprem {LVS_NAME} required."
        )
    print(f"  located patched block ({len(patched_block)} chars)")

    new_script = onprem_script.replace(patched_block, original_block)

    if args.dry_run:
        print("DRY-RUN: would restore original SSM block in {DST_SPACE}")
        print(f"  -- REPLACE ({len(patched_block)} chars) --")
        print(patched_block[:200] + ("..." if len(patched_block) > 200 else ""))
        print(f"  -- WITH ({len(original_block)} chars) --")
        print(original_block[:200] + ("..." if len(original_block) > 200 else ""))
        return

    onprem_var["Value"] = new_script
    api("PUT", f"/variables/{onprem_vsid}", DST_SPACE, body=onprem_vs, key=key)
    print(f"REVERTED: {LVS_NAME} in {DST_SPACE} restored to cloud-equivalent state")


if __name__ == "__main__":
    main()
