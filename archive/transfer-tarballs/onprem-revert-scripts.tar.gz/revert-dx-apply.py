#!/usr/bin/env python3
"""
Reverse of patch-dx-apply.py: removes the SSM kubeconfig block from a project's
DX-Apply inline script in OnPremise space.

The block was inserted by patch-dx-apply.py immediately before the marker
`chmod +x ./mage/mage`, starting with `# On-prem kubeconfig from SSM`. We
locate both markers and excise everything between (inclusive of the leading
marker, exclusive of the chmod line). Cloud space is never touched.

Usage:
    OCTOPUS_API_KEY=API-... ./revert-dx-apply.py --project brands-api [--dry-run]
    OCTOPUS_API_KEY=API-... ./revert-dx-apply.py --all [--dry-run]

Cloud-safety: only modifies deployment processes in Spaces-302 (OnPremise).
"""

import argparse
import json
import os
import sys
import urllib.error
import urllib.request

OCTO = "https://octopus.usxpress.io"
DST_SPACE = "Spaces-302"

BLOCK_START = "# On-prem kubeconfig from SSM"
BLOCK_END_MARKER = "chmod +x ./mage/mage"


def api(method, path, body=None, key=None):
    req = urllib.request.Request(
        f"{OCTO}{path}",
        data=json.dumps(body).encode() if body is not None else None,
        headers={"X-Octopus-ApiKey": key, "Content-Type": "application/json"},
        method=method,
    )
    try:
        with urllib.request.urlopen(req) as r:
            data = r.read()
            return json.loads(data) if data else {}
    except urllib.error.HTTPError as e:
        err = e.read().decode()[:400]
        print(f"  HTTP {e.code} on {method} {path}: {err}", file=sys.stderr)
        return None


def find_project(name, key):
    d = api("GET", f"/api/{DST_SPACE}/projects?partialName={name}&take=10", key=key)
    if not d:
        return None
    for p in d.get("Items", []):
        if p["Name"] == name:
            return p
    return None


def revert_project(project_name, key, dry_run=False):
    print(f"\n{'='*50}")
    print(f"Reverting DX-Apply for: {project_name}")

    proj = find_project(project_name, key)
    if not proj:
        print(f"  ERROR: project {project_name!r} not found in {DST_SPACE}")
        return False

    dp_id = f"deploymentprocess-{proj['Id']}"
    dp = api("GET", f"/api/{DST_SPACE}/deploymentprocesses/{dp_id}", key=key)
    if not dp:
        print("  ERROR: deployment process not found")
        return False

    for step in dp.get("Steps", []):
        for action in step.get("Actions", []):
            if action["Name"] != "DX-Apply":
                continue

            script = action["Properties"].get("Octopus.Action.Script.ScriptBody", "")

            if BLOCK_START not in script:
                print("  ALREADY REVERTED: no SSM kubeconfig block present")
                return True

            if BLOCK_END_MARKER not in script:
                print(f"  ERROR: end marker '{BLOCK_END_MARKER}' not found")
                return False

            start_idx = script.index(BLOCK_START)
            end_idx = script.index(BLOCK_END_MARKER, start_idx)
            # Everything from BLOCK_START up to (but not including) chmod
            removed = script[start_idx:end_idx]
            new_script = script[:start_idx] + script[end_idx:]

            print(f"  located block ({len(removed)} chars)")

            if dry_run:
                print("  DRY-RUN: would remove block")
                return True

            action["Properties"]["Octopus.Action.Script.ScriptBody"] = new_script
            result = api("PUT", f"/api/{DST_SPACE}/deploymentprocesses/{dp_id}", body=dp, key=key)
            if result:
                print(f"  REVERTED: SSM kubeconfig block removed ({len(removed)} chars)")
                return True
            else:
                print("  ERROR: failed to save deployment process")
                return False

    print("  ERROR: DX-Apply action not found in deployment process")
    return False


def main():
    ap = argparse.ArgumentParser(description="Revert DX-Apply on-prem patch")
    ap.add_argument("--project", "-p", default="brands-api")
    ap.add_argument("--all", action="store_true",
                    help="Revert all module-coverage apps")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    key = os.environ.get("OCTOPUS_API_KEY")
    if not key:
        sys.exit("OCTOPUS_API_KEY not set")

    projects = [
        "brands-api",
        "geoenrichment-sync-handler",
        "attrition-api",
        "io-notifications-handler",
        "trailers-api",
        "safetylytx-video-api",
    ] if args.all else [args.project]

    ok = fail = 0
    for name in projects:
        if revert_project(name, key, args.dry_run):
            ok += 1
        else:
            fail += 1

    print(f"\nDone: {ok} ok, {fail} failed")
    if fail > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
