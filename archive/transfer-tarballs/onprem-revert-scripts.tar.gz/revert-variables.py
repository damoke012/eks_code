#!/usr/bin/env python3
"""
Reverse of apply.py: removes dev-scoped library variable set entries from
OnPremise space (Spaces-302) that match entries in the manifest.

Only removes variables whose Name matches a manifest entry AND whose scope is
exactly [development env_id]. Other scopes (qa, staging, production, unscoped,
combined) are never touched. If a variable exists at multiple scopes (e.g.
[dev, qa]), it is left alone — revert targets only pure dev-only entries that
apply.py added.

Usage:
    OCTOPUS_API_KEY=API-... ./revert-variables.py onprem-development.yaml [--dry-run]

Cloud-safety: hard-locked to Spaces-302. Refuses any other space.
"""

import argparse
import json
import os
import sys
import urllib.error
import urllib.request

import yaml

OCTO = "https://octopus.usxpress.io"


def api(method, path, body=None, key=None):
    req = urllib.request.Request(
        f"{OCTO}{path}",
        data=json.dumps(body).encode() if body is not None else None,
        headers={"X-Octopus-ApiKey": key, "Content-Type": "application/json"},
        method=method,
    )
    try:
        with urllib.request.urlopen(req) as r:
            data = r.read()
            return json.loads(data) if data else {}
    except urllib.error.HTTPError as e:
        sys.exit(f"HTTP {e.code} on {method} {path}: {e.read().decode()[:300]}")


def find_by_name(items, name):
    for it in items:
        if it.get("Name") == name:
            return it
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("manifest")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    key = os.environ.get("OCTOPUS_API_KEY")
    if not key:
        sys.exit("OCTOPUS_API_KEY not set")

    with open(args.manifest) as f:
        m = yaml.safe_load(f)

    space_id = m["space"]["id"]
    if space_id != "Spaces-302":
        sys.exit(
            f"REFUSING: manifest space {space_id!r} != Spaces-302 (OnPremise)."
        )

    target_env_name = m["target_environment"]
    envs = api("GET", f"/api/{space_id}/environments?take=100", key=key)["Items"]
    env = find_by_name(envs, target_env_name)
    if not env:
        sys.exit(f"target_environment {target_env_name!r} not found")
    env_id = env["Id"]

    print(f"OnPremise space: {space_id}")
    print(f"  reverting scope env={target_env_name} ({env_id})")
    print(f"  dry_run={args.dry_run}")
    print()

    lvs_index = {
        l["Name"]: l
        for l in api("GET", f"/api/{space_id}/libraryvariablesets?take=200", key=key)["Items"]
    }

    total_removed = total_skipped = total_not_found = 0

    for lvs_name, spec in m["library_variable_sets"].items():
        lvs = lvs_index.get(lvs_name)
        if not lvs:
            print(f"== {lvs_name} ==\n  not found in OnPremise, skipping\n")
            continue
        vsid = lvs["VariableSetId"]
        vs = api("GET", f"/api/{space_id}/variables/{vsid}", key=key)
        existing = vs.get("Variables", [])

        print(f"== {lvs_name} ({vsid}) ==")
        names_to_revert = set(spec["variables"].keys())
        kept = []
        for v in existing:
            if v["Name"] not in names_to_revert:
                kept.append(v)
                continue
            scope_envs = (v.get("Scope") or {}).get("Environment") or []
            other_scope_keys = {k for k in (v.get("Scope") or {}) if k != "Environment"}
            # Only remove if scope is EXACTLY [env_id] and nothing else.
            if scope_envs == [env_id] and not other_scope_keys:
                print(f"  - REMOVE {v['Name']} = {v['Value']!r}  scope=env={target_env_name}")
                total_removed += 1
            else:
                print(f"  = keep   {v['Name']} (scope differs: envs={scope_envs}, extra={sorted(other_scope_keys)})")
                total_skipped += 1
                kept.append(v)

        # Account for manifest entries that never existed
        removed_names = {v["Name"] for v in existing if v not in kept}
        for n in names_to_revert - removed_names:
            if not any(v["Name"] == n for v in existing):
                print(f"  ? missing {n} (nothing to revert)")
                total_not_found += 1

        if not args.dry_run:
            vs["Variables"] = kept
            api("PUT", f"/api/{space_id}/variables/{vsid}", body=vs, key=key)
            print(f"  saved {vsid}")
        print()

    print(
        f"summary: -{total_removed} removed  ={total_skipped} kept (scope mismatch)  "
        f"?{total_not_found} not-found"
    )
    if args.dry_run:
        print("(dry-run, nothing written)")


if __name__ == "__main__":
    main()
