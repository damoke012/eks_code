# DPL2 On-Premises Kubernetes Platform - Architecture & Implementation Document

**Project**: DPL2 Talos Kubernetes Cluster - DX Application Platform
**Date**: March 2026
**Status**: Platform Infrastructure Complete, Application Onboarding In Progress
**Author**: Cloud Platform Team

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Architecture Overview](#2-architecture-overview)
3. [Infrastructure Layer - Virtual Machines](#3-infrastructure-layer---virtual-machines)
4. [Talos Linux Kubernetes Cluster](#4-talos-linux-kubernetes-cluster)
5. [Networking & Load Balancing](#5-networking--load-balancing)
6. [GitOps Architecture - Flux CD](#6-gitops-architecture---flux-cd)
7. [Service Mesh - Istio Ambient](#7-service-mesh---istio-ambient)
8. [Certificate Management](#8-certificate-management)
9. [IRSA - IAM Roles for Service Accounts](#9-irsa---iam-roles-for-service-accounts)
10. [Secrets Management - External Secrets Operator](#10-secrets-management---external-secrets-operator)
11. [Container Registry - ECR Credential Sync](#11-container-registry---ecr-credential-sync)
12. [Terraform IRSA Roles Module](#12-terraform-irsa-roles-module)
13. [Application Namespaces & Workloads](#13-application-namespaces--workloads)
14. [MageRunner & Octopus Deploy Pipeline](#14-magerunner--octopus-deploy-pipeline)
15. [Deployment Sequence & Timeline](#15-deployment-sequence--timeline)
16. [Issues Encountered & Resolutions](#16-issues-encountered--resolutions)
17. [Current State & Next Steps](#17-current-state--next-steps)
18. [Appendix](#18-appendix)

---

## 1. Executive Summary

The DPL2 platform is an **on-premises Kubernetes cluster** running Talos Linux, designed to host all DX (Developer Experience) application workloads currently running on AWS EKS in production. The platform replicates the production EKS architecture on bare-metal infrastructure using:

- **Talos Linux** for an immutable, secure Kubernetes OS
- **Flux CD** for GitOps-driven infrastructure and application management
- **Istio Ambient Mesh** for zero-trust networking without sidecar overhead
- **IRSA** (IAM Roles for Service Accounts) for AWS credential injection via OIDC federation
- **External Secrets Operator** for AWS Secrets Manager integration
- **MageRunner/Octopus Deploy** for production-parity CI/CD pipelines

The platform supports **~156 application deployments** across **48 namespaces**, with **106 ExternalSecrets** syncing from AWS, and **20 IRSA IAM roles** for workload AWS access.

### Key Numbers

| Metric | Value |
|--------|-------|
| Physical Nodes | 8 (3 control-plane + 5 worker) |
| Kubernetes Version | v1.32.0 |
| Talos Version | v1.9.x |
| Application Namespaces | 37 |
| Application Deployments | 99 (deployed via Flux) |
| ExternalSecrets | 139 (all synced) |
| IRSA IAM Roles | 20 (via Terraform) |
| Flux Kustomizations | 18 (all Ready) |
| Helm Releases | 7 (cert-manager, external-secrets, istio x4, istio-csr) |
| AWS Account (Playground) | 786352483360 |
| AWS Account (ECR Images) | 064859874041 |

---

## 2. Architecture Overview

### High-Level Architecture Diagram

```
                                    ┌─────────────────────────────────────────────────────────────────┐
                                    │                    AWS CLOUD                                    │
                                    │                                                                 │
                                    │  ┌─────────────────────┐    ┌──────────────────────────────┐   │
                                    │  │  Playground Account  │    │  Infrastructure-Common Acct   │   │
                                    │  │   (786352483360)     │    │     (064859874041)            │   │
                                    │  │                      │    │                               │   │
                                    │  │  ┌────────────────┐  │    │  ┌─────────────────────────┐  │   │
                                    │  │  │ IAM OIDC       │  │    │  │  ECR Registries          │  │   │
                                    │  │  │ Provider       │  │    │  │  ┌───────────────────┐   │  │   │
                                    │  │  │ (CloudFront)   │  │    │  │  │ us-east-1 (4 imgs)│   │  │   │
                                    │  │  └───────┬────────┘  │    │  │  └───────────────────┘   │  │   │
                                    │  │          │           │    │  │  ┌───────────────────┐   │  │   │
                                    │  │  ┌───────▼────────┐  │    │  │  │ us-east-2 (97 img)│   │  │   │
                                    │  │  │ 20 IRSA Roles  │  │    │  │  └───────────────────┘   │  │   │
                                    │  │  │ (Terraform)    │  │    │  └─────────────────────────┘  │   │
                                    │  │  └────────────────┘  │    │                               │   │
                                    │  │                      │    └──────────────────────────────┘   │
                                    │  │  ┌────────────────┐  │                                       │
                                    │  │  │ AWS Secrets    │  │    ┌──────────────────────────────┐   │
                                    │  │  │ Manager        │  │    │       GitHub                  │   │
                                    │  │  │ (106 secrets)  │  │    │  ┌──────────────────────┐     │   │
                                    │  │  └────────────────┘  │    │  │ iaac-talos-flux-     │     │   │
                                    │  │                      │    │  │ cluster (master)     │     │   │
                                    │  │  ┌────────────────┐  │    │  ├──────────────────────┤     │   │
                                    │  │  │ S3 OIDC Bucket │  │    │  │ iaac-talos-flux-     │     │   │
                                    │  │  │ + CloudFront   │  │    │  │ platform (dpl2)      │     │   │
                                    │  │  └────────────────┘  │    │  └──────────────────────┘     │   │
                                    │  └─────────────────────┘    └──────────────────────────────┘   │
                                    └─────────────┬───────────────────────────────┬───────────────────┘
                                                  │ OIDC / STS                   │ Git Sync (5m)
                                                  │                              │
                    ┌─────────────────────────────────────────────────────────────────────────────────┐
                    │                     ON-PREMISES DATA CENTER (D1)                                │
                    │                     vSphere / Nutanix / vLAN 82                                 │
                    │                                                                                 │
                    │    ┌──────────────────────────────────────────────────────────────────────┐     │
                    │    │              DPL2 TALOS KUBERNETES CLUSTER                           │     │
                    │    │              VIP: 10.10.82.30:6443                                   │     │
                    │    │                                                                      │     │
                    │    │  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐                 │     │
                    │    │  │  CP Node 1   │ │  CP Node 2   │ │  CP Node 3   │  Control Plane  │     │
                    │    │  │ 10.10.82.22  │ │ 10.10.82.21  │ │ 10.10.82.23  │  (HA etcd)      │     │
                    │    │  │ 2 vCPU/4GB   │ │ 2 vCPU/4GB   │ │ 2 vCPU/4GB   │                 │     │
                    │    │  └──────────────┘ └──────────────┘ └──────────────┘                 │     │
                    │    │                                                                      │     │
                    │    │  ┌──────────────────────────┐ ┌──────────────────────────┐           │     │
                    │    │  │     Worker Node 1        │ │     Worker Node 2        │  Workers  │     │
                    │    │  │     10.10.82.139          │ │     10.10.82.138          │           │     │
                    │    │  │     2 vCPU / 4GB          │ │     2 vCPU / 4GB          │           │     │
                    │    │  └──────────────────────────┘ └──────────────────────────┘           │     │
                    │    │                                                                      │     │
                    │    │  ┌─────────────────────────────────────────────────────────────┐     │     │
                    │    │  │  Platform Services                                          │     │     │
                    │    │  │  ┌───────────┐ ┌──────────┐ ┌──────────┐ ┌──────────────┐  │     │     │
                    │    │  │  │ Flux CD   │ │ Istio    │ │ Cert-Mgr │ │ Pod Identity  │  │     │     │
                    │    │  │  │ (GitOps)  │ │ Ambient  │ │          │ │ Webhook       │  │     │     │
                    │    │  │  └───────────┘ └──────────┘ └──────────┘ └──────────────┘  │     │     │
                    │    │  │  ┌───────────┐ ┌──────────┐ ┌──────────┐ ┌──────────────┐  │     │     │
                    │    │  │  │ External  │ │ ECR Cred │ │ Cilium   │ │ Gateway API  │  │     │     │
                    │    │  │  │ Secrets   │ │ Sync     │ │ (CNI+LB) │ │ CRDs         │  │     │     │
                    │    │  │  └───────────┘ └──────────┘ └──────────┘ └──────────────┘  │     │     │
                    │    │  └─────────────────────────────────────────────────────────────┘     │     │
                    │    │                                                                      │     │
                    │    │  ┌─────────────────────────────────────────────────────────────┐     │     │
                    │    │  │  Application Namespaces (48)                                 │     │     │
                    │    │  │  enterprise, trailers, geoservices, tasks, orders, pricing,  │     │     │
                    │    │  │  truck, driver, freight, safety, messaging, vehicle, ...     │     │     │
                    │    │  └─────────────────────────────────────────────────────────────┘     │     │
                    │    └──────────────────────────────────────────────────────────────────────┘     │
                    └─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Infrastructure Layer - Virtual Machines

### vSphere Environment

| Property | Value |
|----------|-------|
| Datacenter | D1-Datacenter |
| Compute Cluster | D1 NTX PROD |
| Datastore | USXD1NTXPROD-SC1 |
| Network | 10.10.82 (vLAN 82) Prod |
| VM Folder | /KubernetesD1/TalosD1/dpl2-cluster |
| Content Library | dpl-cluster (Talos OVA templates) |
| Service Account | svc_terraform (TerraformAutomation role) |

### VM Specifications

```
┌─────────────────────────────────────────────────────────────┐
│                    vSphere D1-Datacenter                     │
│                    D1 NTX PROD Cluster                       │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │          /KubernetesD1/TalosD1/dpl2-cluster         │    │
│  │                                                      │    │
│  │  ┌────────────────┐  VM Spec (all nodes):           │    │
│  │  │ talos-cp-dpl2-1│  - Guest OS: otherGuest64       │    │
│  │  │ 10.10.82.22    │  - vCPUs: 2                     │    │
│  │  │ Control Plane  │  - RAM: 4096 MB                 │    │
│  │  ├────────────────┤  - Disk: 20 GB (thin)           │    │
│  │  │ talos-cp-dpl2-2│  - NIC: vmxnet3                 │    │
│  │  │ 10.10.82.21    │  - Source: Talos v1.9.x OVA     │    │
│  │  │ Control Plane  │                                  │    │
│  │  ├────────────────┤                                  │    │
│  │  │ talos-cp-dpl2-3│                                  │    │
│  │  │ 10.10.82.23    │                                  │    │
│  │  │ Control Plane  │                                  │    │
│  │  ├────────────────┤                                  │    │
│  │  │ talos-wk-dpl2-1│                                  │    │
│  │  │ 10.10.82.139   │                                  │    │
│  │  │ Worker         │                                  │    │
│  │  ├────────────────┤                                  │    │
│  │  │ talos-wk-dpl2-2│                                  │    │
│  │  │ 10.10.82.138   │                                  │    │
│  │  │ Worker         │                                  │    │
│  │  └────────────────┘                                  │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

### Terraform VM Provisioning

The VMs are provisioned using the `iaac-talos` repository with a custom `vsphere_vm` Terraform module. Key provisioning details:

1. **OVA Cloning**: VMs are cloned from a Talos OVA stored in the vSphere content library
2. **IP Assignment Workaround**: vSphere doesn't reliably report IPs during creation, so a 3-step process is used:
   - `wait_for_guest_net_timeout = 0` (don't wait for IP)
   - 60-second delay per VM (`terraform_data.delay_after_vm`)
   - Re-fetch VM info via `data.vsphere_virtual_machine.vm_info`
3. **Guest ID Fix**: `lifecycle { ignore_changes = [guest_id] }` prevents drift from vSphere reporting a different guest OS

### Terraform Variables (via Octopus Deploy)

| Variable | Value |
|----------|-------|
| `TF_VAR_cluster_name` | dpl2-cluster |
| `TF_VAR_control_plane_vip` | 10.10.82.30 |
| `TF_VAR_endpoint` | https://10.10.82.30:6443 |
| `TF_VAR_flux_target_path` | clusters/dpl2 |
| `TF_STATE_KEY` | iaac/talos/dpl2-cluster.tfstate |
| `S3_BUCKET` | lazy-tf-state-0k3nc997arlf7k1a |

---

## 4. Talos Linux Kubernetes Cluster

### Why Talos Linux

Talos is a purpose-built, immutable Linux distribution for Kubernetes:
- **No SSH/shell access** - managed entirely via API
- **Read-only root filesystem** - prevents drift
- **Minimal attack surface** - no package manager, no unnecessary services
- **Declarative configuration** - machine configs applied as YAML

### Cluster Bootstrap Sequence

```
┌──────────────────────────────────────────────────────────────────────┐
│                    TALOS BOOTSTRAP SEQUENCE                          │
│                                                                      │
│  Step 1: Generate Machine Secrets                                    │
│  ├── talos_machine_secrets.cluster                                   │
│  ├── Encryption keys, CA certificates                                │
│  └── SA signing key (used for IRSA JWKS)                            │
│                                                                      │
│  Step 2: Generate Machine Configurations                             │
│  ├── Control Plane config (machine type: controlplane)               │
│  │   ├── CNI: none (Cilium installed via inline manifest)            │
│  │   ├── kube-proxy: disabled (Cilium replaces it)                   │
│  │   ├── API server extraArgs:                                       │
│  │   │   ├── service-account-issuer: CloudFront OIDC URL             │
│  │   │   └── api-audiences: sts.amazonaws.com                        │
│  │   └── VIP: 10.10.82.30 on eth0                                   │
│  └── Worker config (machine type: worker)                            │
│      ├── CNI: none                                                   │
│      └── kube-proxy: disabled                                        │
│                                                                      │
│  Step 3: Apply Config to First CP Node                               │
│  ├── Inline Cilium Job manifest included                             │
│  └── Bootstrap etcd + API server                                     │
│                                                                      │
│  Step 4: Join Remaining CP Nodes (CP2, CP3)                         │
│  Step 5: Join Worker Nodes (WK1, WK2)                               │
│  Step 6: Generate Kubeconfig                                         │
│  Step 7: Bootstrap Flux CD                                           │
└──────────────────────────────────────────────────────────────────────┘
```

### API Server Configuration for IRSA

The Kubernetes API server is configured with custom flags to enable IRSA on-premises:

```yaml
apiServer:
  extraArgs:
    service-account-issuer: https://d2vt9kpivked44.cloudfront.net
    api-audiences: sts.amazonaws.com
```

This tells the API server to:
- Issue service account tokens with the CloudFront OIDC issuer URL
- Set the audience to `sts.amazonaws.com` for STS token exchange

---

## 5. Networking & Load Balancing

### Network Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                    NETWORK ARCHITECTURE                          │
│                    vLAN 82 (10.10.82.0/24)                       │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  Kubernetes API                                             │  │
│  │  VIP: 10.10.82.30:6443 (shared across 3 CP nodes)         │  │
│  └────────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  Cilium CNI                                                 │  │
│  │  ├── Pod CIDR: 10.244.0.0/16                               │  │
│  │  ├── Routing: Native (no VXLAN overlay)                     │  │
│  │  ├── Encryption: WireGuard (node-to-node)                   │  │
│  │  └── Replaces kube-proxy (eBPF datapath)                    │  │
│  └────────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  Cilium L2 LoadBalancer                                     │  │
│  │  ├── IP Pool: 10.10.82.20 - 10.10.82.254 (235 IPs)        │  │
│  │  ├── L2 Announcements (ARP on worker nodes only)            │  │
│  │  └── No BGP required (confirmed with network team)          │  │
│  └────────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  Istio Ambient Mesh (L4 ztunnel)                            │  │
│  │  ├── HBONE protocol (pod-to-pod mTLS)                       │  │
│  │  ├── Trust Domain: dpl2.mesh.usxpress                       │  │
│  │  └── Outbound Policy: REGISTRY_ONLY                         │  │
│  └────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────┘
```

### Cilium Configuration

| Setting | Value | Rationale |
|---------|-------|-----------|
| CNI | Cilium (replaces default) | Enterprise features, eBPF, matches EKS |
| Routing Mode | Native | Better datacenter performance than overlay |
| kube-proxy | Disabled | Cilium eBPF replaces it |
| Encryption | WireGuard | Node-to-node encryption |
| LoadBalancer | L2 (ARP) | No BGP infrastructure needed |
| IP Pool | 10.10.82.20-254 | 235 IPs for LoadBalancer services |

---

## 6. GitOps Architecture - Flux CD

### Repository Structure

```
┌─────────────────────────────────────────────────────────────────────┐
│                      FLUX GITOPS ARCHITECTURE                       │
│                                                                     │
│  ┌─────────────────────┐        ┌──────────────────────────────┐   │
│  │ iaac-talos           │        │ iaac-talos-flux-cluster      │   │
│  │ (Terraform)          │        │ (master branch)              │   │
│  │                      │        │                              │   │
│  │ Creates cluster +    │───────>│ clusters/dpl2/flux-system/   │   │
│  │ bootstraps Flux      │        │ ├── kustomization.yaml       │   │
│  │                      │        │ ├── infra-source.yaml        │   │
│  └─────────────────────┘        │ └── infra.yaml               │   │
│                                  │     (18 Kustomization CRs)    │   │
│                                  └──────────────┬───────────────┘   │
│                                                 │                    │
│                                    GitRepository │ (dpl2 branch)     │
│                                                 ▼                    │
│                                  ┌──────────────────────────────┐   │
│                                  │ iaac-talos-flux-platform     │   │
│                                  │ (dpl2 branch)                │   │
│                                  │                              │   │
│                                  │ infrastructure/              │   │
│                                  │ ├── cert-manager/            │   │
│                                  │ ├── cert-manager-issuers/    │   │
│                                  │ ├── istio/                   │   │
│                                  │ │   ├── base/                │   │
│                                  │ │   ├── istiod/              │   │
│                                  │ │   ├── cni/                 │   │
│                                  │ │   └── ztunnel/             │   │
│                                  │ ├── istio-csr/               │   │
│                                  │ ├── istio-namespace/         │   │
│                                  │ ├── cilium-lb/               │   │
│                                  │ ├── pod-identity-webhook/    │   │
│                                  │ ├── ecr-credentials/         │   │
│                                  │ ├── external-secrets/        │   │
│                                  │ ├── external-secrets-config/ │   │
│                                  │ ├── app-namespaces/          │   │
│                                  │ ├── app-secrets/             │   │
│                                  │ └── app-deployments/         │   │
│                                  └──────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
```

### Flux Kustomization Dependency Chain

All 18 Kustomizations follow a strict dependency ordering to ensure components are ready before dependents deploy:

```
                          ┌─────────────────┐
                          │  istio-namespace │
                          └────────┬────────┘
                                   │
              ┌────────────────────┤
              ▼                    ▼
     ┌─────────────────┐  ┌──────────────────┐
     │   cert-manager   │  │   cilium-lb      │  (no deps)
     └────────┬─────────┘  └──────────────────┘
              │
              ├─────────────────────────────────┐
              ▼                                 ▼
  ┌───────────────────────┐         ┌──────────────────────┐
  │ cert-manager-issuers  │         │ pod-identity-webhook │
  └───────────┬───────────┘         └──────────┬───────────┘
              │                                │
              ▼                     ┌──────────┼──────────┐
     ┌─────────────────┐           ▼          ▼          │
     │    istio-csr     │  ┌──────────────┐ ┌──────────────────┐
     └────────┬─────────┘  │ecr-credentials│ │external-secrets  │
              │            └──────┬───────┘ └────────┬─────────┘
              ▼                   │                   │
     ┌─────────────────┐         │          ┌────────▼──────────┐
     │   istio-base     │         │          │external-secrets-  │
     └────────┬─────────┘         │          │config             │
              │                   │          └────────┬──────────┘
              ▼                   │                   │
     ┌─────────────────┐         │                   │
     │     istiod       │         │                   │
     └────────┬─────────┘         │                   │
              │                   ▼                   │
     ┌────────┴────────┐  ┌──────────────┐           │
     ▼                ▼   │app-namespaces │◄──────────┘
┌──────────┐ ┌──────────┐ └──────┬───────┘
│istio-cni │ │ ztunnel  │        │
└──────────┘ └──────────┘        ▼
                          ┌──────────────┐
                          │ app-secrets  │
                          └──────┬───────┘
                                 │
                                 ▼
                         ┌───────────────┐
                         │app-deployments│
                         └───────────────┘
```

### Kustomization Common Settings

All Kustomizations use consistent settings:

```yaml
interval: 10m0s       # Check for changes every 10 minutes
retryInterval: 5m0s   # Retry on failure after 5 minutes
prune: true           # Remove resources deleted from Git
wait: true            # Wait for resources to be ready
timeout: 5m0s         # Timeout for health checks
```

### Helm Releases Deployed via Flux

| Release | Chart | Version | Namespace | Repository |
|---------|-------|---------|-----------|------------|
| cert-manager | cert-manager | v1.19.1 | cert-manager | charts.jetstack.io |
| external-secrets | external-secrets | 0.12.x | external-secrets | charts.external-secrets.io |
| istio-base | base | 1.27.3 | istio-system | istio-release.storage.googleapis.com |
| istiod | istiod | 1.27.3 | istio-system | istio-release.storage.googleapis.com |
| istio-cni | cni | 1.27.3 | istio-system | istio-release.storage.googleapis.com |
| istio-ztunnel | ztunnel | 1.27.3 | istio-system | istio-release.storage.googleapis.com |
| istio-csr | cert-manager-istio-csr | v0.14.3 | cert-manager | charts.jetstack.io |

---

## 7. Service Mesh - Istio Ambient

### Why Ambient Mode

Istio Ambient Mesh was chosen over traditional sidecar mode for the on-premises cluster:

| Aspect | Sidecar Mode | Ambient Mode (chosen) |
|--------|-------------|----------------------|
| Resource overhead | Envoy sidecar per pod | Shared ztunnel DaemonSet |
| Memory per pod | +50-100MB | 0 (no sidecar) |
| Pod startup | Slower (init container) | Normal |
| L4 security | mTLS via sidecar | mTLS via ztunnel |
| L7 features | Always available | Opt-in via waypoints |
| Complexity | Higher (injection) | Lower |

### Mesh Configuration

```
┌──────────────────────────────────────────────────────────────┐
│                  ISTIO AMBIENT MESH                          │
│                                                              │
│  Mesh ID:      dpl2.mesh.usxpress                           │
│  Trust Domain: dpl2.mesh.usxpress                           │
│  Cluster:      dpl2.talos.mesh.usxpress                     │
│  Network:      10.10.82 (vLAN 82) Prod                      │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Control Plane                                       │    │
│  │  ┌─────────┐  ┌───────────┐  ┌──────────────────┐  │    │
│  │  │ istiod  │  │ istio-csr │  │ cert-manager     │  │    │
│  │  │ (pilot) │  │ (bridge)  │  │ (CA authority)   │  │    │
│  │  └────┬────┘  └─────┬─────┘  └────────┬─────────┘  │    │
│  │       │             │                  │             │    │
│  │       │     ┌───────▼──────────────────▼──────┐     │    │
│  │       │     │  Self-Signed Root CA             │     │    │
│  │       │     │  CN: istio-ca                    │     │    │
│  │       │     │  Org: dpl2.mesh.usxpress         │     │    │
│  │       │     │  Duration: 10 years (87600h)     │     │    │
│  │       │     │  Algorithm: ECDSA P-256          │     │    │
│  │       │     └─────────────────────────────────┘     │    │
│  └───────┼─────────────────────────────────────────────┘    │
│          │                                                   │
│  ┌───────▼─────────────────────────────────────────────┐    │
│  │  Data Plane (per node)                               │    │
│  │  ┌──────────┐  ┌──────────┐                         │    │
│  │  │ ztunnel  │  │ istio-cni│  (DaemonSets - 5 pods) │    │
│  │  │ (L4 mTLS)│  │ (routing)│                         │    │
│  │  └──────────┘  └──────────┘                         │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  Outbound Policy: REGISTRY_ONLY                             │
│  (Pods can only reach explicitly registered services)        │
└──────────────────────────────────────────────────────────────┘
```

### Namespace Enrollment

All 48 application namespaces are enrolled in the ambient mesh via the label:

```yaml
metadata:
  labels:
    istio.io/dataplane-mode: ambient
```

This enables transparent L4 mTLS between all pods in labeled namespaces without any sidecar injection.

---

## 8. Certificate Management

### Certificate Chain

```
┌──────────────────────────────────────────────────────────────┐
│                 CERTIFICATE CHAIN                            │
│                                                              │
│  ┌─────────────────────────────────────┐                    │
│  │     Self-Signed Issuer              │                    │
│  │     (cert-manager.io/v1)            │                    │
│  └──────────────────┬──────────────────┘                    │
│                     │ signs                                  │
│                     ▼                                        │
│  ┌─────────────────────────────────────┐                    │
│  │     istio-ca Certificate            │                    │
│  │     isCA: true                      │                    │
│  │     Duration: 87600h (10 years)     │                    │
│  │     Algorithm: ECDSA 256            │                    │
│  │     Secret: istio-ca                │                    │
│  │     Namespace: istio-system         │                    │
│  └──────────────────┬──────────────────┘                    │
│                     │ used by                                │
│                     ▼                                        │
│  ┌─────────────────────────────────────┐                    │
│  │     istio-ca CA Issuer              │                    │
│  │     (cert-manager.io/v1)            │                    │
│  └──────────────────┬──────────────────┘                    │
│                     │ delegates to                           │
│                     ▼                                        │
│  ┌─────────────────────────────────────┐                    │
│  │     cert-manager-istio-csr          │                    │
│  │     (bridge to Istio)               │                    │
│  │     Listens on: :443                │                    │
│  │     Trust Domain: dpl2.mesh.usxpress│                    │
│  └──────────────────┬──────────────────┘                    │
│                     │ issues short-lived certs to            │
│                     ▼                                        │
│  ┌─────────────────────────────────────┐                    │
│  │     Workload Certificates           │                    │
│  │     (mTLS for pod-to-pod)           │                    │
│  │     Used by ztunnel for HBONE       │                    │
│  └─────────────────────────────────────┘                    │
│                                                              │
│  Pod Identity Webhook TLS:                                   │
│  ┌─────────────────────────────────────┐                    │
│  │     pod-identity-webhook cert       │                    │
│  │     Issued by cert-manager          │                    │
│  │     Injected into webhook config    │                    │
│  └─────────────────────────────────────┘                    │
└──────────────────────────────────────────────────────────────┘
```

---

## 9. IRSA - IAM Roles for Service Accounts

### IRSA Architecture on On-Premises Cluster

IRSA (IAM Roles for Service Accounts) allows Kubernetes pods to assume AWS IAM roles using projected service account tokens, validated via OIDC federation. This is the same mechanism used in EKS, adapted for on-premises use.

```
┌──────────────────────────────────────────────────────────────────────┐
│                         IRSA FLOW                                    │
│                                                                      │
│  ┌─────────────┐    1. Pod created with SA annotation                │
│  │   Pod Spec   │       eks.amazonaws.com/role-arn: arn:...          │
│  │              │                                                    │
│  └──────┬───────┘                                                    │
│         │                                                            │
│         ▼  2. MutatingWebhook intercepts                             │
│  ┌─────────────────────────────┐                                    │
│  │  Pod Identity Webhook       │  Injects:                          │
│  │  (MutatingWebhookConfig)    │  - AWS_ROLE_ARN env var            │
│  │                             │  - AWS_WEB_IDENTITY_TOKEN_FILE     │
│  │                             │  - Projected SA token volume       │
│  └──────┬──────────────────────┘    (audience: sts.amazonaws.com)   │
│         │                                                            │
│         ▼  3. Pod starts with token mounted                          │
│  ┌─────────────────────────────┐                                    │
│  │  Running Pod                │  Token at:                         │
│  │  (e.g., external-secrets)   │  /var/run/secrets/eks.amazonaws.   │
│  │                             │  com/serviceaccount/token          │
│  └──────┬──────────────────────┘                                    │
│         │                                                            │
│         │  4. AWS SDK calls STS AssumeRoleWithWebIdentity            │
│         │     with projected SA token                                │
│         ▼                                                            │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  AWS STS                                                     │    │
│  │                                                              │    │
│  │  5. Validates token:                                         │    │
│  │     a. Fetches JWKS from CloudFront                          │    │
│  │        https://d2vt9kpivked44.cloudfront.net/.well-known/    │    │
│  │     b. Verifies token signature with SA public key           │    │
│  │     c. Checks issuer matches IAM OIDC Provider               │    │
│  │     d. Checks audience = sts.amazonaws.com                   │    │
│  │     e. Checks sub = system:serviceaccount:<ns>:<sa>          │    │
│  │                                                              │    │
│  │  6. Returns temporary AWS credentials                        │    │
│  └──────┬──────────────────────────────────────────────────────┘    │
│         │                                                            │
│         ▼                                                            │
│  ┌─────────────────────────────┐                                    │
│  │  IAM Role Policy            │  Pod now has AWS permissions       │
│  │  (e.g., SecretsManager,    │  scoped to the specific role       │
│  │   S3, DynamoDB, SQS)       │                                    │
│  └─────────────────────────────┘                                    │
└──────────────────────────────────────────────────────────────────────┘
```

### OIDC Discovery Infrastructure

```
┌───────────────────────────────────────────────────────────────┐
│                  OIDC INFRASTRUCTURE                          │
│                                                               │
│  Talos SA Private Key                                         │
│       │                                                       │
│       ▼  jwks.sh script                                       │
│  ┌──────────────────────┐                                    │
│  │  JWKS Document        │  Contains:                        │
│  │  (keys.json)          │  - RSA modulus (base64url)        │
│  │                       │  - Exponent (AQAB)                │
│  │                       │  - Key type (RSA)                 │
│  │                       │  - Use (sig)                      │
│  └──────────┬────────────┘                                    │
│             │                                                  │
│             ▼  Uploaded to S3                                  │
│  ┌──────────────────────────────────────────────┐             │
│  │  S3 Bucket: dpl2-oidc-irsa                    │             │
│  │  (Block Public Access: enabled)               │             │
│  │                                               │             │
│  │  /.well-known/openid-configuration            │             │
│  │  /keys.json                                   │             │
│  └──────────────────┬───────────────────────────┘             │
│                     │ Origin Access Control (OAC)              │
│                     ▼                                          │
│  ┌──────────────────────────────────────────────┐             │
│  │  CloudFront: d2vt9kpivked44.cloudfront.net   │             │
│  │  (Public HTTPS endpoint)                      │             │
│  │  SigV4 signed requests to S3                  │             │
│  └──────────────────┬───────────────────────────┘             │
│                     │                                          │
│                     ▼                                          │
│  ┌──────────────────────────────────────────────┐             │
│  │  IAM OIDC Provider                            │             │
│  │  ARN: arn:aws:iam::786352483360:oidc-         │             │
│  │       provider/d2vt9kpivked44.cloudfront.net  │             │
│  │  Audience: sts.amazonaws.com                  │             │
│  └──────────────────────────────────────────────┘             │
└───────────────────────────────────────────────────────────────┘
```

### Pod Identity Webhook Configuration

- **Namespace**: `pod-identity-webhook`
- **Replicas**: 2 (HA)
- **Image**: `public.ecr.aws/eks/amazon-eks-pod-identity-webhook:latest`
- **TLS**: cert-manager issued certificate
- **Failure Policy**: `Ignore` (pods still create if webhook is down)
- **Annotation Prefix**: `eks.amazonaws.com` (same as EKS for compatibility)

---

## 10. Secrets Management - External Secrets Operator

### Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│              EXTERNAL SECRETS ARCHITECTURE                       │
│                                                                  │
│  ┌────────────────────────────────────────────────────────┐     │
│  │  ClusterSecretStore: "default"                         │     │
│  │  Provider: AWS Secrets Manager (us-east-1)             │     │
│  │  Auth: IRSA (external-secrets SA → dpl2-external-      │     │
│  │         secrets IAM role)                               │     │
│  └───────────────────────────┬────────────────────────────┘     │
│                              │                                   │
│         ┌────────────────────┼────────────────────┐              │
│         ▼                    ▼                    ▼              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐     │
│  │ ExternalSecret│  │ ExternalSecret│  │ ExternalSecret   │     │
│  │ azuread-secret│  │ kafka-creds  │  │ kafka-reg-creds  │     │
│  │ (per ns)      │  │ (per ns)     │  │ (per ns)         │     │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────────┘     │
│         │                  │                  │                  │
│         ▼                  ▼                  ▼                  │
│  ┌──────────────────────────────────────────────────────┐      │
│  │  AWS Secrets Manager (us-east-1, Playground Account) │      │
│  │                                                       │      │
│  │  dx--<namespace>-azuread-secret   (32 secrets)       │      │
│  │  dx--ccloud-kafka-master          (shared)            │      │
│  │  dx--ccloud-schema-registry-master (shared)           │      │
│  └──────────────────────────────────────────────────────┘      │
│                                                                  │
│  Total ExternalSecrets: 106                                      │
│  Refresh Interval: 1 hour                                        │
│  Status: All 106 SecretSynced                                    │
└──────────────────────────────────────────────────────────────────┘
```

### Secret Types per Namespace

Each application namespace typically receives 3 ExternalSecrets:

| Secret Name | AWS Secret Key | Purpose |
|-------------|---------------|---------|
| `<ns>-azuread-secret` | `dx--<ns>-azuread-secret` | Azure AD OAuth credentials |
| `<ns>-kafka-creds` | `dx--ccloud-kafka-master` | Confluent Cloud Kafka credentials |
| `<ns>-kafka-reg-creds` | `dx--ccloud-schema-registry-master` | Schema Registry credentials |

### Secret File Structure

```
infrastructure/app-secrets/
├── kustomization.yaml
├── test-app.yaml                    # Test app secrets
├── enterprise-secrets.yaml          # Enterprise namespace (custom)
├── trailers-secrets.yaml            # Trailers namespace (custom)
├── common-kafka-secrets.yaml        # Kafka secrets for initial namespaces
├── remaining-namespace-secrets.yaml # Kafka/AzureAD for remaining namespaces
└── new-namespace-secrets.yaml       # 13 new namespaces discovered from prod
```

---

## 11. Container Registry - ECR Credential Sync

### Dual-Region ECR Access

Production container images are stored across two AWS ECR regions:

| Region | Account | Images |
|--------|---------|--------|
| us-east-1 | 064859874041 | ~4 images (legacy) |
| us-east-2 | 064859874041 | ~97 images (primary) |

### CronJob Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│              ECR CREDENTIAL SYNC                                 │
│                                                                  │
│  ┌────────────────────────────────────────┐                     │
│  │  CronJob: ecr-credentials-sync         │                     │
│  │  Schedule: 0 */6 * * * (every 6 hours) │                     │
│  │  Namespace: ecr-credentials            │                     │
│  │  ServiceAccount: ecr-credentials-sync  │                     │
│  │  IRSA Role: dpl2-ecr-credentials-sync  │                     │
│  └────────────────────┬───────────────────┘                     │
│                       │                                          │
│                       ▼                                          │
│  ┌────────────────────────────────────────┐                     │
│  │  1. Fetch ECR tokens (via IRSA)        │                     │
│  │     aws ecr get-login-password         │                     │
│  │     --region us-east-1                 │                     │
│  │     --region us-east-2                 │                     │
│  └────────────────────┬───────────────────┘                     │
│                       │                                          │
│                       ▼                                          │
│  ┌────────────────────────────────────────┐                     │
│  │  2. Build dockerconfigjson             │                     │
│  │     {                                  │                     │
│  │       "auths": {                       │                     │
│  │         "064859874041.dkr.ecr.         │                     │
│  │          us-east-1.amazonaws.com":     │                     │
│  │          {"auth": "<base64>"},         │                     │
│  │         "064859874041.dkr.ecr.         │                     │
│  │          us-east-2.amazonaws.com":     │                     │
│  │          {"auth": "<base64>"}          │                     │
│  │       }                                │                     │
│  │     }                                  │                     │
│  └────────────────────┬───────────────────┘                     │
│                       │                                          │
│                       ▼                                          │
│  ┌────────────────────────────────────────┐                     │
│  │  3. Distribute to ALL namespaces       │                     │
│  │     (discovers dynamically via K8s API)│                     │
│  │     Creates/updates ecr-pull-secret    │                     │
│  │     in each namespace                  │                     │
│  │                                        │                     │
│  │     Excludes: kube-system, kube-public,│                     │
│  │     kube-node-lease, flux-system       │                     │
│  └────────────────────────────────────────┘                     │
│                                                                  │
│  Also: Init Job runs once on first deploy to seed credentials   │
│  ECR tokens valid for 12 hours; CronJob runs every 6 hours      │
└──────────────────────────────────────────────────────────────────┘
```

---

## 12. Terraform IRSA Roles Module

### Module Structure

```
terraform-irsa-roles/
├── main.tf                    # Root module - defines all 20 roles
├── variables.tf               # OIDC provider ARN/URL
├── outputs.tf                 # Map of role name → ARN
└── modules/
    └── irsa-role/
        ├── main.tf            # Trust policy + IAM role + inline policy
        ├── variables.tf       # Role name, namespace, SA, policy
        └── outputs.tf         # role_arn, role_name
```

### How the Module Works

```
┌──────────────────────────────────────────────────────────────────┐
│                 TERRAFORM IRSA MODULE                            │
│                                                                  │
│  Input:                                                          │
│  ┌──────────────────────────────────────────────┐               │
│  │  role_name:    "dpl2-trailers-api"            │               │
│  │  namespace:    "trailers"                     │               │
│  │  sa_name:      "trailers-api"                 │               │
│  │  oidc_arn:     arn:aws:iam::786352483360:     │               │
│  │                oidc-provider/d2vt9kpivked44.  │               │
│  │                cloudfront.net                  │               │
│  │  inline_policy: s3_read_write                 │               │
│  └──────────────────────┬───────────────────────┘               │
│                         │                                        │
│                         ▼                                        │
│  Creates:                                                        │
│  ┌──────────────────────────────────────────────┐               │
│  │  IAM Role: dpl2-trailers-api                  │               │
│  │                                               │               │
│  │  Trust Policy:                                │               │
│  │  {                                            │               │
│  │    "Effect": "Allow",                         │               │
│  │    "Principal": {                             │               │
│  │      "Federated": "<oidc_provider_arn>"       │               │
│  │    },                                         │               │
│  │    "Action": "sts:AssumeRoleWithWebIdentity", │               │
│  │    "Condition": {                             │               │
│  │      "StringEquals": {                        │               │
│  │        "<oidc_url>:aud": "sts.amazonaws.com", │               │
│  │        "<oidc_url>:sub": "system:service      │               │
│  │          account:trailers:trailers-api"        │               │
│  │      }                                        │               │
│  │    }                                          │               │
│  │  }                                            │               │
│  │                                               │               │
│  │  Inline Policy: dpl2-trailers-api-policy      │               │
│  │  (S3 GetObject, PutObject, ListBucket,        │               │
│  │   DeleteObject on Resource: *)                │               │
│  │                                               │               │
│  │  Tags:                                        │               │
│  │    kubernetes-namespace: trailers              │               │
│  │    kubernetes-service-account: trailers-api    │               │
│  │    cluster: dpl2                               │               │
│  └──────────────────────────────────────────────┘               │
└──────────────────────────────────────────────────────────────────┘
```

### All 20 IRSA Roles

| # | Role Name | Namespace | Service Account | AWS Access | ARN |
|---|-----------|-----------|----------------|------------|-----|
| 1 | dpl2-ecr-credentials-sync | ecr-credentials | ecr-credentials-sync | ECR Read | arn:aws:iam::786352483360:role/dpl2-ecr-credentials-sync |
| 2 | dpl2-external-secrets | external-secrets | external-secrets | Secrets Manager | arn:aws:iam::786352483360:role/dpl2-external-secrets |
| 3 | dpl2-driver-insights-cron | enterprise | driver-insights-cron | S3 R/W | arn:aws:iam::786352483360:role/dpl2-driver-insights-cron |
| 4 | dpl2-ocs-cisive-handler | enterprise | ocs-cisive-handler | S3 R/W | arn:aws:iam::786352483360:role/dpl2-ocs-cisive-handler |
| 5 | dpl2-safetylytx-video-handler | enterprise | safetylytx-video-handler | S3 R/W | arn:aws:iam::786352483360:role/dpl2-safetylytx-video-handler |
| 6 | dpl2-trailers-api | trailers | trailers-api | S3 R/W | arn:aws:iam::786352483360:role/dpl2-trailers-api |
| 7 | dpl2-domte | trailers | domte | S3 R/W | arn:aws:iam::786352483360:role/dpl2-domte |
| 8 | dpl2-ttelh | trailers | ttelh | S3 R/W | arn:aws:iam::786352483360:role/dpl2-ttelh |
| 9 | dpl2-uteh | trailers | uteh | S3 R/W | arn:aws:iam::786352483360:role/dpl2-uteh |
| 10 | dpl2-driver-message-handler | trailers | driver-message-handler | SQS/SNS | arn:aws:iam::786352483360:role/dpl2-driver-message-handler |
| 11 | dpl2-geofence-api | geoservices | geofence-api | DynamoDB | arn:aws:iam::786352483360:role/dpl2-geofence-api |
| 12 | dpl2-data-address-api | geoservices | data-address-api | DynamoDB | arn:aws:iam::786352483360:role/dpl2-data-address-api |
| 13 | dpl2-geofence-data-provider | geoservices | geofence-data-provider | S3 R/W | arn:aws:iam::786352483360:role/dpl2-geofence-data-provider |
| 14 | dpl2-task-data-api | tasks | task-data-api | DynamoDB | arn:aws:iam::786352483360:role/dpl2-task-data-api |
| 15 | dpl2-mcleod-location-sync-handler | mcleod-data-sync | mcleod-location-sync-handler | SQS/SNS | arn:aws:iam::786352483360:role/dpl2-mcleod-location-sync-handler |
| 16 | dpl2-event-message-bridge-api | messagebridge | event-message-bridge-api | SQS/SNS | arn:aws:iam::786352483360:role/dpl2-event-message-bridge-api |
| 17 | dpl2-safetylytx-video-api | safety | safetylytx-video-api | S3 R/W | arn:aws:iam::786352483360:role/dpl2-safetylytx-video-api |
| 18 | dpl2-pricing-rfp-api | knx-synergy | pricing-rfp-api | S3 R/W | arn:aws:iam::786352483360:role/dpl2-pricing-rfp-api |
| 19 | dpl2-capacity-snapshots-cron | freight | capacity-snapshots-cron | S3 R/W | arn:aws:iam::786352483360:role/dpl2-capacity-snapshots-cron |
| 20 | dpl2-kafka-connect | kafka | connect-connect | S3 R/W | arn:aws:iam::786352483360:role/dpl2-kafka-connect |

### Terraform State

- **Backend**: Local (S3 backend commented out, ready to enable)
- **S3 Key**: `iaac/irsa-roles/dpl2.tfstate`
- **Resources**: 60 total (20 roles + 20 inline policies + 20 trust policy data sources)
- **Provider**: AWS ~> 5.0, region us-east-1

---

## 13. Application Namespaces & Workloads

### Namespace Overview

48 namespaces are configured across the cluster, each enrolled in Istio ambient mesh:

```
┌──────────────────────────────────────────────────────────────────┐
│                    48 APPLICATION NAMESPACES                      │
│                    (all with istio ambient label)                 │
│                                                                  │
│  Platform:          Application (Original 24):                    │
│  ├── flux-system    ├── test-app        ├── orders              │
│  ├── cert-manager   ├── enterprise      ├── pricing             │
│  ├── istio-system   ├── trailers        ├── truck               │
│  ├── ecr-credentials├── geoservices     ├── driver              │
│  ├── external-secrets├── tasks          ├── freight             │
│  ├── pod-identity-  ├── mcleod-data-sync├── messaging          │
│  │   webhook        ├── messagebridge   ├── usxpress-io         │
│  └── kube-system    ├── kafka           ├── vehicle             │
│                     ├── safety          ├── fade                │
│                     ├── utility         ├── halo                │
│                     ├── customers       ├── knx-synergy         │
│                     └── mulesoft        └── analytics           │
│                                                                  │
│  New (13 from production discovery):                             │
│  ├── attrition       ├── io-curt        ├── recruiting          │
│  ├── customer-profile├── lumper         ├── tender              │
│  ├── data-feeds      ├── maintenance    ├── xpress-os           │
│  ├── freight-alloc.  ├── missions       └── xra                 │
│  └── ocs                                                         │
└──────────────────────────────────────────────────────────────────┘
```

### Application Deployment Pattern

Each application deployment follows a consistent pattern:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: <app-name>
  namespace: <namespace>
spec:
  replicas: 1
  template:
    spec:
      serviceAccountName: <app-name>       # For IRSA (if applicable)
      imagePullSecrets:
        - name: ecr-pull-secret            # From ECR credential sync
      containers:
        - name: <app-name>
          image: 064859874041.dkr.ecr.us-east-2.amazonaws.com/<ns>/<app>:<version>
          env:
            - name: APP_ENV
              value: dpl2
          resources:
            requests:
              cpu: 50m
              memory: 64Mi
            limits:
              cpu: 200m
              memory: 256Mi
---
apiVersion: v1
kind: Service
metadata:
  name: <app-name>
  namespace: <namespace>
spec:
  selector:
    app: <app-name>
  ports:
    - port: 80
      targetPort: <app-port>
```

### App Deployment Files (33 files)

```
infrastructure/app-deployments/
├── kustomization.yaml
├── test-app.yaml          # Validation app
├── attrition.yaml         ├── maintenance.yaml
├── customer-profile.yaml  ├── mcleod-data-sync.yaml
├── customers.yaml         ├── messagebridge.yaml
├── data-feeds.yaml        ├── messaging.yaml
├── driver.yaml            ├── missions.yaml
├── enterprise.yaml        ├── ocs.yaml
├── fade.yaml              ├── orders.yaml
├── freight.yaml           ├── pricing.yaml
├── freight-allocation.yaml├── recruiting.yaml
├── geoservices.yaml       ├── safety.yaml
├── halo.yaml              ├── tasks.yaml
├── io-curt.yaml           ├── tender.yaml
├── knx-synergy.yaml       ├── trailers.yaml
├── lumper.yaml            ├── truck.yaml
                           ├── utility.yaml
                           ├── vehicle.yaml
                           ├── xpress-os.yaml
                           └── xra.yaml
```

---

## 14. MageRunner & Octopus Deploy Pipeline

### Production Deployment Pipeline

In production (EKS), applications are NOT deployed as raw Kubernetes manifests. Instead, a sophisticated CI/CD pipeline orchestrates deployments:

```
┌──────────────────────────────────────────────────────────────────────┐
│              PRODUCTION DEPLOYMENT PIPELINE                          │
│                                                                      │
│  ┌──────────────┐                                                   │
│  │  GitHub Push  │  Developer pushes code                           │
│  └──────┬───────┘                                                   │
│         │                                                            │
│         ▼                                                            │
│  ┌──────────────────────────────────┐                               │
│  │  GitHub Actions                   │                               │
│  │  (.github/workflows/octo.yaml)   │                               │
│  │  1. Run tflint                    │                               │
│  │  2. Package code                  │                               │
│  │  3. Trigger Octopus release       │                               │
│  └──────────────┬───────────────────┘                               │
│                 │                                                     │
│                 ▼                                                     │
│  ┌──────────────────────────────────┐                               │
│  │  Octopus Deploy                   │                               │
│  │                                   │                               │
│  │  Channels:                        │                               │
│  │  ├── Feature (branch) → Dev → DPL │                               │
│  │  └── Release (master) → Dev →     │                               │
│  │      QA → Staging → Prod          │                               │
│  │                                   │                               │
│  │  Creates release with packages:   │                               │
│  │  ├── project (app code)           │                               │
│  │  ├── terraform (IaC)              │                               │
│  │  ├── mage (orchestrator)          │                               │
│  │  └── schemas (config)             │                               │
│  └──────────────┬───────────────────┘                               │
│                 │                                                     │
│                 ▼                                                     │
│  ┌──────────────────────────────────────────────────────────┐       │
│  │  MageRunner (Go binary on Octopus Worker)                 │       │
│  │                                                           │       │
│  │  Phase 1: Parse spec.yaml                                 │       │
│  │  ┌─────────────────────────────────────┐                 │       │
│  │  │  spec.yaml defines:                 │                 │       │
│  │  │  - name, namespace, image           │                 │       │
│  │  │  - module type (api/cron/handler/ui)│                 │       │
│  │  │  - infrastructure (S3, DDB, etc.)   │                 │       │
│  │  │  - secrets, env vars                │                 │       │
│  │  └─────────────────────────────────────┘                 │       │
│  │                                                           │       │
│  │  Phase 2: Deploy Infrastructure (parallel)                │       │
│  │  ┌──────┐ ┌──────┐ ┌────────┐ ┌───────┐ ┌─────┐        │       │
│  │  │Namespace│ │Role  │ │Buckets │ │Kafka  │ │Auth │       │       │
│  │  │(kubectl)│ │(IRSA)│ │(S3)    │ │(topics)│ │(AD) │       │       │
│  │  └──────┘ └──────┘ └────────┘ └───────┘ └─────┘        │       │
│  │                                                           │       │
│  │  Phase 3: Deploy Application                              │       │
│  │  ┌─────────────────────────────────────┐                 │       │
│  │  │  Terraform + Helm Chart              │                 │       │
│  │  │  - Chart: api/cron/handler/ui module │                 │       │
│  │  │  - Values: image, role_arn, secrets  │                 │       │
│  │  │  - Backend: S3 state per app         │                 │       │
│  │  └─────────────────────────────────────┘                 │       │
│  │                                                           │       │
│  │  Phase 4: Post-deploy (health checks, artifacts)          │       │
│  └──────────────────────────────────────────────────────────┘       │
└──────────────────────────────────────────────────────────────────────┘
```

### DXSpec Structure

Each application defines its deployment specification:

```yaml
name: "app-name"
octopus:
  space: "DevOps"
  group: "namespace-name"    # Maps to Kubernetes namespace
  preStep: "echo testing"
  postStep: ""
git:
  repository: "repo-name"
  user: "user-name"
  version: "1.0.1-abc1234"
  image: "064859874041.dkr.ecr.us-east-2.amazonaws.com/ns/app:tag"
  language: "python"
tags:
  owner: "team-name"
  team: "cloudops"
infrastructure:              # Optional - creates AWS resources
  buckets: { ... }
  dynamodb: { ... }
  kafka: { ... }
api:                         # One of: api, cron, handler, ui
  service:
    targetPort: 5000
  secretVars: { ... }
```

### Adapting MageRunner for DPL2

To deploy apps to dpl2 through the production pipeline, the following configuration is needed:

1. **Separate Octopus Space for On-Prem**: Instead of adding dpl2 as another environment in the existing EKS Space, create a dedicated Octopus Space for on-prem Talos deployments. This provides:
   - **Clean separation** — on-prem clusters have fundamentally different variables (vSphere creds, Talos API endpoints, physical node IPs) vs cloud EKS
   - **Independent lifecycle** — different providers, state keys, and deploy scripts than EKS
   - **No variable conflicts** — eliminates the need to scope every variable to avoid collisions with existing EKS environments
   - **Team isolation** — platform team manages on-prem Space, cloud team manages EKS Space
   - **Independent lifecycles and channels** — on-prem promotion path (DPL → DPL2 → Prod-OnPrem) separate from cloud (Dev → QA → Staging → Prod)
2. **Octopus Lifecycle (On-Prem Space)**: DPL → DPL2 → Production (on-prem), with manual promotion gates
3. **Worker Configuration**: Point to worker with dpl2 kubeconfig access (or deploy a dedicated Octopus worker on-prem with direct cluster connectivity)
4. **Variables (DPL2-scoped in On-Prem Space)**:
   - `KUBECONFIG` → path to dpl2 cluster kubeconfig
   - `AWS_PROFILE` → playground account credentials
   - `OIDC_PROVIDER_ARN` → dpl2 CloudFront OIDC provider
   - `TF_STATE_KEY` prefix → separate from production state
   - `S3_BUCKET` → `lazy-tf-state-0k3nc997arlf7k1a` (shared state bucket, different keys)
5. **MageRunner Changes**: Namespace labels (`istio-injection: disabled`, `istio.io/dataplane-mode: ambient`) and ServiceAccount patching (`imagePullSecrets: ecr-pull-secret`) already handled in code and Flux manifests

---

## 15. Deployment Sequence & Timeline

### Implementation Timeline

```
┌──────────────────────────────────────────────────────────────────────┐
│                    DEPLOYMENT SEQUENCE                                │
│                                                                      │
│  PHASE 1: INFRASTRUCTURE (Terraform - iaac-talos)                   │
│  ═══════════════════════════════════════════════                     │
│  ✅ Provision 5 VMs on vSphere (3 CP + 2 Worker)                    │
│  ✅ Install Talos Linux via OVA clone                                │
│  ✅ Bootstrap Kubernetes v1.32.0 cluster                             │
│  ✅ Install Cilium CNI (inline manifest)                             │
│  ✅ Configure VIP (10.10.82.30) for HA                              │
│  ✅ Generate IRSA OIDC documents (JWKS)                             │
│  ✅ Upload OIDC to S3 + CloudFront                                   │
│  ✅ Create IAM OIDC Provider in AWS                                  │
│  ✅ Bootstrap Flux CD                                                │
│                                                                      │
│  PHASE 2: PLATFORM SERVICES (Flux GitOps)                           │
│  ═══════════════════════════════════════                             │
│  ✅ Deploy cert-manager (v1.19.1)                                    │
│  ✅ Create self-signed root CA for Istio                             │
│  ✅ Deploy Istio CSR bridge                                          │
│  ✅ Deploy Istio Ambient Mesh (base + istiod + cni + ztunnel)       │
│  ✅ Deploy Pod Identity Webhook (2 replicas)                        │
│  ✅ Deploy External Secrets Operator (v0.12.x)                      │
│  ✅ Configure ClusterSecretStore (AWS Secrets Manager)               │
│  ✅ Deploy ECR Credential Sync (dual-region CronJob)                │
│  ✅ Configure Cilium L2 LoadBalancer IP Pool                        │
│  ✅ Deploy Gateway API CRDs (v1.2.1)                                │
│                                                                      │
│  PHASE 3: APPLICATION INFRASTRUCTURE                                 │
│  ═══════════════════════════════════                                 │
│  ✅ Create 48 application namespaces (Flux)                          │
│  ✅ Create ServiceAccounts with IRSA annotations (Flux)              │
│  ✅ Deploy 106 ExternalSecrets (Flux)                                │
│  ✅ Create 32 AWS Secrets Manager entries (placeholder AzureAD)      │
│  ✅ Sync all 106 ExternalSecrets to SecretSynced                     │
│  ✅ Create 20 IRSA IAM roles via Terraform                          │
│  ✅ Distribute ecr-pull-secret to all namespaces                     │
│                                                                      │
│  PHASE 4: APPLICATION DEPLOYMENT (Next)                              │
│  ════════════════════════════════════                                │
│  ⬜ Create separate Octopus Space for on-prem deployments           │
│  ⬜ Configure on-prem lifecycle (DPL → DPL2 → Prod-OnPrem)         │
│  ⬜ Set up Octopus worker with dpl2 kubeconfig access               │
│  ⬜ Configure MageRunner with DPL2 kubeconfig + OIDC                │
│  ⬜ Test single app deployment through pipeline                      │
│  ⬜ Deploy all ~156 applications via MageRunner                      │
│  ⬜ Populate real AzureAD secrets                                    │
│  ⬜ Validate end-to-end application connectivity                     │
└──────────────────────────────────────────────────────────────────────┘
```

---

## 16. Issues Encountered & Resolutions

### Issue 1: Job Immutability Error

```
Error: Job.batch "ecr-credentials-sync-init" is invalid:
       spec.template: field is immutable
```

**Cause**: The init Job already existed with the old (single-region us-east-1) script. Kubernetes does not allow modifying Job templates after creation.

**Resolution**: Deleted the existing Job and reconciled:
```bash
kubectl delete job ecr-credentials-sync-init -n ecr-credentials
flux reconcile kustomization ecr-credentials
```

### Issue 2: Missing File in Kustomization

```
Error: remaining-namespace-secrets.yaml: no such file or directory
```

**Cause**: File was referenced in `kustomization.yaml` but never committed/pushed to the Git repository (was untracked locally).

**Resolution**: Committed and pushed the missing file:
```bash
git add infrastructure/app-secrets/remaining-namespace-secrets.yaml
git commit && git push
```

### Issue 3: ExternalSecrets AzureAD SecretSyncedError

**Cause**: 32 AWS Secrets Manager entries for `dx--<namespace>-azuread-secret` did not exist in the Playground account.

**Resolution**: Created all 32 placeholder secrets:
```bash
for ns in enterprise trailers geoservices tasks ...; do
  aws secretsmanager create-secret \
    --name "dx--${ns}-azuread-secret" \
    --secret-string '{"client_id":"placeholder","client_secret":"placeholder","tenant_id":"placeholder"}' \
    --region us-east-1 --profile playground
done
```
Then force-synced all ExternalSecrets with annotation:
```bash
kubectl annotate externalsecret --all force-sync=$(date +%s) --overwrite -A
```

### Issue 4: Git Push SSL Certificate Error

```
Error: server certificate verification failed. CAfile: none CRLfile: none
```

**Cause**: Corporate proxy intercepting HTTPS traffic with a self-signed certificate.

**Resolution**: Disabled SSL verification for Git:
```bash
git config http.sslVerify false
```

### Issue 5: Terraform TLS Error in WSL

```
Error: x509: certificate signed by unknown authority
```

**Cause**: Same corporate proxy issue affecting Terraform provider downloads.

**Resolution**: Ran Terraform from GitHub Codespace instead of WSL where TLS works without proxy interference.

### Issue 6: Terraform IRSA Roles - EntityAlreadyExists

```
Error: creating IAM Role (dpl2-external-secrets): EntityAlreadyExists
```

**Cause**: Two platform roles (`dpl2-external-secrets`, `dpl2-ecr-credentials-sync`) were created manually before the Terraform module was written.

**Resolution**: Imported existing roles into Terraform state:
```bash
terraform import 'module.irsa_role["dpl2-external-secrets"].aws_iam_role.this' dpl2-external-secrets
terraform import 'module.irsa_role["dpl2-ecr-credentials-sync"].aws_iam_role.this' dpl2-ecr-credentials-sync
terraform apply  # Successfully: 20 added, 2 changed
```

### Issue 7: Pod Identity Webhook TLS Handshake Failure

```
Error: Internal error occurred: failed calling webhook "pod-identity-webhook.amazonaws.com":
       x509: certificate signed by unknown authority
```

**Cause**: The Pod Identity Webhook was configured with `--in-cluster=true`, which attempts to use the Kubernetes CSR API for certificate management. Talos Linux does not have the Kubernetes CSR API (no `kube-controller-manager` certificate signer). The webhook was trying to generate its own certificates via CSR but failing silently, then serving without valid TLS.

**Resolution**: Changed PIW to use cert-manager-issued certificates:
- Set `--in-cluster=false` (disables K8s CSR-based cert management)
- Added `--tls-cert=/etc/webhook/certs/tls.crt` and `--tls-key=/etc/webhook/certs/tls.key`
- Mounted cert-manager `Certificate` resource secret (`pod-identity-webhook-cert`) as a volume
- Added `cert-manager.io/inject-ca-from` annotation to `MutatingWebhookConfiguration` for CA injection

**IaC Fix**: Changes committed to `infrastructure/pod-identity-webhook/deployment.yaml` and `certificate.yaml` — no manual intervention needed on redeploy.

### Issue 8: ECR CronJob runAsNonRoot Failure

```
Error: container has runAsNonRoot and image will run as root
Error: Permission denied: '/.aws'
```

**Cause**: The `public.ecr.aws/aws-cli/aws-cli:latest` image runs as root by default. PodSecurity `restricted:latest` enforcement requires `runAsNonRoot: true`. Additionally, the AWS CLI writes config to `$HOME/.aws/`, and running as uid 1000 cannot write to `/root/.aws/`.

**Resolution**: Added full restricted-compliant securityContext:
- Pod: `runAsNonRoot: true`, `runAsUser: 1000`, `seccompProfile: RuntimeDefault`
- Container: `allowPrivilegeEscalation: false`, `capabilities.drop: ["ALL"]`
- Environment: `HOME=/tmp` (writable directory for non-root user)

**IaC Fix**: Applied to both CronJob and init Job in `infrastructure/ecr-credentials/cronjob.yaml` — no manual intervention needed on redeploy.

### Issue 9: KEDA HelmRelease CRD Race Condition

```
Error: Helm install failed for release keda/keda with chart keda@2.19.0:
       customresourcedefinitions.apiextensions.k8s.io "scaledobjects.keda.sh" not found
```

**Cause**: The KEDA Helm chart installs CRDs as part of the Helm release, but the CRD creation and the deployment referencing them raced. With no install remediation retries configured, Helm gave up after 1 failed attempt and the HelmRelease entered a permanent `Stalled` state.

**Resolution (manual)**: Suspended and resumed the HelmRelease to force retry:
```bash
flux suspend helmrelease keda -n keda
flux resume helmrelease keda -n keda
flux reconcile kustomization keda -n flux-system --with-source
```

**IaC Fix**: Added to `infrastructure/keda/helmrelease.yaml`:
- `install.remediation.retries: 5` — auto-retry up to 5 times on install failure
- `upgrade.remediation.retries: 3` — auto-retry up to 3 times on upgrade failure
- `install.crds: CreateReplace` and `upgrade.crds: CreateReplace` — ensure CRDs are created/replaced
- `timeout: 10m` — extended from default 5m

### Issue 10: ECR Init Job Ran Before App Namespaces Created

**Cause**: The Flux dependency chain had `ecr-credentials` running BEFORE `app-namespaces`. The init Job would sync ECR pull secrets to all existing namespaces, but the 37 app namespaces didn't exist yet. When `app-deployments` started, pods failed with `ImagePullBackOff` because `ecr-pull-secret` was missing from their namespace.

**Resolution (manual)**: Deleted and recreated the init Job after namespaces were created:
```bash
kubectl delete job ecr-credentials-sync-init -n ecr-credentials
flux reconcile kustomization ecr-credentials -n flux-system
# Then deleted all ImagePullBackOff pods to trigger recreation
kubectl get pods -A --no-headers | grep -E 'ImagePull|ErrImagePull' | awk '{print "kubectl delete pod " $2 " -n " $1}' | sh
```

**IaC Fix**: Reordered the Flux dependency chain in `clusters/dpl2/flux-system/infra.yaml`:
- **Before**: `pod-identity-webhook` → `ecr-credentials` → `app-namespaces` → `app-deployments`
- **After**: `pod-identity-webhook` → `app-namespaces` → `ecr-credentials` → `app-deployments`
- `app-namespaces` now depends on `external-secrets` + `pod-identity-webhook` (not ecr-credentials)
- `ecr-credentials` now depends on `pod-identity-webhook` + `app-namespaces` (ensures namespaces exist first)
- `app-deployments` now depends on `app-namespaces` + `app-secrets` + `ecr-credentials` + `keda`
- Added `ttlSecondsAfterFinished: 86400` to init Job (auto-cleanup after 24h, Flux recreates on next reconciliation)

### Issue 11: Terraform Destroyed Existing Nodes (Naming Mismatch)

**Cause**: `terraform.tfvars` had `dare` naming convention (from the template) but the actual VMs were named `dpl2`. Also, `template_uuid` changes in vSphere forced VM replacement.

**Resolution**:
- Updated all naming in `terraform.tfvars` to match actual `dpl2-cluster` convention
- Fixed VIP from `10.10.82.20` to `10.10.82.30`
- Added `clone` to `lifecycle.ignore_changes` in vSphere VM module to prevent template_uuid-triggered replacements
- Updated `worker_count` from 2 to 5, `worker_memory_mb` from 4096 to 8192, `disk_size_gb` from 20 to 50

### Issue 12: Terraform Flux Bootstrap Removed Infra References

**Cause**: When Terraform re-applied the Flux bootstrap module, it pushed a commit to `iaac-talos-flux-cluster` that overwrote `clusters/dpl2/flux-system/kustomization.yaml`, removing the `infra-source.yaml` and `infra.yaml` resource references.

**Resolution**: Manually restored the lines in `kustomization.yaml` and pushed:
```yaml
resources:
  - gotk-components.yaml
  - gotk-sync.yaml
  - infra-source.yaml   # Restored
  - infra.yaml           # Restored
```

**Prevention**: After initial Flux bootstrap, avoid re-running the Terraform Flux module unless intentional. The cluster repo should be managed via Git, not Terraform, after bootstrap.

---

## 17. Current State & Next Steps

### Current State (March 11, 2026)

| Component | Status | Details |
|-----------|--------|---------|
| VMs | Running | 8 nodes on vSphere D1 (3 CP + 5 worker, 8GB RAM / 50GB disk per worker) |
| Talos Cluster | Healthy | K8s v1.32.0, VIP 10.10.82.30, all 8 nodes Ready |
| Flux CD | Operational | 20/20 Kustomizations Ready |
| Istio Ambient | Running | istiod + ztunnel + CNI on all nodes |
| cert-manager | Running | v1.19.1, self-signed root CA |
| Pod Identity Webhook | Running | 1 replica, cert-manager TLS (--in-cluster=false) |
| External Secrets | Synced | 139/139 SecretSynced |
| ECR Credentials | Active | Dual-region, non-root (uid 1000), HOME=/tmp |
| IRSA Roles | Created | 20/20 via Terraform in Playground |
| KEDA | Running | v2.19.0, install remediation retries enabled |
| Namespaces | Created | 37 with ambient mesh labels |
| App Deployments | Deployed | 99 deployments, 80 Running / ~73 CrashLoopBackOff (missing real secrets) |
| Application Deployments | Deployed | 99 deployments across 37 namespaces via Flux, 80 Running / 73 CrashLoop (config) |
| Worker Node Specs | Upgraded | 8GB RAM, 50GB disk per worker (upgraded from 4GB/20GB) |

### Remaining Work

1. **Populate Real Secrets in AWS Secrets Manager**
   - Replace placeholder AzureAD secrets (`dx--<ns>-azuread-secret`) with real `CLIENT_ID`, `CLIENT_SECRET`, `TENANT_ID`
   - Populate MongoDB connection strings for apps that require them
   - Populate any app-specific config secrets (API keys, endpoints, etc.)
   - ExternalSecrets will auto-refresh within 1h (or force-sync with annotation)

2. **Fix App-Specific Environment Variables**
   - Several apps expect `APPLICATION:ENVIRONMENT` env var (e.g., brands-api, .NET apps)
   - Review each CrashLoopBackOff app's logs for missing config
   - Update deployment manifests with required env vars or envFrom secret references

3. **Configure Monitoring & Alerting**
   - Deploy Prometheus/Grafana stack
   - Set up alerting for pod failures, node pressure, certificate expiry

4. **Configure Octopus Deploy / MageRunner for DPL2**
   - Create DPL2 environment and lifecycle in Octopus
   - Point MageRunner to dpl2 kubeconfig
   - Set OIDC provider to CloudFront URL

5. **Production Readiness**
   - End-to-end validation of all 99 apps
   - Load testing on 5-worker cluster
   - Backup & DR (Velero) configuration

---

## 18. Appendix

### A. AWS Accounts

| Account | ID | Purpose |
|---------|-----|---------|
| Infrastructure-Playground | 786352483360 | IRSA roles, Secrets Manager, OIDC |
| Infrastructure-Common | 064859874041 | ECR container images |

### B. Key URLs and Endpoints

| Resource | URL/Endpoint |
|----------|-------------|
| Kubernetes API | https://10.10.82.30:6443 |
| OIDC Issuer | https://d2vt9kpivked44.cloudfront.net |
| OIDC Discovery | https://d2vt9kpivked44.cloudfront.net/.well-known/openid-configuration |
| JWKS | https://d2vt9kpivked44.cloudfront.net/keys.json |
| ECR us-east-1 | 064859874041.dkr.ecr.us-east-1.amazonaws.com |
| ECR us-east-2 | 064859874041.dkr.ecr.us-east-2.amazonaws.com |
| GitHub Org | github.com/variant-inc |

### C. Git Repositories

| Repository | Branch | Purpose |
|------------|--------|---------|
| iaac-talos | per-cluster | Terraform: VM provisioning + cluster bootstrap |
| iaac-talos-flux-cluster | master | Flux wiring: per-cluster Kustomization definitions |
| iaac-talos-flux-platform | dpl2 | Platform manifests: infrastructure + apps |
| terraform-irsa-roles | main | Terraform: 20 IRSA IAM roles |
| mage-runner | main | Go: CI/CD orchestration engine |

### D. Node IP Addresses

| Node | IP | Role | Specs |
|------|-----|------|-------|
| talos-cp-dpl2-1 | 10.10.82.22 | Control Plane | 2 vCPU, 4GB RAM, 20GB disk |
| talos-cp-dpl2-2 | 10.10.82.21 | Control Plane | 2 vCPU, 4GB RAM, 20GB disk |
| talos-cp-dpl2-3 | 10.10.82.23 | Control Plane | 2 vCPU, 4GB RAM, 20GB disk |
| talos-wk-dpl2-1 | 10.10.82.139 | Worker | 2 vCPU, 8GB RAM, 50GB disk |
| talos-wk-dpl2-2 | 10.10.82.138 | Worker | 2 vCPU, 8GB RAM, 50GB disk |
| talos-wk-dpl2-3 | 10.10.82.174 | Worker | 2 vCPU, 8GB RAM, 50GB disk |
| talos-wk-dpl2-4 | 10.10.82.175 | Worker | 2 vCPU, 8GB RAM, 50GB disk |
| talos-wk-dpl2-5 | 10.10.82.176 | Worker | 2 vCPU, 8GB RAM, 50GB disk |
| VIP | 10.10.82.30 | API Endpoint | — |

### E. Design Decisions

| Decision | Chosen | Alternative | Rationale |
|----------|--------|-------------|-----------|
| OS | Talos Linux | Ubuntu/RHEL | Immutable, minimal attack surface, K8s-native |
| CNI | Cilium | Flannel/Calico | eBPF, matches EKS, enterprise features |
| Mesh | Istio Ambient | Istio Sidecar/Linkerd | Lower overhead on fixed bare-metal |
| LB | Cilium L2 | MetalLB/BGP | No BGP infra needed, simpler |
| Routing | Native | VXLAN overlay | Better datacenter performance |
| IRSA | CloudFront OIDC | IAM Roles Anywhere | Same pattern as EKS, proven |
| State | AWS S3 | Local/Consul | Durable, versioned, shared |
| GitOps | Flux CD | ArgoCD | Already integrated, separates concerns |
| Secrets | External Secrets | Vault/CSI | Matches EKS pattern, simpler |

### F. Contacts

| Person | Role | Domain |
|--------|------|--------|
| Omar | Platform Engineer (departing) | Terraform, Octopus, implementation |
| Vivian | Cloud Platform Architect | Architecture, priorities |
| Jeremy Keys | Network Engineer | IP ranges, VLAN, networking |
| Jon Griffin | vSphere Admin | VM folder permissions |
| Parul/Rohit | DX Engineers | Application deployment, Helm charts |
