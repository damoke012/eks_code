# DPL2 Full App Deployment — Runbook & CI/CD Reference

**Date**: March 11, 2026 (updated after initial deployment)
**Status**: 99 apps deployed, 80 Running, ~73 CrashLoopBackOff (missing real secrets)
**Predecessor**: MageRunner v17 successful end-to-end deployment

---

## Current State (March 11, 2026)

| Metric | Value |
|--------|-------|
| Cluster Nodes | 8 (3 CP + 5 workers, 8GB RAM / 50GB disk per worker) |
| Total Pods | 157 (including infrastructure) |
| App Pods Running | 80 |
| App Pods CrashLoopBackOff | ~73 (missing real secrets/config) |
| ImagePull Failures | ~0 (ECR pull secrets synced) |
| Flux Kustomizations | 20/20 Ready |
| ExternalSecrets | 139/139 SecretSynced |
| IRSA Roles | 20/20 via Terraform |

---

## Fully Automated CI/CD — Zero CLI Commands Required

After the fixes documented here, a complete teardown and recreate requires **only Git pushes**. No `kubectl`, `flux`, or manual intervention.

### Flux Kustomization Dependency Chain (Correct Order)

```
                    cert-manager (no deps)
                         │
          ┌──────────────┼──────────────────────┐
          ▼              ▼                       ▼
   cert-manager-    pod-identity-              keda
   issuers          webhook                     │
     │                │        │                │
     ▼                │        ▼                │
   istio-csr          │   external-secrets      │
     │                │        │                │
     ▼                │        ▼                │
   istio-base         │   external-secrets-     │
     │                │   config                │
     ▼                │        │                │
   istiod             │        │                │
     │                │        │                │
   ┌─┼─┐             │        │                │
   ▼   ▼             ▼        ▼                │
istio  ztunnel   app-namespaces                │
-cni             (depends: external-secrets,    │
                  pod-identity-webhook)         │
                      │                         │
                ┌─────┼─────────┐               │
                ▼               ▼               │
          ecr-credentials   app-secrets         │
          (depends: PIW,    (depends:           │
           app-namespaces)   app-namespaces,    │
                │            eso-config)        │
                │               │               │
                └───────┬───────┘───────────────┘
                        ▼
                  app-deployments
                  (depends: app-namespaces,
                   app-secrets, ecr-credentials, keda)
```

### Key Design: ECR Credentials Run AFTER App Namespaces

The dependency chain ensures that:
1. `app-namespaces` creates all 37 namespaces first
2. `ecr-credentials` init Job then syncs `ecr-pull-secret` to ALL namespaces
3. `app-deployments` starts only after ECR secrets are in place

This eliminates the manual `kubectl delete job` + `kubectl delete pods` workaround that was needed in the initial deployment.

### KEDA HelmRelease Self-Heals

The KEDA HelmRelease has `install.remediation.retries: 5` — if CRD race conditions cause a first-attempt failure, Flux automatically retries up to 5 times. No manual `flux suspend/resume` needed.

---

## Fresh Cluster Deployment Procedure (Fully Automated)

### Prerequisites (One-Time AWS Setup)

```bash
export AWS_PROFILE=playground

# 1. Terraform IRSA roles (20 roles)
cd terraform-irsa-roles && terraform apply -auto-approve

# 2. AWS Secrets Manager entries (already created, but verify)
for ns in enterprise trailers geoservices tasks orders pricing truck driver \
  freight mcleod-data-sync messagebridge safety utility messaging vehicle \
  fade halo customers knx-synergy attrition customer-profile data-feeds \
  freight-allocation io-curt lumper maintenance missions ocs recruiting \
  tender xpress-os xra; do
  aws secretsmanager describe-secret --secret-id "dx--${ns}-azuread-secret" \
    --query 'Name' --output text 2>/dev/null || echo "MISSING: dx--${ns}-azuread-secret"
done
```

### Step 1: Bootstrap Cluster (Terraform — iaac-talos repo)

Run from WSL2:
```bash
cd ~/iaac-talos/deploy/terraform
terraform apply
```

This provisions VMs, installs Talos, bootstraps Kubernetes, and initializes Flux.

**IMPORTANT**: After Terraform Flux bootstrap, verify `clusters/dpl2/flux-system/kustomization.yaml` includes:
```yaml
resources:
  - gotk-components.yaml
  - gotk-sync.yaml
  - infra-source.yaml
  - infra.yaml
```
Terraform may overwrite this file, removing the `infra-source.yaml` and `infra.yaml` lines. If so, restore them and push.

### Step 2: Push Platform Manifests (Git Only)

Everything else is automated via Flux. Just ensure the `dpl2` branch of `iaac-talos-flux-platform` has all manifests pushed. Flux will reconcile in dependency order automatically.

### Step 3: Verify (Optional — Monitoring Only)

```bash
# Watch kustomizations cascade
kubectl get kustomizations -n flux-system -w

# Final verification (after ~15 minutes)
kubectl get kustomizations -n flux-system              # All Ready: True
kubectl get externalsecrets -A | grep -c SecretSynced  # 139
kubectl get pods -A --no-headers | wc -l               # ~157
kubectl get pods -A --no-headers | grep -c Running     # ~80+
kubectl get events -A --field-selector type=Warning | grep ImagePull  # Should be empty
```

---

## Issues Resolved for CI/CD Compatibility

### Issue 1: ECR Init Job Timing (FIXED)

**Problem**: ECR init Job ran before app namespaces existed → pods had no `ecr-pull-secret` → `ImagePullBackOff`

**Fix**: Reordered dependency chain in `infra.yaml`:
- `ecr-credentials` now depends on `app-namespaces` (was the reverse)
- `app-namespaces` depends on `external-secrets` + `pod-identity-webhook` (removed `ecr-credentials` dep)
- Init Job has `ttlSecondsAfterFinished: 86400` for auto-cleanup

### Issue 2: KEDA HelmRelease Stuck (FIXED)

**Problem**: CRD race condition on first install → HelmRelease permanently `Stalled`

**Fix**: Added to `infrastructure/keda/helmrelease.yaml`:
```yaml
install:
  crds: CreateReplace
  remediation:
    retries: 5
upgrade:
  crds: CreateReplace
  remediation:
    retries: 3
```

### Issue 3: Pod Identity Webhook TLS (FIXED)

**Problem**: PIW used K8s CSR API which doesn't exist on Talos → TLS handshake failures

**Fix**: In `infrastructure/pod-identity-webhook/deployment.yaml`:
- `--in-cluster=false` (disables CSR-based cert management)
- `--tls-cert=/etc/webhook/certs/tls.crt` + `--tls-key=/etc/webhook/certs/tls.key`
- Cert-manager Certificate resource provides the certs

### Issue 4: ECR CronJob Non-Root (FIXED)

**Problem**: AWS CLI image runs as root → PodSecurity `restricted:latest` rejection

**Fix**: In `infrastructure/ecr-credentials/cronjob.yaml`:
- `runAsUser: 1000`, `runAsNonRoot: true`
- `HOME=/tmp` environment variable
- Full restricted securityContext on both CronJob and init Job

---

## Getting the 73 CrashLoopBackOff Apps Working

### Root Cause

Apps are crashing because they need real configuration that we've set to placeholder values:

1. **AzureAD secrets** — `CLIENT_ID`, `CLIENT_SECRET`, `TENANT_ID` are all `"placeholder"`
2. **MongoDB connection strings** — Many apps need `MONGODB_URI` or similar
3. **App-specific env vars** — e.g., `APPLICATION:ENVIRONMENT` for .NET apps
4. **Kafka broker endpoints** — Apps connecting to Confluent Cloud need real credentials

### Priority Order

1. **Populate real AzureAD secrets** in AWS Secrets Manager (largest impact — affects most apps)
2. **Add missing env vars** to deployment manifests (e.g., `APPLICATION:ENVIRONMENT`)
3. **Populate MongoDB connection strings** per namespace
4. **Populate Kafka credentials** if not already real

### How to Fix

1. Update secrets in AWS Secrets Manager:
```bash
aws secretsmanager update-secret --secret-id "dx--enterprise-azuread-secret" \
  --secret-string '{"CLIENT_ID":"real-id","CLIENT_SECRET":"real-secret","TENANT_ID":"real-tenant"}'
```

2. ExternalSecrets auto-refresh within 1h, or force-sync:
```bash
kubectl annotate externalsecret --all force-sync=$(date +%s) --overwrite -A
```

3. Pods will automatically restart with new secrets (no manual intervention needed).

---

## Resource Budget

| Resource | Per Pod | 99 Pods Total | 5-Worker Capacity |
|----------|---------|---------------|-------------------|
| CPU Request | 50m | 4.95 cores | ~10 cores allocatable |
| Memory Request | 64Mi | ~6.2 Gi | ~40 Gi allocatable |
| CPU Limit | 200m | 19.8 cores | ~10 cores |
| Memory Limit | 256Mi | ~24.8 Gi | ~40 Gi |

Fits comfortably — CPU requests use ~50% capacity, memory requests use ~15% capacity.

---

## Files Reference

| What | Where |
|------|-------|
| Production extract | `deployment-summary.jsonl` (99 apps) |
| Platform repo | `iaac-talos-flux-platform/` (branch: dpl2) |
| Cluster repo | `iaac-talos-flux-cluster/` (clusters/dpl2/) |
| Terraform IRSA roles | `terraform-irsa-roles/` |
| Architecture document | `dpl2_platform_architecture_document.md` |
| MageRunner guide | `dpl2_magerunner_local_setup_guide.md` |
| This document | `dx_deployment_preparation.md` |
